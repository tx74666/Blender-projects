"""Transactional Automatic Weights for only the selected deform bones."""

import traceback

import bpy
from bpy.types import Operator, Panel

from .ui_constants import SIDEBAR_CATEGORY


SUPPORTED_CONTEXT_MODES = frozenset({"POSE", "PAINT_WEIGHT", "EDIT_ARMATURE"})


class SelectedBoneWeightsError(ValueError):
    """A safe, artist-facing preflight or weighting failure."""


def _object_is_available(context, obj):
    return (
        obj is not None
        and context.view_layer.objects.get(obj.name) is obj
        and not obj.hide_get(view_layer=context.view_layer)
        and not obj.hide_viewport
    )


def _armature_modifiers(mesh_obj):
    return tuple(
        modifier
        for modifier in mesh_obj.modifiers
        if modifier.type == "ARMATURE"
        and modifier.object is not None
        and modifier.object.type == "ARMATURE"
    )


def _selected_pose_bone_names(armature_obj):
    names = []
    for pose_bone in armature_obj.pose.bones:
        if not bool(getattr(pose_bone, "select", False)):
            continue
        bone = pose_bone.bone
        if bone.hide or not bone.use_deform:
            continue
        names.append(pose_bone.name)
    return tuple(names)


def _selected_edit_bone_names(armature_obj):
    names = []
    for edit_bone in armature_obj.data.edit_bones:
        if edit_bone.select and edit_bone.use_deform:
            names.append(edit_bone.name)
    return tuple(names)


def _selected_deform_bone_names(context, armature_obj):
    if (
        context.mode == "EDIT_ARMATURE"
        and context.edit_object is armature_obj
    ):
        return _selected_edit_bone_names(armature_obj)
    return _selected_pose_bone_names(armature_obj)


def _mirrored_half_mesh_source(mesh_obj):
    """Return the base-mesh X side and tolerance for one standard Mirror stack."""
    mirrors = tuple(
        modifier
        for modifier in mesh_obj.modifiers
        if modifier.type == "MIRROR"
        and modifier.use_axis[0]
        and modifier.use_mirror_vertex_groups
        and modifier.mirror_object is None
    )
    if len(mirrors) != 1:
        return None

    x_values = tuple(vertex.co.x for vertex in mesh_obj.data.vertices)
    if not x_values:
        return None
    minimum = min(x_values)
    maximum = max(x_values)
    tolerance = max(1.0e-6, (maximum - minimum) * 1.0e-5)
    if minimum >= -tolerance and maximum > tolerance:
        source_side = 1.0
    elif maximum <= tolerance and minimum < -tolerance:
        source_side = -1.0
    else:
        return None
    return source_side, tolerance


def _validate_mirrored_half_mesh_side(mesh_obj, armature_obj, selected_names):
    """Refuse bones that exist only on a Mirror-generated X side.

    A generated half has no base vertices that can own the requested weights.
    Its source-side counterpart must be weighted instead.
    """

    source = _mirrored_half_mesh_source(mesh_obj)
    if source is None:
        return
    source_side, tolerance = source

    mesh_from_armature = mesh_obj.matrix_world.inverted_safe() @ armature_obj.matrix_world
    generated_side = []
    for name in selected_names:
        bone = armature_obj.data.bones.get(name)
        if bone is None:
            continue
        center = mesh_from_armature @ ((bone.head_local + bone.tail_local) * 0.5)
        if center.x * source_side < -tolerance:
            generated_side.append(name)
    if not generated_side:
        return

    label = ", ".join(generated_side[:3])
    if len(generated_side) > 3:
        label += f" (+{len(generated_side) - 3})"
    side_label = "+X" if source_side > 0.0 else "-X"
    raise SelectedBoneWeightsError(
        f"This is a mirrored {side_label} half Mesh. Select source-side or center "
        f"bones instead; these bones exist only on the generated side: {label}."
    )


def _missing_mirror_pair_group_names(mesh_obj, armature_obj, selected_names):
    """Find empty counterpart groups required by a true half-Mesh Mirror.

    Blender's Mirror modifier can flip ``.L``/``.R`` memberships only when the
    counterpart Vertex Group definition exists.  The generated side still owns
    no base vertices, so creating an empty definition preserves every
    unselected bone's weights while making the evaluated mirrored weights usable.
    """

    if _mirrored_half_mesh_source(mesh_obj) is None:
        return ()

    selected = set(selected_names)
    missing = []
    for name in selected_names:
        paired_name = bpy.utils.flip_name(name)
        if paired_name == name or paired_name in selected:
            continue
        paired_bone = armature_obj.data.bones.get(paired_name)
        if paired_bone is None or not paired_bone.use_deform:
            continue
        if mesh_obj.vertex_groups.get(paired_name) is None:
            missing.append(paired_name)
    return tuple(dict.fromkeys(missing))


def _resolve_armature(context):
    active = context.view_layer.objects.active
    selected = tuple(context.selected_objects or ())
    selected_armatures = tuple(obj for obj in selected if obj.type == "ARMATURE")

    if active is not None and active.type == "ARMATURE":
        return active

    if active is not None and active.type == "MESH":
        modifiers = _armature_modifiers(active)
        targets = tuple(dict.fromkeys(modifier.object for modifier in modifiers))
        if len(targets) == 1:
            if selected_armatures and targets[0] not in selected_armatures:
                raise SelectedBoneWeightsError(
                    "The selected Armature does not match the Mesh's Armature modifier."
                )
            return targets[0]
        if len(targets) > 1:
            raise SelectedBoneWeightsError(
                "The active Mesh has multiple Armature targets; choose an unambiguous rig."
            )

    if len(selected_armatures) == 1:
        return selected_armatures[0]
    if not selected_armatures:
        raise SelectedBoneWeightsError("Select the bound Armature and its deform bones.")
    raise SelectedBoneWeightsError("Select exactly one Armature.")


def _mesh_uses_armature(mesh_obj, armature_obj):
    modifiers = _armature_modifiers(mesh_obj)
    return len(modifiers) == 1 and modifiers[0].object is armature_obj


def _resolve_mesh(context, armature_obj):
    active = context.view_layer.objects.active
    if active is not None and active.type == "MESH":
        candidates = (active,)
    else:
        selected = tuple(
            obj
            for obj in (context.selected_objects or ())
            if obj.type == "MESH"
        )
        if selected:
            candidates = selected
        else:
            candidates = tuple(
                obj
                for obj in context.view_layer.objects
                if obj.type == "MESH" and _mesh_uses_armature(obj, armature_obj)
            )

    if len(candidates) != 1:
        if not candidates:
            raise SelectedBoneWeightsError(
                "Select one Mesh with an existing Armature modifier for this rig."
            )
        raise SelectedBoneWeightsError(
            "More than one bound Mesh is available; select exactly one Mesh."
        )

    mesh_obj = candidates[0]
    modifiers = _armature_modifiers(mesh_obj)
    if len(modifiers) != 1 or modifiers[0].object is not armature_obj:
        raise SelectedBoneWeightsError(
            "The Mesh must have exactly one Armature modifier targeting the selected rig."
        )
    return mesh_obj, modifiers[0]


def _preflight(context):
    if context.mode not in SUPPORTED_CONTEXT_MODES:
        raise SelectedBoneWeightsError(
            "Use Pose Mode, Weight Paint Mode, or Armature Edit Mode."
        )

    armature_obj = _resolve_armature(context)
    mesh_obj, armature_modifier = _resolve_mesh(context, armature_obj)

    if not _object_is_available(context, armature_obj):
        raise SelectedBoneWeightsError("The Armature must be visible in the current View Layer.")
    if not _object_is_available(context, mesh_obj):
        raise SelectedBoneWeightsError("The Mesh must be visible in the current View Layer.")
    if mesh_obj.library is not None and mesh_obj.override_library is None:
        raise SelectedBoneWeightsError("The linked Mesh is read-only.")
    if mesh_obj.data.library is not None and mesh_obj.data.override_library is None:
        raise SelectedBoneWeightsError("The linked Mesh data is read-only.")
    if not mesh_obj.data.vertices:
        raise SelectedBoneWeightsError("The Mesh has no vertices to weight.")

    selected_names = _selected_deform_bone_names(context, armature_obj)
    if not selected_names:
        raise SelectedBoneWeightsError("Select at least one visible Deform bone.")
    _validate_mirrored_half_mesh_side(mesh_obj, armature_obj, selected_names)

    locked = tuple(
        name
        for name in selected_names
        if mesh_obj.vertex_groups.get(name) is not None
        and mesh_obj.vertex_groups[name].lock_weight
    )
    if locked:
        label = ", ".join(locked[:3])
        if len(locked) > 3:
            label += f" (+{len(locked) - 3})"
        raise SelectedBoneWeightsError(
            f"Unlock the selected bone Vertex Group first: {label}."
        )

    return mesh_obj, armature_obj, armature_modifier, selected_names


def _capture_vertex_groups(mesh_obj):
    states = [
        {
            "name": group.name,
            "index": group.index,
            "lock_weight": bool(group.lock_weight),
            "weights": [],
        }
        for group in mesh_obj.vertex_groups
    ]
    for vertex in mesh_obj.data.vertices:
        for membership in vertex.groups:
            if membership.group < len(states):
                states[membership.group]["weights"].append(
                    (vertex.index, float(membership.weight))
                )
    for state in states:
        state["weights"] = tuple(state["weights"])
    return tuple(states)


def _group_state_map(states):
    return {state["name"]: state for state in states}


def _clear_group(group, vertex_count):
    was_locked = bool(group.lock_weight)
    group.lock_weight = False
    try:
        chunk_size = 32768
        for start in range(0, vertex_count, chunk_size):
            group.remove(list(range(start, min(start + chunk_size, vertex_count))))
    finally:
        group.lock_weight = was_locked


def _restore_vertex_groups(mesh_obj, states):
    expected_names = tuple(state["name"] for state in states)
    expected_set = set(expected_names)

    for group in reversed(tuple(mesh_obj.vertex_groups)):
        if group.name not in expected_set:
            mesh_obj.vertex_groups.remove(group)

    current_names = tuple(group.name for group in mesh_obj.vertex_groups)
    if current_names != expected_names:
        for group in reversed(tuple(mesh_obj.vertex_groups)):
            mesh_obj.vertex_groups.remove(group)
        for state in states:
            mesh_obj.vertex_groups.new(name=state["name"])

    vertex_count = len(mesh_obj.data.vertices)
    for state in states:
        group = mesh_obj.vertex_groups.get(state["name"])
        if group is None or group.index != state["index"]:
            raise RuntimeError("Vertex Group order changed unexpectedly.")
        group.lock_weight = False
        _clear_group(group, vertex_count)
        for vertex_index, weight in state["weights"]:
            group.add((vertex_index,), weight, "REPLACE")
        group.lock_weight = state["lock_weight"]

    restored = _capture_vertex_groups(mesh_obj)
    if restored != states:
        raise RuntimeError("Vertex Group rollback could not be verified exactly.")


def _verify_protected_groups(
    mesh_obj,
    before_states,
    selected_names,
    allowed_empty_names=(),
):
    selected = set(selected_names)
    allowed_empty = set(allowed_empty_names)
    after_states = _capture_vertex_groups(mesh_obj)
    before_by_name = _group_state_map(before_states)
    after_by_name = _group_state_map(after_states)

    unexpected = (
        set(after_by_name)
        - set(before_by_name)
        - selected
        - allowed_empty
    )
    missing = set(before_by_name) - set(after_by_name)
    if unexpected or missing:
        raise SelectedBoneWeightsError(
            "Automatic Weights changed protected Vertex Group definitions."
        )

    for name, before in before_by_name.items():
        if name in selected:
            continue
        after = after_by_name.get(name)
        if after != before:
            raise SelectedBoneWeightsError(
                f'Automatic Weights changed protected Vertex Group "{name}".'
            )

    for name in allowed_empty_names:
        after = after_by_name.get(name)
        if after is None or after["weights"]:
            raise SelectedBoneWeightsError(
                f'Automatic Weights changed mirror-pair Vertex Group "{name}".'
            )

    for name in selected_names:
        after = after_by_name.get(name)
        if after is None or not any(weight > 0.0 for _index, weight in after["weights"]):
            raise SelectedBoneWeightsError(
                f'Automatic Weights produced no usable result for "{name}".'
            )
    return after_states


def _capture_context_state(context, mesh_obj, armature_obj):
    edit_selection = ()
    edit_active = ""
    if context.mode == "EDIT_ARMATURE" and context.edit_object is armature_obj:
        edit_selection = tuple(
            (
                bone.name,
                bool(bone.select),
                bool(bone.select_head),
                bool(bone.select_tail),
            )
            for bone in armature_obj.data.edit_bones
        )
        active = armature_obj.data.edit_bones.active
        edit_active = active.name if active is not None else ""

    active_bone = armature_obj.data.bones.active
    return {
        "mode": context.mode,
        "active_object": context.view_layer.objects.active,
        "selected_objects": tuple(
            obj for obj in context.view_layer.objects if obj.select_get()
        ),
        "pose_selection": tuple(
            bone.name
            for bone in armature_obj.pose.bones
            if bool(getattr(bone, "select", False))
        ),
        "active_bone": active_bone.name if active_bone is not None else "",
        "edit_selection": edit_selection,
        "edit_active": edit_active,
        "active_group_index": mesh_obj.vertex_groups.active_index,
    }


def _force_object_mode(context):
    active = context.view_layer.objects.active
    if active is not None and active.mode != "OBJECT":
        result = bpy.ops.object.mode_set(mode="OBJECT")
        if "FINISHED" not in result:
            raise RuntimeError("Blender could not leave the current mode safely.")


def _deselect_all_objects(context):
    for obj in context.view_layer.objects:
        if obj.select_get():
            obj.select_set(False)


def _set_pose_selection(armature_obj, names, active_name=""):
    selected = set(names)
    for pose_bone in armature_obj.pose.bones:
        pose_bone.select = pose_bone.name in selected
    active = armature_obj.data.bones.get(active_name) if active_name else None
    if active is None and names:
        active = armature_obj.data.bones.get(names[0])
    armature_obj.data.bones.active = active


def _enter_pose_mode(context, armature_obj, selected_names, active_name=""):
    _force_object_mode(context)
    _deselect_all_objects(context)
    armature_obj.select_set(True)
    context.view_layer.objects.active = armature_obj
    result = bpy.ops.object.mode_set(mode="POSE")
    if "FINISHED" not in result:
        raise RuntimeError("Blender could not enter Pose Mode.")
    _set_pose_selection(armature_obj, selected_names, active_name)


def _enter_weight_paint(context, mesh_obj, armature_obj, selected_names):
    _enter_pose_mode(context, armature_obj, selected_names, selected_names[0])
    mesh_obj.select_set(True)
    context.view_layer.objects.active = mesh_obj
    result = bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
    if "FINISHED" not in result:
        raise RuntimeError("Blender could not enter Weight Paint Mode.")
    actual = tuple(
        bone.name
        for bone in (context.selected_pose_bones or ())
        if bone.bone.use_deform
    )
    if set(actual) != set(selected_names):
        raise RuntimeError("Blender did not preserve the intended Pose Bone selection.")


def _restore_context_state(context, mesh_obj, armature_obj, state):
    _force_object_mode(context)
    _deselect_all_objects(context)

    for obj in state["selected_objects"]:
        if _object_is_available(context, obj):
            obj.select_set(True)
    active = state["active_object"]
    if _object_is_available(context, active):
        context.view_layer.objects.active = active

    original_mode = state["mode"]
    if original_mode == "POSE":
        if not armature_obj.select_get():
            armature_obj.select_set(True)
        context.view_layer.objects.active = armature_obj
        result = bpy.ops.object.mode_set(mode="POSE")
        if "FINISHED" not in result:
            raise RuntimeError("Blender could not restore Pose Mode.")
        _set_pose_selection(
            armature_obj,
            state["pose_selection"],
            state["active_bone"],
        )
    elif original_mode == "PAINT_WEIGHT":
        _enter_pose_mode(
            context,
            armature_obj,
            state["pose_selection"],
            state["active_bone"],
        )
        mesh_obj.select_set(True)
        context.view_layer.objects.active = mesh_obj
        result = bpy.ops.object.mode_set(mode="WEIGHT_PAINT")
        if "FINISHED" not in result:
            raise RuntimeError("Blender could not restore Weight Paint Mode.")
        for obj in state["selected_objects"]:
            if obj not in {mesh_obj, armature_obj} and _object_is_available(context, obj):
                obj.select_set(True)
    elif original_mode == "EDIT_ARMATURE":
        if not armature_obj.select_get():
            armature_obj.select_set(True)
        context.view_layer.objects.active = armature_obj
        result = bpy.ops.object.mode_set(mode="EDIT")
        if "FINISHED" not in result:
            raise RuntimeError("Blender could not restore Armature Edit Mode.")
        selected = {
            name: (body, head, tail)
            for name, body, head, tail in state["edit_selection"]
        }
        for edit_bone in armature_obj.data.edit_bones:
            edit_bone.select = False
            edit_bone.select_head = False
            edit_bone.select_tail = False
        for edit_bone in armature_obj.data.edit_bones:
            body, head, tail = selected.get(edit_bone.name, (False, False, False))
            edit_bone.select = body
            edit_bone.select_head = head
            edit_bone.select_tail = tail
        armature_obj.data.edit_bones.active = armature_obj.data.edit_bones.get(
            state["edit_active"]
        )
        restored = tuple(
            (
                bone.name,
                bool(bone.select),
                bool(bone.select_head),
                bool(bone.select_tail),
            )
            for bone in armature_obj.data.edit_bones
        )
        if restored != state["edit_selection"]:
            raise RuntimeError("Blender could not restore the exact Edit Bone selection.")
    else:
        _set_pose_selection(
            armature_obj,
            state["pose_selection"],
            state["active_bone"],
        )
    mesh_obj.vertex_groups.active_index = state["active_group_index"]


def _capture_structure(mesh_obj, armature_obj):
    bones = (
        armature_obj.data.edit_bones
        if armature_obj.mode == "EDIT"
        else armature_obj.data.bones
    )
    return {
        "parent": mesh_obj.parent,
        "parent_type": mesh_obj.parent_type,
        "parent_bone": mesh_obj.parent_bone,
        "matrix_parent_inverse": tuple(
            value for row in mesh_obj.matrix_parent_inverse for value in row
        ),
        "modifiers": tuple(
            (
                modifier.as_pointer(),
                modifier.name,
                modifier.type,
                getattr(modifier, "object", None),
            )
            for modifier in mesh_obj.modifiers
        ),
        "deform": tuple(
            (bone.name, bool(bone.use_deform)) for bone in bones
        ),
        "mesh_data": mesh_obj.data,
    }


def _verify_structure(mesh_obj, armature_obj, before):
    after = _capture_structure(mesh_obj, armature_obj)
    if after != before:
        raise SelectedBoneWeightsError(
            "Automatic Weights changed parenting, modifiers, Mesh data, or Deform flags."
        )


def _restore_deform_flags(armature_obj, before):
    if before is None:
        return
    expected = dict(before["deform"])
    bones = (
        armature_obj.data.edit_bones
        if armature_obj.mode == "EDIT"
        else armature_obj.data.bones
    )
    for bone in bones:
        if bone.name in expected:
            bone.use_deform = expected[bone.name]
    restored = tuple((bone.name, bool(bone.use_deform)) for bone in bones)
    if restored != before["deform"]:
        raise RuntimeError("Blender could not restore every bone Deform flag.")


def _run_native_auto_weights():
    return bpy.ops.paint.weight_from_bones(type="AUTOMATIC")


class CHARACTERDESIGNER_OT_auto_weight_selected_bones(Operator):
    bl_idname = "character_designer.auto_weight_selected_bones"
    bl_label = "Auto Weight Selected Bones"
    bl_description = (
        "Recalculate Automatic Weights only for selected Deform bones while "
        "verifying every other Vertex Group remains exactly unchanged"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if context.view_layer is None or context.scene is None:
            return False
        if context.mode not in SUPPORTED_CONTEXT_MODES:
            cls.poll_message_set(
                "Use Pose Mode, Weight Paint Mode, or Armature Edit Mode."
            )
            return False
        return True

    def execute(self, context):
        mesh_obj = None
        armature_obj = None
        group_snapshot = None
        context_snapshot = None
        structure_snapshot = None
        temporary_flags = None
        context_restore_error = None
        finalization_errors = []
        rollback_error = None
        failure_message = None
        selected_names = ()
        mirror_pair_names = ()
        completed = False

        try:
            (
                mesh_obj,
                armature_obj,
                _armature_modifier,
                selected_names,
            ) = _preflight(context)
            group_snapshot = _capture_vertex_groups(mesh_obj)
            context_snapshot = _capture_context_state(
                context,
                mesh_obj,
                armature_obj,
            )
            structure_snapshot = _capture_structure(mesh_obj, armature_obj)
            mirror_pair_names = _missing_mirror_pair_group_names(
                mesh_obj,
                armature_obj,
                selected_names,
            )
            temporary_flags = (
                bool(mesh_obj.data.use_mirror_x),
                bool(mesh_obj.data.use_paint_mask),
                bool(mesh_obj.data.use_paint_mask_vertex),
            )

            _enter_weight_paint(
                context,
                mesh_obj,
                armature_obj,
                selected_names,
            )

            mesh_obj.data.use_mirror_x = False
            mesh_obj.data.use_paint_mask = False
            mesh_obj.data.use_paint_mask_vertex = False

            for name in mirror_pair_names:
                mesh_obj.vertex_groups.new(name=name)

            vertex_count = len(mesh_obj.data.vertices)
            for name in selected_names:
                group = mesh_obj.vertex_groups.get(name)
                if group is None:
                    group = mesh_obj.vertex_groups.new(name=name)
                _clear_group(group, vertex_count)

            if not bpy.ops.paint.weight_from_bones.poll():
                raise SelectedBoneWeightsError(
                    "Blender Automatic Weights is unavailable for this Mesh and Armature."
                )
            result = _run_native_auto_weights()
            if "FINISHED" not in result:
                raise SelectedBoneWeightsError("Blender Automatic Weights did not finish.")

            _verify_protected_groups(
                mesh_obj,
                group_snapshot,
                selected_names,
                mirror_pair_names,
            )
            _verify_structure(mesh_obj, armature_obj, structure_snapshot)
            completed = True
        except SelectedBoneWeightsError as exc:
            failure_message = str(exc)
        except Exception as exc:
            traceback.print_exc()
            failure_message = (
                f"Selected-bone Automatic Weights was rolled back: {exc}"
            )
        finally:
            if (
                not completed
                and mesh_obj is not None
                and group_snapshot is not None
            ):
                try:
                    _restore_vertex_groups(mesh_obj, group_snapshot)
                except Exception as exc:
                    traceback.print_exc()
                    rollback_error = exc
            if armature_obj is not None:
                try:
                    _restore_deform_flags(armature_obj, structure_snapshot)
                except Exception as exc:
                    traceback.print_exc()
                    finalization_errors.append(f"Deform flags: {exc}")
            if mesh_obj is not None and temporary_flags is not None:
                try:
                    (
                        mesh_obj.data.use_mirror_x,
                        mesh_obj.data.use_paint_mask,
                        mesh_obj.data.use_paint_mask_vertex,
                    ) = temporary_flags
                except Exception as exc:
                    traceback.print_exc()
                    finalization_errors.append(f"Mesh flags: {exc}")
            if (
                mesh_obj is not None
                and armature_obj is not None
                and context_snapshot is not None
            ):
                try:
                    _restore_context_state(
                        context,
                        mesh_obj,
                        armature_obj,
                        context_snapshot,
                    )
                except Exception:
                    traceback.print_exc()
                    context_restore_error = RuntimeError(
                        "Blender could not restore the original mode and selection."
                    )

        if (
            completed
            and (context_restore_error is not None or finalization_errors)
            and mesh_obj is not None
            and group_snapshot is not None
        ):
            try:
                _restore_vertex_groups(mesh_obj, group_snapshot)
                completed = False
            except Exception as exc:
                traceback.print_exc()
                rollback_error = exc

        if rollback_error is not None:
            self.report(
                {"ERROR"},
                "Weight rollback failed; inspect the Mesh before continuing.",
            )
            return {"CANCELLED"}
        if finalization_errors:
            self.report(
                {"ERROR"},
                "Could not restore all temporary state: "
                + "; ".join(finalization_errors),
            )
            return {"CANCELLED"}
        if context_restore_error is not None:
            self.report({"WARNING"}, str(context_restore_error))
            return {"CANCELLED"}
        if failure_message is not None:
            self.report({"WARNING"}, failure_message)
            return {"CANCELLED"}

        protected_count = sum(
            state["name"] not in set(selected_names) for state in group_snapshot
        )
        message = (
            f"Recalculated {len(selected_names)} selected bone"
            f"{'s' if len(selected_names) != 1 else ''}; "
            f"verified {protected_count} other Vertex Groups unchanged."
        )
        if mirror_pair_names:
            message += (
                f" Added {len(mirror_pair_names)} empty Mirror counterpart"
                f"{'s' if len(mirror_pair_names) != 1 else ''}."
            )
        self.report({"INFO"}, message)
        return {"FINISHED"}


class CHARACTERDESIGNER_PT_weight_tools(Panel):
    bl_label = "Weight Tools"
    bl_idname = "CHARACTERDESIGNER_PT_weight_tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = SIDEBAR_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, _context):
        layout = self.layout
        layout.label(text="Select one bound Mesh and Pose bones.", icon="INFO")
        layout.operator(
            "character_designer.auto_weight_selected_bones",
            text="Auto Weight Selected Bones",
            icon="MOD_ARMATURE",
        )


SELECTED_BONE_WEIGHT_CLASSES = (
    CHARACTERDESIGNER_OT_auto_weight_selected_bones,
    CHARACTERDESIGNER_PT_weight_tools,
)
