bl_info = {
    "name": "Character Designer",
    "author": "Randy & Codex",
    "version": (0, 3, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Character",
    "description": "Build exact center curves from selected character-mesh slices.",
    "category": "3D View",
}

import hashlib
import importlib
import json
import os
import sys
import traceback
from collections import defaultdict, deque

import bmesh
import bpy
from bpy.props import IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Vector


VERSION_TEXT = ".".join(str(value) for value in bl_info["version"])
GENERATOR_ID = "character_designer_centerline_v1"
EPSILON = 1.0e-8

ADDON_SOURCE_ROOT = os.path.dirname(os.path.abspath(__file__))
ADDON_MODULE_NAME = (__package__ or os.path.basename(ADDON_SOURCE_ROOT)).split(".")[0]
ADDON_REFRESH_PENDING = False
ADDON_REFRESH_LAST_STATE = False
ADDON_REFRESH_LAST_ERROR = ""


class CenterlineError(ValueError):
    """A topology or selection problem that can be shown directly to the artist."""


def _source_files():
    paths = []
    for root, directory_names, file_names in os.walk(ADDON_SOURCE_ROOT):
        directory_names[:] = [
            name
            for name in directory_names
            if name != "__pycache__" and not name.startswith(".")
        ]
        for file_name in file_names:
            if file_name.endswith(".py"):
                paths.append(os.path.join(root, file_name))
    return sorted(paths)


def _source_signature():
    signature = []
    for path in _source_files():
        try:
            stat = os.stat(path)
        except OSError:
            continue
        relative_path = os.path.relpath(path, ADDON_SOURCE_ROOT).replace(os.sep, "/")
        signature.append((relative_path, stat.st_mtime_ns, stat.st_size))
    return tuple(signature)


ADDON_LOADED_SIGNATURE = _source_signature()


def _source_changed():
    return _source_signature() != ADDON_LOADED_SIGNATURE


def _validate_source_files():
    for path in _source_files():
        with open(path, "rb") as handle:
            compile(handle.read(), path, "exec")


def _tag_view3d_redraw():
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _source_watch_deferred():
    global ADDON_REFRESH_LAST_STATE

    changed = _source_changed()
    if changed != ADDON_REFRESH_LAST_STATE:
        ADDON_REFRESH_LAST_STATE = changed
        _tag_view3d_redraw()
    return 1.0


def _register_source_watch():
    global ADDON_REFRESH_LAST_STATE

    ADDON_REFRESH_LAST_STATE = _source_changed()
    try:
        if not bpy.app.timers.is_registered(_source_watch_deferred):
            bpy.app.timers.register(
                _source_watch_deferred,
                first_interval=1.0,
                persistent=True,
            )
    except Exception as exc:
        print(f"[Character Designer] Could not start source watcher: {exc}")


def _unregister_source_watch():
    try:
        if bpy.app.timers.is_registered(_source_watch_deferred):
            bpy.app.timers.unregister(_source_watch_deferred)
    except Exception:
        pass


def _reload_addon_deferred():
    global ADDON_REFRESH_PENDING, ADDON_REFRESH_LAST_ERROR

    import addon_utils

    module_name = ADDON_MODULE_NAME
    old_modules = {
        name: module
        for name, module in list(sys.modules.items())
        if name == module_name or name.startswith(f"{module_name}.")
    }
    old_main = old_modules.get(module_name)
    persistent = bool(getattr(old_main, "__addon_persistent__", False)) if old_main else False

    try:
        try:
            addon_utils.disable(module_name, default_set=False, refresh_handled=True)
        except TypeError:
            addon_utils.disable(module_name, default_set=False)

        for name in old_modules:
            sys.modules.pop(name, None)
        importlib.invalidate_caches()

        try:
            reloaded = addon_utils.enable(
                module_name,
                default_set=False,
                persistent=persistent,
                refresh_handled=True,
            )
        except TypeError:
            reloaded = addon_utils.enable(
                module_name,
                default_set=False,
                persistent=persistent,
            )
        if reloaded is None:
            raise RuntimeError("Blender could not enable the refreshed add-on.")
        print("[Character Designer] Add-on refreshed successfully.")
    except Exception as exc:
        traceback.print_exc()
        for name in list(sys.modules):
            if name == module_name or name.startswith(f"{module_name}."):
                sys.modules.pop(name, None)
        sys.modules.update(old_modules)
        if old_main is not None:
            try:
                old_main.ADDON_REFRESH_PENDING = False
                old_main.ADDON_REFRESH_LAST_ERROR = str(exc)
                # register() is deliberately idempotent. If disable failed before
                # unregistering anything this is a no-op; if enable failed after a
                # successful disable it restores the old, known-good classes.
                old_main.register()
                old_main.__addon_enabled__ = True
            except Exception:
                traceback.print_exc()
        ADDON_REFRESH_PENDING = False
        ADDON_REFRESH_LAST_ERROR = str(exc)
    return None


def _mesh_object_poll(_self, obj):
    return obj is not None and obj.type == "MESH"


def _curve_object_poll(_self, obj):
    return obj is not None and obj.type == "CURVE"


class CharacterDesignerState(PropertyGroup):
    root_object: PointerProperty(
        name="Root Object",
        type=bpy.types.Object,
        poll=_mesh_object_poll,
        options={"SKIP_SAVE"},
    )
    root_mesh: PointerProperty(
        name="Root Mesh",
        type=bpy.types.Mesh,
        options={"SKIP_SAVE"},
    )
    root_indices_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_edges_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_kind: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_vertex_count: IntProperty(default=0, min=0, options={"SKIP_SAVE"})
    topology_signature: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    output_object: PointerProperty(
        name="Output",
        type=bpy.types.Object,
        poll=_curve_object_poll,
        options={"SKIP_SAVE"},
    )
    last_level: StringProperty(default="NONE", options={"HIDDEN", "SKIP_SAVE"})
    last_message: StringProperty(options={"HIDDEN", "SKIP_SAVE"})


def _settings(context):
    window_manager = getattr(context, "window_manager", None)
    return getattr(window_manager, "character_designer", None)


def _set_status(settings, level, message):
    settings.last_level = level
    settings.last_message = message


def _clear_capture(settings):
    settings.root_object = None
    settings.root_mesh = None
    settings.root_indices_json = ""
    settings.root_edges_json = ""
    settings.root_kind = ""
    settings.root_vertex_count = 0
    settings.topology_signature = ""


def _edit_bmesh(context):
    obj = context.edit_object
    if obj is None or obj.type != "MESH" or obj.mode != "EDIT":
        raise CenterlineError("Enter Mesh Edit Mode on one hair object.")
    if context.object is not obj:
        raise CenterlineError("The edited hair object must be active.")

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.verts.index_update()
    bm.edges.index_update()
    bm.faces.index_update()
    return obj, bm


def _topology_signature(bm):
    digest = hashlib.sha256()
    digest.update(f"v{len(bm.verts)}e{len(bm.edges)}f{len(bm.faces)}|".encode("ascii"))
    edge_keys = sorted(
        (min(edge.verts[0].index, edge.verts[1].index), max(edge.verts[0].index, edge.verts[1].index))
        for edge in bm.edges
    )
    for first, second in edge_keys:
        digest.update(f"{first}:{second};".encode("ascii"))
    return digest.hexdigest()


def _indices_from_settings(settings):
    try:
        values = json.loads(settings.root_indices_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CenterlineError("The captured root is invalid. Capture it again.") from exc
    if not isinstance(values, list) or not values:
        raise CenterlineError("Capture a root slice first.")
    try:
        indices = tuple(sorted({int(value) for value in values}))
    except (TypeError, ValueError) as exc:
        raise CenterlineError("The captured root is invalid. Capture it again.") from exc
    if len(indices) != len(values):
        raise CenterlineError("The captured root is invalid. Capture it again.")
    return indices


def _root_edges_from_settings(settings):
    try:
        values = json.loads(settings.root_edges_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CenterlineError("The captured root edges are invalid. Capture the root again.") from exc
    if not isinstance(values, list) or not values:
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")

    edge_keys = []
    try:
        for value in values:
            if not isinstance(value, list) or len(value) != 2:
                raise ValueError
            first, second = sorted((int(value[0]), int(value[1])))
            if first == second:
                raise ValueError
            edge_keys.append((first, second))
    except (TypeError, ValueError) as exc:
        raise CenterlineError("The captured root edges are invalid. Capture the root again.") from exc
    if len(set(edge_keys)) != len(edge_keys):
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")
    return tuple(sorted(edge_keys))


def _adjacency_from_edge_keys(vertex_indices, edge_keys):
    vertex_indices = set(vertex_indices)
    adjacency = {index: set() for index in vertex_indices}
    for first, second in edge_keys:
        if first in vertex_indices and second in vertex_indices:
            adjacency[first].add(second)
            adjacency[second].add(first)
    return adjacency


def _selected_edge_keys(bm, vertex_indices):
    vertex_indices = set(vertex_indices)
    edge_keys = []
    for edge in bm.edges:
        if not edge.select:
            continue
        first = edge.verts[0].index
        second = edge.verts[1].index
        if first in vertex_indices and second in vertex_indices:
            edge_keys.append(tuple(sorted((first, second))))
    return tuple(sorted(edge_keys))


def _is_connected(indices, adjacency):
    indices = set(indices)
    if not indices:
        return False
    visited = set()
    queue = deque((next(iter(indices)),))
    while queue:
        current = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        queue.extend((adjacency[current] & indices) - visited)
    return visited == indices


def _classify_slice(indices, adjacency, *, label):
    indices = set(indices)
    count = len(indices)
    if count == 1:
        return "POINT"
    if not _is_connected(indices, adjacency):
        raise CenterlineError(f"{label} is split into multiple pieces.")

    degrees = {index: len(adjacency[index] & indices) for index in indices}
    edge_count = sum(degrees.values()) // 2
    if count >= 3 and edge_count == count and all(value == 2 for value in degrees.values()):
        return "CLOSED"
    if edge_count == count - 1:
        end_count = sum(value == 1 for value in degrees.values())
        middle_ok = all(value in {1, 2} for value in degrees.values())
        if end_count == 2 and middle_ok:
            return "OPEN"
    raise CenterlineError(
        f"{label} branches or is not one simple row/loop. Select one clean cross-section."
    )


def _root_label(kind):
    return "closed loop" if kind == "CLOSED" else "open row"


def _slice_edge_keys(indices, adjacency):
    indices = set(indices)
    return {
        tuple(sorted((first, second)))
        for first in indices
        for second in adjacency[first] & indices
        if first < second
    }


def _validate_face_bands(bm, selected, layers, distances, adjacency):
    """Confirm that graph layers are backed by complete quad surface bands."""

    final_layer_index = len(layers) - 1
    band_faces = defaultdict(list)
    for face in bm.faces:
        indices = tuple(vertex.index for vertex in face.verts)
        if not all(index in selected for index in indices):
            continue
        face_layers = {distances[index] for index in indices}
        if len(face_layers) == 1:
            layer_index = next(iter(face_layers))
            if layer_index not in {0, final_layer_index}:
                raise CenterlineError(
                    f"Layer {layer_index + 1} contains an internal cap face."
                )
            continue
        if len(face_layers) != 2:
            raise CenterlineError("A selected face crosses more than one layer.")

        lower_layer = min(face_layers)
        upper_layer = max(face_layers)
        if upper_layer != lower_layer + 1:
            raise CenterlineError("A selected face skips a centerline layer.")
        lower_vertices = tuple(index for index in indices if distances[index] == lower_layer)
        upper_vertices = tuple(index for index in indices if distances[index] == upper_layer)
        upper_is_point = len(layers[upper_layer]) == 1
        valid_counts = (
            len(face.verts) == 3
            and len(lower_vertices) == 2
            and len(upper_vertices) == 1
        ) if upper_is_point else (
            len(face.verts) == 4
            and len(lower_vertices) == 2
            and len(upper_vertices) == 2
        )
        if not valid_counts:
            expected = "a 2+1 tip triangle" if upper_is_point else "a 2+2 quad"
            raise CenterlineError(
                f"The band between layers {lower_layer + 1} and {upper_layer + 1} "
                f"contains a face that is not {expected}."
            )

        face_edges = {
            tuple(sorted((edge.verts[0].index, edge.verts[1].index)))
            for edge in face.edges
        }
        lower_edge = tuple(sorted(lower_vertices))
        if lower_edge not in face_edges or lower_edge not in _slice_edge_keys(
            layers[lower_layer], adjacency
        ):
            raise CenterlineError(
                f"A face between layers {lower_layer + 1} and {upper_layer + 1} is twisted."
            )
        upper_edge = None
        if not upper_is_point:
            upper_edge = tuple(sorted(upper_vertices))
            if upper_edge not in face_edges or upper_edge not in _slice_edge_keys(
                layers[upper_layer], adjacency
            ):
                raise CenterlineError(
                    f"A face between layers {lower_layer + 1} and {upper_layer + 1} is twisted."
                )
        band_faces[lower_layer].append((lower_edge, upper_edge))

    for lower_layer in range(final_layer_index):
        upper_layer = lower_layer + 1
        expected_lower_edges = _slice_edge_keys(layers[lower_layer], adjacency)
        actual_faces = band_faces.get(lower_layer, [])
        actual_lower_edges = [lower_edge for lower_edge, _upper_edge in actual_faces]
        if (
            len(actual_faces) != len(expected_lower_edges)
            or set(actual_lower_edges) != expected_lower_edges
            or len(set(actual_lower_edges)) != len(actual_lower_edges)
        ):
            raise CenterlineError(
                f"Layers {lower_layer + 1} and {upper_layer + 1} do not have one complete face band."
            )

        if len(layers[upper_layer]) > 1:
            expected_upper_edges = _slice_edge_keys(layers[upper_layer], adjacency)
            actual_upper_edges = [upper_edge for _lower_edge, upper_edge in actual_faces]
            if (
                set(actual_upper_edges) != expected_upper_edges
                or len(set(actual_upper_edges)) != len(actual_upper_edges)
            ):
                raise CenterlineError(
                    f"Layers {lower_layer + 1} and {upper_layer + 1} have mismatched quad faces."
                )


def _selection_counts(bm):
    return (
        sum(vertex.select for vertex in bm.verts),
        sum(edge.select for edge in bm.edges),
        sum(face.select for face in bm.faces),
    )


def _capture_data(context):
    obj, bm = _edit_bmesh(context)
    selected = {vertex.index for vertex in bm.verts if vertex.select}
    if len(selected) < 2:
        raise CenterlineError("Select one root edge row or one root cap face, then capture.")

    edge_keys = _selected_edge_keys(bm, selected)
    adjacency = _adjacency_from_edge_keys(selected, edge_keys)
    kind = _classify_slice(selected, adjacency, label="The root selection")
    if kind == "POINT":
        raise CenterlineError("The root needs at least two vertices; a point is supported only at the tip.")
    return obj, bm, tuple(sorted(selected)), edge_keys, kind


def _validate_capture(context, settings):
    obj, bm = _edit_bmesh(context)
    if settings.root_object is None:
        raise CenterlineError("Capture a root slice first.")
    if obj is not settings.root_object or obj.data is not settings.root_mesh:
        raise CenterlineError("Return to the captured hair object, or capture a new root.")
    if _topology_signature(bm) != settings.topology_signature:
        raise CenterlineError("Hair topology changed after capture. Capture the root again.")

    root_indices = _indices_from_settings(settings)
    root_edge_keys = _root_edges_from_settings(settings)
    if root_indices[-1] >= len(bm.verts):
        raise CenterlineError("Hair topology changed after capture. Capture the root again.")
    root_set = set(root_indices)
    if any(first not in root_set or second not in root_set for first, second in root_edge_keys):
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")
    adjacency = _adjacency_from_edge_keys(root_set, root_edge_keys)
    kind = _classify_slice(root_set, adjacency, label="The captured root")
    if kind != settings.root_kind:
        raise CenterlineError("The captured root topology changed. Capture it again.")
    return obj, bm, root_indices, root_edge_keys


def _extract_layers(context, settings):
    obj, bm, root_indices, root_edge_keys = _validate_capture(context, settings)
    selected = {vertex.index for vertex in bm.verts if vertex.select}
    root_set = set(root_indices)
    missing = root_set - selected
    if missing:
        raise CenterlineError("Keep the captured root selected while growing toward the tip.")
    if selected == root_set:
        raise CenterlineError("Only the root is selected. Grow the selection toward the tip.")

    selected_edge_keys = [
        edge_key
        for edge_key in _selected_edge_keys(bm, selected)
        if not (edge_key[0] in root_set and edge_key[1] in root_set)
    ]
    selected_edge_keys.extend(root_edge_keys)
    adjacency = _adjacency_from_edge_keys(selected, selected_edge_keys)
    distances = {index: 0 for index in root_set}
    queue = deque(root_indices)
    while queue:
        current = queue.popleft()
        next_distance = distances[current] + 1
        for neighbor in adjacency[current]:
            if neighbor not in distances:
                distances[neighbor] = next_distance
                queue.append(neighbor)
    unreachable = selected - distances.keys()
    if unreachable:
        raise CenterlineError(
            f"The selection contains {len(unreachable)} vertex/vertices disconnected from the root."
        )

    grouped = defaultdict(list)
    for index, distance in distances.items():
        grouped[distance].append(index)
    layers = [tuple(sorted(grouped[distance])) for distance in range(max(grouped) + 1)]
    if set(layers[0]) != root_set:
        raise CenterlineError("The captured root could not be reconstructed. Capture it again.")

    for layer_index, layer in enumerate(layers):
        kind = _classify_slice(
            layer,
            adjacency,
            label=f"Layer {layer_index + 1}",
        )
        is_last = layer_index == len(layers) - 1
        if kind == "POINT":
            if not is_last:
                raise CenterlineError(
                    f"Layer {layer_index + 1} is a point before the tip. The selection branches after it."
                )
        elif kind != settings.root_kind:
            raise CenterlineError(
                f"Layer {layer_index + 1} changes from {_root_label(settings.root_kind)} "
                f"to {_root_label(kind)}. Check the selection."
            )

        if layer_index == 0:
            continue
        previous = set(layers[layer_index - 1])
        current = set(layer)
        cross_edges = []
        for previous_index in previous:
            for current_index in adjacency[previous_index] & current:
                cross_edges.append((previous_index, current_index))

        previous_degree = defaultdict(int)
        current_degree = defaultdict(int)
        for previous_index, current_index in cross_edges:
            previous_degree[previous_index] += 1
            current_degree[current_index] += 1

        if len(current) == 1:
            # A collapsed point tip is valid only when every vertex in the last
            # regular slice connects directly to that one final vertex.
            complete = (
                is_last
                and len(cross_edges) == len(previous)
                and all(previous_degree[index] == 1 for index in previous)
                and current_degree[next(iter(current))] == len(previous)
            )
        else:
            # The artist's source is a regular quad strip/tube. One-to-one
            # longitudinal edges make each graph-distance layer unambiguous;
            # many-to-many links would let BFS hide a branch or triangulated
            # shortcut inside an apparently valid row.
            complete = (
                len(previous) == len(current) == len(cross_edges)
                and all(previous_degree[index] == 1 for index in previous)
                and all(current_degree[index] == 1 for index in current)
            )
        if not complete:
            raise CenterlineError(
                f"Layers {layer_index} and {layer_index + 1} do not form one regular quad band."
            )

    _validate_face_bands(bm, selected, layers, distances, adjacency)

    centers = []
    for layer_index, layer in enumerate(layers):
        center = sum((bm.verts[index].co for index in layer), Vector((0.0, 0.0, 0.0))) / len(layer)
        if centers and (center - centers[-1]).length <= EPSILON:
            raise CenterlineError(
                f"Layers {layer_index} and {layer_index + 1} have the same center point."
            )
        centers.append(center.copy())
    return obj, bm, tuple(layers), tuple(centers)


def _visible_collections(context):
    visible_collections = set()

    def visit(layer_collection, parent_visible=True):
        visible = (
            parent_visible
            and not layer_collection.exclude
            and not layer_collection.hide_viewport
            and not layer_collection.collection.hide_viewport
            and not layer_collection.collection.hide_select
        )
        if visible:
            visible_collections.add(layer_collection.collection)
        for child in layer_collection.children:
            visit(child, visible)

    visit(context.view_layer.layer_collection)
    return visible_collections


def _visible_source_collection(context, source_obj):
    visible_collections = _visible_collections(context)
    for collection in source_obj.users_collection:
        if collection in visible_collections:
            return collection
    return context.collection or context.scene.collection


def _output_is_selectable(context, output):
    if not (
        output is not None
        and output.name in bpy.data.objects
        and output.type == "CURVE"
        and context.view_layer.objects.get(output.name) is output
        and not output.hide_viewport
        and not output.hide_select
    ):
        return False
    visible_collections = _visible_collections(context)
    return any(collection in visible_collections for collection in output.users_collection)


def _create_centerline_object(context, source_obj, layers, centers):
    curve_data = None
    curve_obj = None
    try:
        curve_data = bpy.data.curves.new(f"{source_obj.name}_Centerline", type="CURVE")
        curve_data.dimensions = "3D"
        curve_data.resolution_u = 1
        curve_data.render_resolution_u = 1
        curve_data.bevel_depth = 0.0
        curve_data.extrude = 0.0
        curve_data.taper_object = None

        spline = curve_data.splines.new(type="POLY")
        spline.points.add(len(centers) - 1)
        for point, center in zip(spline.points, centers):
            point.co = (*center, 1.0)
        spline.use_cyclic_u = False

        curve_obj = bpy.data.objects.new(f"{source_obj.name}_Centerline", curve_data)
        _visible_source_collection(context, source_obj).objects.link(curve_obj)
        curve_obj.matrix_world = source_obj.matrix_world.copy()
        curve_obj.show_in_front = True
        curve_obj["character_designer_generator"] = GENERATOR_ID
        curve_obj["character_designer_source"] = source_obj.name
        curve_obj["character_designer_layer_vertices"] = json.dumps(layers, separators=(",", ":"))
        return curve_obj
    except Exception:
        if curve_obj is not None and curve_obj.name in bpy.data.objects:
            bpy.data.objects.remove(curve_obj, do_unlink=True)
        if curve_data is not None and curve_data.name in bpy.data.curves:
            bpy.data.curves.remove(curve_data)
        raise


def _remove_created_curve(curve_obj):
    if curve_obj is None or curve_obj.name not in bpy.data.objects:
        return
    curve_data = curve_obj.data if curve_obj.type == "CURVE" else None
    bpy.data.objects.remove(curve_obj, do_unlink=True)
    if curve_data is not None and curve_data.users == 0:
        bpy.data.curves.remove(curve_data)


class CHARACTERDESIGNER_OT_capture_root(Operator):
    bl_idname = "character_designer.capture_root_slice"
    bl_label = "Capture Selected Root"
    bl_description = "Remember one selected open row or closed root loop"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.edit_object is not None and context.edit_object.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({"ERROR"}, "Character Designer is not registered correctly.")
            return {"CANCELLED"}
        try:
            obj, bm, root_indices, root_edge_keys, kind = _capture_data(context)
            settings.root_object = obj
            settings.root_mesh = obj.data
            settings.root_indices_json = json.dumps(root_indices, separators=(",", ":"))
            settings.root_edges_json = json.dumps(root_edge_keys, separators=(",", ":"))
            settings.root_kind = kind
            settings.root_vertex_count = len(root_indices)
            settings.topology_signature = _topology_signature(bm)
            _set_status(
                settings,
                "SUCCESS",
                f"Captured {_root_label(kind)} with {len(root_indices)} vertices.",
            )
        except CenterlineError as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, settings.last_message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_clear_root(Operator):
    bl_idname = "character_designer.clear_root_slice"
    bl_label = "Clear Captured Root"
    bl_description = "Forget the captured root slice"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        settings = _settings(context)
        if settings is not None:
            _clear_capture(settings)
            _set_status(settings, "INFO", "Root capture cleared.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_build_centerline(Operator):
    bl_idname = "character_designer.build_centerline"
    bl_label = "Build Center Curve"
    bl_description = "Create one exact Poly curve point at the arithmetic mean of every selected slice"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.edit_object is not None and context.edit_object.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({"ERROR"}, "Character Designer is not registered correctly.")
            return {"CANCELLED"}

        created = None
        try:
            source_obj, _bm, layers, centers = _extract_layers(context, settings)
            created = _create_centerline_object(context, source_obj, layers, centers)
            settings.output_object = created
            _set_status(
                settings,
                "SUCCESS",
                f"Built {created.name}: {len(centers)} exact center points.",
            )
        except CenterlineError as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            _remove_created_curve(created)
            if settings.output_object is created:
                settings.output_object = None
            message = f"Center curve failed: {exc}"
            _set_status(settings, "ERROR", message)
            self.report({"ERROR"}, message)
            traceback.print_exc()
            return {"CANCELLED"}

        self.report({"INFO"}, settings.last_message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_select_output(Operator):
    bl_idname = "character_designer.select_output"
    bl_label = "Select Output"
    bl_description = "Leave mesh Edit Mode and select the last generated center curve"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        obj = getattr(settings, "output_object", None) if settings else None
        return _output_is_selectable(context, obj)

    def execute(self, context):
        settings = _settings(context)
        output = settings.output_object
        if not _output_is_selectable(context, output):
            self.report({"WARNING"}, "The output curve is not visible/selectable in this View Layer.")
            return {"CANCELLED"}
        output.hide_set(False)
        if not output.visible_get(view_layer=context.view_layer):
            self.report({"WARNING"}, "The output curve is hidden by its collection or View Layer.")
            return {"CANCELLED"}
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        output.hide_set(False)
        output.select_set(True)
        context.view_layer.objects.active = output
        if not output.select_get(view_layer=context.view_layer):
            self.report({"ERROR"}, "Blender could not select the output curve.")
            return {"CANCELLED"}
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_refresh_addon(Operator):
    bl_idname = "character_designer.refresh_addon"
    bl_label = "Refresh Add-on"
    bl_description = "Validate and reload Character Designer after its Python files change"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, _context):
        return not ADDON_REFRESH_PENDING

    def execute(self, _context):
        global ADDON_REFRESH_PENDING, ADDON_REFRESH_LAST_ERROR

        if not _source_changed():
            self.report({"INFO"}, "Character Designer is already current.")
            return {"CANCELLED"}
        try:
            _validate_source_files()
        except Exception as exc:
            ADDON_REFRESH_LAST_ERROR = str(exc)
            self.report({"ERROR"}, f"Refresh blocked by a Python error: {exc}")
            return {"CANCELLED"}

        ADDON_REFRESH_PENDING = True
        ADDON_REFRESH_LAST_ERROR = ""
        try:
            if not bpy.app.timers.is_registered(_reload_addon_deferred):
                bpy.app.timers.register(_reload_addon_deferred, first_interval=0.1)
        except Exception as exc:
            ADDON_REFRESH_PENDING = False
            ADDON_REFRESH_LAST_ERROR = str(exc)
            self.report({"ERROR"}, f"Could not schedule refresh: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, "Refreshing Character Designer...")
        return {"FINISHED"}


def _draw_message(layout, level, message):
    if not message:
        return
    icon = {"ERROR": "ERROR", "SUCCESS": "CHECKMARK", "INFO": "INFO"}.get(level, "INFO")
    row = layout.row()
    row.alert = level == "ERROR"
    row.label(text=message, icon=icon)


class CHARACTERDESIGNER_PT_main(Panel):
    bl_label = "Character Designer"
    bl_idname = "CHARACTERDESIGNER_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Character"

    def draw(self, context):
        layout = self.layout
        settings = _settings(context)
        if settings is None:
            layout.label(text="Add-on state unavailable", icon="ERROR")
            return

        layout.label(text="Hair Centerline", icon="CURVE_DATA")

        root_box = layout.box()
        root_box.label(text="1  Root Slice")
        row = root_box.row(align=True)
        row.operator(
            "character_designer.capture_root_slice",
            text="Recapture Root" if settings.root_object else "Capture Selected Root",
            icon="RESTRICT_SELECT_OFF",
        )
        if settings.root_object:
            row.operator("character_designer.clear_root_slice", text="", icon="X")
            root_box.label(
                text=(
                    f"Captured: {_root_label(settings.root_kind)} · "
                    f"{settings.root_vertex_count} verts"
                ),
                icon="CHECKMARK",
            )
        else:
            root_box.label(text="Select one root row or cap face", icon="INFO")

        grow_box = layout.box()
        grow_box.label(text="2  Grow Selection")
        grow_box.label(text="Ctrl + Numpad +  toward the tip", icon="ADD")

        build_ready = False
        try:
            obj, bm = _edit_bmesh(context)
            vertex_count, edge_count, face_count = _selection_counts(bm)
            grow_box.label(text=f"Selected: {vertex_count} V · {edge_count} E · {face_count} F")
            if settings.root_object is not None and obj is settings.root_object:
                root_indices = set(_indices_from_settings(settings))
                selected = {vertex.index for vertex in bm.verts if vertex.select}
                if selected == root_indices:
                    grow_box.label(text="Root captured. Grow toward the tip.", icon="INFO")
                else:
                    _source, _bm, layers, _centers = _extract_layers(context, settings)
                    grow_box.label(
                        text=f"Ready: {len(layers)} layers → {len(layers)} curve points",
                        icon="CHECKMARK",
                    )
                    build_ready = True
            elif settings.root_object is not None:
                row = grow_box.row()
                row.alert = True
                row.label(text="Return to the captured hair object.", icon="ERROR")
        except CenterlineError as exc:
            if settings.root_object is not None:
                row = grow_box.row()
                row.alert = True
                row.label(text=str(exc), icon="ERROR")

        build_box = layout.box()
        build_box.label(text="3  Build")
        build_box.label(text="Points: layer vertex mean · exact source position")
        row = build_box.row()
        row.enabled = build_ready
        row.operator("character_designer.build_centerline", icon="CURVE_PATH")

        output = settings.output_object
        if output is not None and output.name in bpy.data.objects:
            row = build_box.row(align=True)
            row.prop(settings, "output_object", text="Output")
            row.operator("character_designer.select_output", text="Select", icon="RESTRICT_SELECT_OFF")

        _draw_message(layout, settings.last_level, settings.last_message)

        layout.separator()
        refresh_row = layout.row(align=True)
        refresh_row.label(text=f"v{VERSION_TEXT}")
        refresh_row.alert = bool(ADDON_REFRESH_LAST_ERROR or ADDON_REFRESH_LAST_STATE)
        refresh_row.enabled = not ADDON_REFRESH_PENDING
        refresh_row.operator(
            "character_designer.refresh_addon",
            text="Refreshing..." if ADDON_REFRESH_PENDING else "Refresh Add-on",
            icon="ERROR" if ADDON_REFRESH_LAST_ERROR else "FILE_REFRESH",
        )
        if ADDON_REFRESH_LAST_STATE:
            layout.label(text="Source changed · refresh ready", icon="INFO")


CLASSES = (
    CharacterDesignerState,
    CHARACTERDESIGNER_OT_capture_root,
    CHARACTERDESIGNER_OT_clear_root,
    CHARACTERDESIGNER_OT_build_centerline,
    CHARACTERDESIGNER_OT_select_output,
    CHARACTERDESIGNER_OT_refresh_addon,
    CHARACTERDESIGNER_PT_main,
)


def register():
    if hasattr(bpy.types.WindowManager, "character_designer"):
        _register_source_watch()
        return

    registered = []
    property_added = False
    try:
        for cls in CLASSES:
            bpy.utils.register_class(cls)
            registered.append(cls)
        bpy.types.WindowManager.character_designer = PointerProperty(
            type=CharacterDesignerState,
            options={"SKIP_SAVE"},
        )
        property_added = True
        _register_source_watch()
    except Exception:
        _unregister_source_watch()
        if property_added and hasattr(bpy.types.WindowManager, "character_designer"):
            del bpy.types.WindowManager.character_designer
        for cls in reversed(registered):
            try:
                bpy.utils.unregister_class(cls)
            except RuntimeError:
                pass
        raise


def unregister():
    _unregister_source_watch()
    if hasattr(bpy.types.WindowManager, "character_designer"):
        del bpy.types.WindowManager.character_designer
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
