# Character Designer

Character Designer is Randy's personal Blender add-on. It stays separate from
RR Helper, which remains focused on the team's Blender/BlackUnity workflow.

## Hair Centerline

This tool does one job: it turns the cross-sections of a selected hair mesh into
an exact, plain center curve.

1. Enter Mesh Edit Mode.
2. Select only the root cross-section: either one open vertex/edge row or one
   closed cap loop.
3. Click **Capture Selected Root**.
4. Keep the root selected and grow toward the tip with `Ctrl+Numpad+`.
5. Click **Build Center Curve**.

Each selected topological layer contributes one Poly curve point. The point is
the arithmetic mean of that layer's current vertex positions. A final
single-vertex tip is supported. The curve stores those points in the source
mesh's local space and copies the source object's transform, so it appears in
the exact original position without losing local precision.

The result is deliberately plain: no bevel profile, thickness, material,
Radius, Tilt, USD, or automatic shape generation. The source mesh, Edit Mode,
and selection remain untouched when the curve is built.

The extractor accepts a regular quad open strip or closed tube. Every two
non-tip layers must have one-to-one longitudinal edges; the final layer may
collapse to one fully connected point. It rejects a root in the middle,
disconnected selections, branches, ambiguous many-to-many layer links, partial
connections, and topology edits made after root capture instead of silently
producing a wrong curve.

## Refresh Add-on

Character Designer watches its installed Python files. When they change, use
**Refresh Add-on** at the bottom of the panel. The add-on validates every Python
file first, then reloads itself on a short Blender timer so the running operator
is never unregistered from inside its own callback. The current `.blend` is not
saved or reloaded; session-only root/output state is reset.
