bl_info = {
    "name": "Character Designer",
    "author": "Randy & Codex",
    "version": (0, 3, 2),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Character",
    "description": "Build exact center curves from selected character-mesh slices.",
    "category": "3D View",
}

import hashlib
import importlib
import json
import math
import os
import sys
import textwrap
import traceback
from collections import defaultdict, deque

import bmesh
import bpy
from bpy.props import IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Vector


GENERATOR_ID = "character_designer_centerline_v1"
METADATA_VERSION = 2
METADATA_SPACE = "SOURCE_OBJECT_LOCAL"
EPSILON = 1.0e-8

ADDON_SOURCE_ROOT = os.path.dirname(os.path.abspath(__file__))
ADDON_MODULE_NAME = (__package__ or os.path.basename(ADDON_SOURCE_ROOT)).split(".")[0]
ADDON_REFRESH_PENDING = False
ADDON_REFRESH_LAST_STATE = False
ADDON_REFRESH_LAST_ERROR = ""


class CenterlineError(ValueError):
    """A topology or selection problem that can be shown directly to the artist."""


def _source_files():
    paths = []
    for root, directory_names, file_names in os.walk(ADDON_SOURCE_ROOT):
        directory_names[:] = [
            name
            for name in directory_names
            if name != "__pycache__" and not name.startswith(".")
        ]
        for file_name in file_names:
            if file_name.endswith(".py"):
                paths.append(os.path.join(root, file_name))
    return sorted(paths)


def _source_signature():
    signature = []
    for path in _source_files():
        try:
            stat = os.stat(path)
        except OSError:
            continue
        relative_path = os.path.relpath(path, ADDON_SOURCE_ROOT).replace(os.sep, "/")
        signature.append((relative_path, stat.st_mtime_ns, stat.st_size))
    return tuple(signature)


ADDON_LOADED_SIGNATURE = _source_signature()


def _source_changed():
    return _source_signature() != ADDON_LOADED_SIGNATURE


def _refresh_ui_visible():
    return bool(
        ADDON_REFRESH_PENDING
        or ADDON_REFRESH_LAST_STATE
        or ADDON_REFRESH_LAST_ERROR
    )


def _validate_source_files():
    for path in _source_files():
        with open(path, "rb") as handle:
            compile(handle.read(), path, "exec")


def _tag_view3d_redraw():
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _source_watch_deferred():
    global ADDON_REFRESH_LAST_STATE, ADDON_REFRESH_LAST_ERROR

    try:
        changed = _source_changed()
        if changed != ADDON_REFRESH_LAST_STATE:
            ADDON_REFRESH_LAST_STATE = changed
            _tag_view3d_redraw()
    except Exception as exc:
        ADDON_REFRESH_LAST_ERROR = f"Source watcher failed: {exc}"
        _tag_view3d_redraw()
    return 1.0


def _register_source_watch():
    global ADDON_REFRESH_LAST_STATE, ADDON_REFRESH_LAST_ERROR

    try:
        ADDON_REFRESH_LAST_STATE = _source_changed()
        if not bpy.app.timers.is_registered(_source_watch_deferred):
            bpy.app.timers.register(
                _source_watch_deferred,
                first_interval=1.0,
                persistent=True,
            )
    except Exception as exc:
        ADDON_REFRESH_LAST_ERROR = f"Source watcher failed: {exc}"
        print(f"[Character Designer] Could not start source watcher: {exc}")
        _tag_view3d_redraw()
        return False
    return True


def _unregister_source_watch():
    try:
        if bpy.app.timers.is_registered(_source_watch_deferred):
            bpy.app.timers.unregister(_source_watch_deferred)
    except Exception:
        pass


def _reload_addon_deferred():
    global ADDON_REFRESH_PENDING, ADDON_REFRESH_LAST_ERROR

    import addon_utils

    module_name = ADDON_MODULE_NAME
    old_modules = {
        name: module
        for name, module in list(sys.modules.items())
        if name == module_name or name.startswith(f"{module_name}.")
    }
    old_main = old_modules.get(module_name)
    persistent = bool(getattr(old_main, "__addon_persistent__", False)) if old_main else False

    try:
        try:
            addon_utils.disable(module_name, default_set=False, refresh_handled=True)
        except TypeError:
            addon_utils.disable(module_name, default_set=False)

        for name in old_modules:
            sys.modules.pop(name, None)
        importlib.invalidate_caches()

        try:
            reloaded = addon_utils.enable(
                module_name,
                default_set=False,
                persistent=persistent,
                refresh_handled=True,
            )
        except TypeError:
            reloaded = addon_utils.enable(
                module_name,
                default_set=False,
                persistent=persistent,
            )
        if reloaded is None:
            raise RuntimeError("Blender could not enable the refreshed add-on.")
        print("[Character Designer] Add-on refreshed successfully.")
    except Exception as exc:
        traceback.print_exc()
        for name in list(sys.modules):
            if name == module_name or name.startswith(f"{module_name}."):
                sys.modules.pop(name, None)
        sys.modules.update(old_modules)
        if old_main is not None:
            try:
                old_main.ADDON_REFRESH_PENDING = False
                old_main.ADDON_REFRESH_LAST_ERROR = str(exc)
                # register() is deliberately idempotent. If disable failed before
                # unregistering anything this is a no-op; if enable failed after a
                # successful disable it restores the old, known-good classes.
                old_main.register()
                old_main.__addon_enabled__ = True
            except Exception:
                traceback.print_exc()
        ADDON_REFRESH_PENDING = False
        ADDON_REFRESH_LAST_ERROR = str(exc)
    return None


def _mesh_object_poll(_self, obj):
    return obj is not None and obj.type == "MESH"


def _curve_object_poll(_self, obj):
    return obj is not None and obj.type == "CURVE"


class CharacterDesignerState(PropertyGroup):
    root_object: PointerProperty(
        name="Root Object",
        type=bpy.types.Object,
        poll=_mesh_object_poll,
        options={"SKIP_SAVE"},
    )
    root_mesh: PointerProperty(
        name="Root Mesh",
        type=bpy.types.Mesh,
        options={"SKIP_SAVE"},
    )
    root_indices_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_edges_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_ignored_indices_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_kind: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_capture_mode: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_vertex_count: IntProperty(default=0, min=0, options={"SKIP_SAVE"})
    root_ignored_count: IntProperty(default=0, min=0, options={"SKIP_SAVE"})
    topology_signature: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    output_object: PointerProperty(
        name="Output",
        type=bpy.types.Object,
        poll=_curve_object_poll,
        options={"SKIP_SAVE"},
    )
    last_level: StringProperty(default="NONE", options={"HIDDEN", "SKIP_SAVE"})
    last_message: StringProperty(options={"HIDDEN", "SKIP_SAVE"})


def _settings(context):
    window_manager = getattr(context, "window_manager", None)
    return getattr(window_manager, "character_designer", None)


def _set_status(settings, level, message):
    settings.last_level = level
    settings.last_message = message


def _clear_capture(settings):
    settings.root_object = None
    settings.root_mesh = None
    settings.root_indices_json = ""
    settings.root_edges_json = ""
    settings.root_ignored_indices_json = ""
    settings.root_kind = ""
    settings.root_capture_mode = ""
    settings.root_vertex_count = 0
    settings.root_ignored_count = 0
    settings.topology_signature = ""


def _edit_bmesh(context):
    obj = context.edit_object
    if obj is None or obj.type != "MESH" or obj.mode != "EDIT":
        raise CenterlineError("Enter Mesh Edit Mode on one hair object.")
    if context.object is not obj:
        raise CenterlineError("The edited hair object must be active.")

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.verts.index_update()
    bm.edges.index_update()
    bm.faces.index_update()
    return obj, bm


def _topology_signature(bm):
    digest = hashlib.sha256()
    digest.update(f"v{len(bm.verts)}e{len(bm.edges)}f{len(bm.faces)}|".encode("ascii"))
    edge_keys = sorted(
        (min(edge.verts[0].index, edge.verts[1].index), max(edge.verts[0].index, edge.verts[1].index))
        for edge in bm.edges
    )
    for first, second in edge_keys:
        digest.update(f"{first}:{second};".encode("ascii"))
    return digest.hexdigest()


def _indices_from_settings(settings):
    try:
        values = json.loads(settings.root_indices_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CenterlineError("The captured root is invalid. Capture it again.") from exc
    if not isinstance(values, list) or not values:
        raise CenterlineError("Capture a root slice first.")
    try:
        indices = tuple(sorted({int(value) for value in values}))
    except (TypeError, ValueError) as exc:
        raise CenterlineError("The captured root is invalid. Capture it again.") from exc
    if len(indices) != len(values):
        raise CenterlineError("The captured root is invalid. Capture it again.")
    return indices


def _ignored_indices_from_settings(settings):
    if not settings.root_ignored_indices_json:
        return ()
    try:
        values = json.loads(settings.root_ignored_indices_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CenterlineError("The captured cap interior is invalid. Capture the root again.") from exc
    if not isinstance(values, list):
        raise CenterlineError("The captured cap interior is invalid. Capture the root again.")
    try:
        indices = tuple(sorted({int(value) for value in values}))
    except (TypeError, ValueError) as exc:
        raise CenterlineError("The captured cap interior is invalid. Capture the root again.") from exc
    if len(indices) != len(values):
        raise CenterlineError("The captured cap interior is invalid. Capture the root again.")
    return indices


def _root_edges_from_settings(settings):
    try:
        values = json.loads(settings.root_edges_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CenterlineError("The captured root edges are invalid. Capture the root again.") from exc
    if not isinstance(values, list) or not values:
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")

    edge_keys = []
    try:
        for value in values:
            if not isinstance(value, list) or len(value) != 2:
                raise ValueError
            first, second = sorted((int(value[0]), int(value[1])))
            if first == second:
                raise ValueError
            edge_keys.append((first, second))
    except (TypeError, ValueError) as exc:
        raise CenterlineError("The captured root edges are invalid. Capture the root again.") from exc
    if len(set(edge_keys)) != len(edge_keys):
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")
    return tuple(sorted(edge_keys))


def _adjacency_from_edge_keys(vertex_indices, edge_keys):
    vertex_indices = set(vertex_indices)
    adjacency = {index: set() for index in vertex_indices}
    for first, second in edge_keys:
        if first in vertex_indices and second in vertex_indices:
            adjacency[first].add(second)
            adjacency[second].add(first)
    return adjacency


def _selected_edge_keys(bm, vertex_indices):
    vertex_indices = set(vertex_indices)
    edge_keys = []
    for edge in bm.edges:
        if not edge.select:
            continue
        first = edge.verts[0].index
        second = edge.verts[1].index
        if first in vertex_indices and second in vertex_indices:
            edge_keys.append(tuple(sorted((first, second))))
    return tuple(sorted(edge_keys))


def _is_connected(indices, adjacency):
    indices = set(indices)
    if not indices:
        return False
    visited = set()
    queue = deque((next(iter(indices)),))
    while queue:
        current = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        queue.extend((adjacency[current] & indices) - visited)
    return visited == indices


def _classify_slice(indices, adjacency, *, label):
    indices = set(indices)
    count = len(indices)
    if count == 1:
        return "POINT"
    if not _is_connected(indices, adjacency):
        raise CenterlineError(f"{label} is split into multiple pieces.")

    degrees = {index: len(adjacency[index] & indices) for index in indices}
    edge_count = sum(degrees.values()) // 2
    if count >= 3 and edge_count == count and all(value == 2 for value in degrees.values()):
        return "CLOSED"
    if edge_count == count - 1:
        end_count = sum(value == 1 for value in degrees.values())
        middle_ok = all(value in {1, 2} for value in degrees.values())
        if end_count == 2 and middle_ok:
            return "OPEN"
    raise CenterlineError(
        f"{label} branches or is not one simple row/loop. Select one clean cross-section."
    )


def _root_label(kind):
    return "closed loop" if kind == "CLOSED" else "open row"


def _captured_root_label(settings):
    if settings.root_capture_mode in {"CAP", "FAN_CAP", "TRI_CAP", "REGION_CAP"}:
        return "cap boundary"
    return _root_label(settings.root_kind)


def _slice_edge_keys(indices, adjacency):
    indices = set(indices)
    return {
        tuple(sorted((first, second)))
        for first in indices
        for second in adjacency[first] & indices
        if first < second
    }


def _validate_face_bands(bm, selected, layers, distances, adjacency):
    """Confirm that graph layers are backed by complete quad surface bands."""

    final_layer_index = len(layers) - 1
    band_faces = defaultdict(list)
    relevant_band_faces = set()
    for face in bm.faces:
        indices = tuple(vertex.index for vertex in face.verts)
        if not all(index in selected for index in indices):
            continue
        face_layers = {distances[index] for index in indices}
        if len(face_layers) == 1:
            layer_index = next(iter(face_layers))
            if layer_index not in {0, final_layer_index}:
                raise CenterlineError(
                    f"Layer {layer_index + 1} contains an internal cap face."
                )
            continue
        if len(face_layers) != 2:
            raise CenterlineError("A selected face crosses more than one layer.")

        lower_layer = min(face_layers)
        upper_layer = max(face_layers)
        if upper_layer != lower_layer + 1:
            raise CenterlineError("A selected face skips a centerline layer.")
        lower_vertices = tuple(index for index in indices if distances[index] == lower_layer)
        upper_vertices = tuple(index for index in indices if distances[index] == upper_layer)
        upper_is_point = len(layers[upper_layer]) == 1
        valid_counts = (
            len(face.verts) == 3
            and len(lower_vertices) == 2
            and len(upper_vertices) == 1
        ) if upper_is_point else (
            len(face.verts) == 4
            and len(lower_vertices) == 2
            and len(upper_vertices) == 2
        )
        if not valid_counts:
            expected = "a 2+1 tip triangle" if upper_is_point else "a 2+2 quad"
            raise CenterlineError(
                f"The band between layers {lower_layer + 1} and {upper_layer + 1} "
                f"contains a face that is not {expected}."
            )

        face_edges = {
            tuple(sorted((edge.verts[0].index, edge.verts[1].index)))
            for edge in face.edges
        }
        lower_edge = tuple(sorted(lower_vertices))
        if lower_edge not in face_edges or lower_edge not in _slice_edge_keys(
            layers[lower_layer], adjacency
        ):
            raise CenterlineError(
                f"A face between layers {lower_layer + 1} and {upper_layer + 1} is twisted."
            )
        upper_edge = None
        if not upper_is_point:
            upper_edge = tuple(sorted(upper_vertices))
            if upper_edge not in face_edges or upper_edge not in _slice_edge_keys(
                layers[upper_layer], adjacency
            ):
                raise CenterlineError(
                    f"A face between layers {lower_layer + 1} and {upper_layer + 1} is twisted."
                )
        band_faces[lower_layer].append((lower_edge, upper_edge))
        relevant_band_faces.add(face)

    # The undirected edge/face counts above cannot distinguish a coherent band
    # from one containing a flipped polygon.  Check every shared band edge with
    # BMesh's winding-aware manifold predicate before any normals are averaged
    # into persistent orientation metadata.
    for edge in bm.edges:
        linked_band_faces = [
            face for face in edge.link_faces if face in relevant_band_faces
        ]
        if len(linked_band_faces) > 2:
            first, second = sorted(vertex.index for vertex in edge.verts)
            raise CenterlineError(
                f"Selected side-band edge {first}-{second} is non-manifold."
            )
        if len(linked_band_faces) == 2:
            first, second = sorted(vertex.index for vertex in edge.verts)
            if not edge.is_manifold:
                raise CenterlineError(
                    f"Selected side-band edge {first}-{second} is non-manifold."
                )
            if not edge.is_contiguous:
                raise CenterlineError(
                    "Selected side-band faces have inconsistent winding across "
                    f"edge {first}-{second}."
                )

    for lower_layer in range(final_layer_index):
        upper_layer = lower_layer + 1
        expected_lower_edges = _slice_edge_keys(layers[lower_layer], adjacency)
        actual_faces = band_faces.get(lower_layer, [])
        actual_lower_edges = [lower_edge for lower_edge, _upper_edge in actual_faces]
        if (
            len(actual_faces) != len(expected_lower_edges)
            or set(actual_lower_edges) != expected_lower_edges
            or len(set(actual_lower_edges)) != len(actual_lower_edges)
        ):
            raise CenterlineError(
                f"Layers {lower_layer + 1} and {upper_layer + 1} do not have one complete face band."
            )

        if len(layers[upper_layer]) > 1:
            expected_upper_edges = _slice_edge_keys(layers[upper_layer], adjacency)
            actual_upper_edges = [upper_edge for _lower_edge, upper_edge in actual_faces]
            if (
                set(actual_upper_edges) != expected_upper_edges
                or len(set(actual_upper_edges)) != len(actual_upper_edges)
            ):
                raise CenterlineError(
                    f"Layers {lower_layer + 1} and {upper_layer + 1} have mismatched quad faces."
                )


def _selection_counts(bm):
    return (
        sum(vertex.select for vertex in bm.verts),
        sum(edge.select for edge in bm.edges),
        sum(face.select for face in bm.faces),
    )


def _selected_faces_are_one_edge_component(selected_faces):
    face_set = set(selected_faces)
    visited = set()
    queue = deque((selected_faces[0],))
    while queue:
        face = queue.popleft()
        if face in visited:
            continue
        visited.add(face)
        for edge in face.edges:
            queue.extend(
                linked_face
                for linked_face in edge.link_faces
                if linked_face in face_set and linked_face not in visited
            )
    return visited == face_set


def _capture_selected_face_boundary(bm, selected_faces):
    """Extract one cap boundary from a face-connected topological disk.

    The selected faces may use any polygon sizes, but their complete boundary
    must meet one provably regular, unselected side band.  That positive collar
    test is important: a whole card, a partial card, and one arbitrary side face
    can all be topological disks too, but none is the cap of a regular tube.
    """

    selected_faces = tuple(selected_faces)
    if not _selected_faces_are_one_edge_component(selected_faces):
        raise CenterlineError("The selected cap contains multiple disconnected face islands.")

    region_vertices = {vertex for face in selected_faces for vertex in face.verts}
    region_edges = {edge for face in selected_faces for edge in face.edges}
    extra_vertices = {vertex for vertex in bm.verts if vertex.select} - region_vertices
    extra_edges = {edge for edge in bm.edges if edge.select} - region_edges
    if extra_vertices or extra_edges:
        raise CenterlineError("Do not mix a cap selection with extra vertices or edges.")

    face_incidence = defaultdict(int)
    for face in selected_faces:
        for edge in face.edges:
            face_incidence[edge] += 1
    if any(count > 2 for count in face_incidence.values()):
        raise CenterlineError("The selected cap contains a non-manifold shared edge.")
    if any(len(edge.link_faces) > 2 for edge in region_edges):
        raise CenterlineError("The selected cap touches non-manifold mesh geometry.")

    boundary_edges = {edge for edge, count in face_incidence.items() if count == 1}
    if not boundary_edges:
        raise CenterlineError("The selected cap has no open boundary.")
    boundary_vertices = {vertex for edge in boundary_edges for vertex in edge.verts}
    boundary_edge_keys = tuple(
        sorted(
            tuple(sorted((edge.verts[0].index, edge.verts[1].index)))
            for edge in boundary_edges
        )
    )
    boundary_indices = tuple(sorted(vertex.index for vertex in boundary_vertices))
    boundary_adjacency = _adjacency_from_edge_keys(boundary_indices, boundary_edge_keys)
    try:
        boundary_kind = _classify_slice(
            boundary_indices,
            boundary_adjacency,
            label="The cap boundary",
        )
    except CenterlineError as exc:
        raise CenterlineError("The selected cap must have exactly one simple boundary loop.") from exc
    if boundary_kind != "CLOSED":
        raise CenterlineError("The selected cap boundary is not closed.")

    interior_vertices = region_vertices - boundary_vertices
    if len(region_vertices) - len(region_edges) + len(selected_faces) != 1:
        raise CenterlineError("The selected faces are not one topological disk.")

    # Every enclosed vertex must really be enclosed by the selected region.  An
    # unselected incident edge means that the artist selected only part of a
    # larger triangulated surface and the apparent boundary is misleading.
    if any(
        edge not in region_edges
        for vertex in interior_vertices
        for edge in vertex.link_edges
    ):
        raise CenterlineError(
            "A cap interior vertex is connected to geometry outside the selected region."
        )

    # A cap boundary vertex has exactly one longitudinal edge into the first
    # unselected side band.  This gives an explicit boundary -> next-layer map,
    # rather than trying to infer cap semantics from polygon sizes.
    next_vertex_by_boundary = {}
    leaving_edge_by_boundary = {}
    for vertex in boundary_vertices:
        leaving_edges = [edge for edge in vertex.link_edges if edge not in region_edges]
        if len(leaving_edges) != 1:
            raise CenterlineError(
                "The selected face region has no complete regular first collar: "
                "each cap boundary vertex needs exactly one outgoing side edge."
            )
        leaving_edge = leaving_edges[0]
        next_vertex = leaving_edge.other_vert(vertex)
        if next_vertex in region_vertices:
            raise CenterlineError(
                "The selected face region has an extra chord instead of a regular first collar."
            )
        leaving_edge_by_boundary[vertex] = leaving_edge
        next_vertex_by_boundary[vertex] = next_vertex

    next_vertices = set(next_vertex_by_boundary.values())
    normal_collar = len(next_vertices) == len(boundary_vertices)
    collapsed_collar = len(next_vertices) == 1
    if not normal_collar and not collapsed_collar:
        raise CenterlineError(
            "The selected cap collar branches between its boundary and the next layer."
        )

    # Every boundary edge must own exactly one outside band face.  For a normal
    # collar that face is the exact quad (root edge, two longitudinal edges,
    # outer edge); a uniformly collapsed collar uses one triangle and a shared
    # point tip.  Checking edge sets as well as vertices rejects twisted faces.
    selected_face_set = set(selected_faces)
    outside_face_use = defaultdict(int)
    outer_edge_keys = []
    for edge in boundary_edges:
        first, second = edge.verts
        next_first = next_vertex_by_boundary[first]
        next_second = next_vertex_by_boundary[second]
        outside_faces = [face for face in edge.link_faces if face not in selected_face_set]
        if len(outside_faces) != 1:
            raise CenterlineError(
                "The selected face region has no complete regular first collar: "
                "every cap edge must meet one unselected side face."
            )
        outside_face = outside_faces[0]
        outside_face_use[outside_face] += 1

        expected_vertices = {first, second, next_first, next_second}
        expected_edge_keys = {
            tuple(sorted((first.index, second.index))),
            tuple(sorted((first.index, next_first.index))),
            tuple(sorted((second.index, next_second.index))),
        }
        if normal_collar:
            expected_edge_keys.add(tuple(sorted((next_first.index, next_second.index))))
            expected_face_size = 4
        else:
            expected_face_size = 3
        actual_edge_keys = {
            tuple(sorted((face_edge.verts[0].index, face_edge.verts[1].index)))
            for face_edge in outside_face.edges
        }
        if (
            len(outside_face.verts) != expected_face_size
            or set(outside_face.verts) != expected_vertices
            or actual_edge_keys != expected_edge_keys
        ):
            expected_label = "quad" if normal_collar else "tip triangle"
            raise CenterlineError(
                f"The first collar needs one untwisted {expected_label} per cap boundary edge."
            )
        if leaving_edge_by_boundary[first] not in outside_face.edges or (
            leaving_edge_by_boundary[second] not in outside_face.edges
        ):
            raise CenterlineError("A first-collar face does not use its mapped side edges.")
        if normal_collar:
            outer_edge_keys.append(tuple(sorted((next_first.index, next_second.index))))

    if any(count != 1 for count in outside_face_use.values()):
        raise CenterlineError(
            "Each first-collar face must correspond to exactly one cap boundary edge."
        )

    if normal_collar:
        next_indices = tuple(sorted(vertex.index for vertex in next_vertices))
        outer_adjacency = _adjacency_from_edge_keys(next_indices, outer_edge_keys)
        try:
            outer_kind = _classify_slice(
                next_indices,
                outer_adjacency,
                label="The first collar outer edge",
            )
        except CenterlineError as exc:
            raise CenterlineError(
                "The first collar outer edges do not form one simple closed loop."
            ) from exc
        if outer_kind != "CLOSED":
            raise CenterlineError(
                "The first collar outer edges do not form one simple closed loop."
            )

    ignored_indices = tuple(sorted(vertex.index for vertex in interior_vertices))
    return boundary_indices, boundary_edge_keys, ignored_indices, "REGION_CAP"


def _capture_data(context):
    obj, bm = _edit_bmesh(context)
    selected_faces = tuple(face for face in bm.faces if face.select)
    if selected_faces:
        root_indices, edge_keys, ignored_indices, capture_mode = _capture_selected_face_boundary(
            bm,
            selected_faces,
        )
        return obj, bm, root_indices, edge_keys, "CLOSED", ignored_indices, capture_mode

    selected = {vertex.index for vertex in bm.verts if vertex.select}
    if len(selected) < 2:
        raise CenterlineError("Select one root edge row or one root cap face, then capture.")

    edge_keys = _selected_edge_keys(bm, selected)
    adjacency = _adjacency_from_edge_keys(selected, edge_keys)
    kind = _classify_slice(selected, adjacency, label="The root selection")
    if kind == "POINT":
        raise CenterlineError("The root needs at least two vertices; a point is supported only at the tip.")
    return obj, bm, tuple(sorted(selected)), edge_keys, kind, (), "EDGES"


def _validate_capture(context, settings):
    obj, bm = _edit_bmesh(context)
    if settings.root_object is None:
        raise CenterlineError("Capture a root slice first.")
    if obj is not settings.root_object or obj.data is not settings.root_mesh:
        raise CenterlineError("Return to the captured hair object, or capture a new root.")
    if _topology_signature(bm) != settings.topology_signature:
        raise CenterlineError("Hair topology changed after capture. Capture the root again.")

    root_indices = _indices_from_settings(settings)
    root_edge_keys = _root_edges_from_settings(settings)
    ignored_indices = _ignored_indices_from_settings(settings)
    if root_indices[-1] >= len(bm.verts) or (
        ignored_indices and ignored_indices[-1] >= len(bm.verts)
    ):
        raise CenterlineError("Hair topology changed after capture. Capture the root again.")
    root_set = set(root_indices)
    ignored_set = set(ignored_indices)
    if root_set & ignored_set:
        raise CenterlineError("The captured cap boundary overlaps its interior. Capture it again.")
    if any(first not in root_set or second not in root_set for first, second in root_edge_keys):
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")
    adjacency = _adjacency_from_edge_keys(root_set, root_edge_keys)
    kind = _classify_slice(root_set, adjacency, label="The captured root")
    if kind != settings.root_kind:
        raise CenterlineError("The captured root topology changed. Capture it again.")
    return obj, bm, root_indices, root_edge_keys, ignored_indices


def _extract_layers(context, settings):
    obj, bm, root_indices, root_edge_keys, ignored_indices = _validate_capture(
        context,
        settings,
    )
    ignored_set = set(ignored_indices)
    selected = {
        vertex.index
        for vertex in bm.verts
        if vertex.select and vertex.index not in ignored_set
    }
    root_set = set(root_indices)
    missing = root_set - selected
    if missing:
        raise CenterlineError("Keep the captured root selected while growing toward the tip.")
    if selected == root_set:
        raise CenterlineError("Only the root is selected. Grow the selection toward the tip.")

    selected_edge_keys = [
        edge_key
        for edge_key in _selected_edge_keys(bm, selected)
        if not (edge_key[0] in root_set and edge_key[1] in root_set)
    ]
    selected_edge_keys.extend(root_edge_keys)
    adjacency = _adjacency_from_edge_keys(selected, selected_edge_keys)
    distances = {index: 0 for index in root_set}
    queue = deque(root_indices)
    while queue:
        current = queue.popleft()
        next_distance = distances[current] + 1
        for neighbor in adjacency[current]:
            if neighbor not in distances:
                distances[neighbor] = next_distance
                queue.append(neighbor)
    unreachable = selected - distances.keys()
    if unreachable:
        raise CenterlineError(
            f"The selection contains {len(unreachable)} vertex/vertices disconnected from the root."
        )

    grouped = defaultdict(list)
    for index, distance in distances.items():
        grouped[distance].append(index)
    layers = [tuple(sorted(grouped[distance])) for distance in range(max(grouped) + 1)]
    if set(layers[0]) != root_set:
        raise CenterlineError("The captured root could not be reconstructed. Capture it again.")

    for layer_index, layer in enumerate(layers):
        kind = _classify_slice(
            layer,
            adjacency,
            label=f"Layer {layer_index + 1}",
        )
        is_last = layer_index == len(layers) - 1
        if kind == "POINT":
            if not is_last:
                raise CenterlineError(
                    f"Layer {layer_index + 1} is a point before the tip. The selection branches after it."
                )
        elif kind != settings.root_kind:
            raise CenterlineError(
                f"Layer {layer_index + 1} changes from {_root_label(settings.root_kind)} "
                f"to {_root_label(kind)}. Check the selection."
            )

        if layer_index == 0:
            continue
        previous = set(layers[layer_index - 1])
        current = set(layer)
        cross_edges = []
        for previous_index in previous:
            for current_index in adjacency[previous_index] & current:
                cross_edges.append((previous_index, current_index))

        previous_degree = defaultdict(int)
        current_degree = defaultdict(int)
        for previous_index, current_index in cross_edges:
            previous_degree[previous_index] += 1
            current_degree[current_index] += 1

        if len(current) == 1:
            # A collapsed point tip is valid only when every vertex in the last
            # regular slice connects directly to that one final vertex.
            complete = (
                is_last
                and len(cross_edges) == len(previous)
                and all(previous_degree[index] == 1 for index in previous)
                and current_degree[next(iter(current))] == len(previous)
            )
        else:
            # The artist's source is a regular quad strip/tube. One-to-one
            # longitudinal edges make each graph-distance layer unambiguous;
            # many-to-many links would let BFS hide a branch or triangulated
            # shortcut inside an apparently valid row.
            complete = (
                len(previous) == len(current) == len(cross_edges)
                and all(previous_degree[index] == 1 for index in previous)
                and all(current_degree[index] == 1 for index in current)
            )
        if not complete:
            raise CenterlineError(
                f"Layers {layer_index} and {layer_index + 1} do not form one regular quad band."
            )

    _validate_face_bands(bm, selected, layers, distances, adjacency)

    _validate_layer_coordinates(bm, layers)
    _validate_source_matrix(obj)
    centers = []
    for layer_index, layer in enumerate(layers):
        center = sum((bm.verts[index].co for index in layer), Vector((0.0, 0.0, 0.0))) / len(layer)
        if not _vector_is_finite(center):
            raise CenterlineError(
                f"Layer {layer_index + 1} has a non-finite center point."
            )
        if centers and (center - centers[-1]).length <= EPSILON:
            raise CenterlineError(
                f"Layers {layer_index} and {layer_index + 1} have the same center point."
            )
        centers.append(center.copy())
    return obj, bm, tuple(layers), tuple(centers)


def _is_finite_number(value):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(float(value))
    except (OverflowError, TypeError, ValueError):
        return False


def _vector_is_finite(value):
    try:
        return len(value) == 3 and all(_is_finite_number(component) for component in value)
    except TypeError:
        return False


def _validate_layer_coordinates(bm, layers):
    for layer_index, layer in enumerate(layers):
        for vertex_index in layer:
            if not _vector_is_finite(bm.verts[vertex_index].co):
                raise CenterlineError(
                    f"Layer {layer_index + 1} vertex {vertex_index} has non-finite coordinates."
                )


def _validate_source_matrix(source_obj):
    for row in range(4):
        for column in range(4):
            if not _is_finite_number(source_obj.matrix_world[row][column]):
                raise CenterlineError(
                    "The source object transform has a non-finite value at "
                    f"row {row + 1}, column {column + 1}."
                )


def _unit_vector_or_none(value):
    value = Vector(value)
    if value.length <= EPSILON:
        return None
    return value.normalized()


def _project_to_normal_plane(value, normal):
    value = Vector(value)
    normal = Vector(normal)
    return _unit_vector_or_none(value - normal * value.dot(normal))


def _vector_json(value):
    return [float(value.x), float(value.y), float(value.z)] if value is not None else None


def _layer_diameter(bm, layer):
    """Return the exact, deterministic maximum vertex chord for one layer."""

    if len(layer) == 1:
        return 0.0, None, None

    best_distance_squared = -1.0
    best_pair = None
    best_vector = None
    ordered = tuple(sorted(layer))
    for position, first in enumerate(ordered[:-1]):
        for second in ordered[position + 1 :]:
            chord = bm.verts[second].co - bm.verts[first].co
            distance_squared = chord.length_squared
            # Iteration is lexicographic, so an exact tie deliberately keeps
            # the first pair and produces the same result on every build.
            if distance_squared > best_distance_squared:
                best_distance_squared = distance_squared
                best_pair = (first, second)
                best_vector = chord.copy()
    return best_distance_squared ** 0.5, best_pair, best_vector


def _layer_profile_span(bm, layer, tangent):
    """Return the maximum vertex chord after projection normal to the tangent."""

    if len(layer) == 1:
        return 0.0, None, None

    best_distance_squared = -1.0
    best_pair = None
    best_vector = None
    ordered = tuple(sorted(layer))
    for position, first in enumerate(ordered[:-1]):
        for second in ordered[position + 1 :]:
            chord = bm.verts[second].co - bm.verts[first].co
            projected = chord - tangent * chord.dot(tangent)
            distance_squared = projected.length_squared
            if distance_squared > best_distance_squared:
                best_distance_squared = distance_squared
                best_pair = (first, second)
                best_vector = projected.copy()
    return best_distance_squared ** 0.5, best_pair, best_vector


def _center_tangents(centers):
    if len(centers) < 2:
        raise CenterlineError("A center curve needs at least two points.")

    tangents = []
    final_index = len(centers) - 1
    for index, center in enumerate(centers):
        if index == 0:
            tangent = _unit_vector_or_none(centers[1] - center)
        elif index == final_index:
            tangent = _unit_vector_or_none(center - centers[index - 1])
        else:
            incoming = _unit_vector_or_none(center - centers[index - 1])
            outgoing = _unit_vector_or_none(centers[index + 1] - center)
            tangent = _unit_vector_or_none(incoming + outgoing)
            if tangent is None:
                # A perfect 180-degree reversal has no bisector. The outgoing
                # segment is deterministic and keeps the frame well defined.
                tangent = outgoing
        if tangent is None:
            raise CenterlineError(f"Center point {index + 1} has no usable tangent.")
        tangents.append(tangent)
    return tuple(tangents)


def _deterministic_perpendicular(tangent):
    basis = min(
        (Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0))),
        key=lambda axis: abs(axis.dot(tangent)),
    )
    result = _project_to_normal_plane(basis, tangent)
    if result is None:
        raise CenterlineError("Could not construct a stable orientation frame.")
    return result


def _transport_axis(axis, previous_tangent, tangent):
    try:
        transported = previous_tangent.rotation_difference(tangent) @ axis
    except ValueError:
        transported = axis
    transported = _project_to_normal_plane(transported, tangent)
    return transported if transported is not None else _deterministic_perpendicular(tangent)


def _track_layer_anchors(bm, layers, profile_span_pairs):
    neighbors = defaultdict(set)
    relevant = {index for layer in layers for index in layer}
    for edge in bm.edges:
        first = edge.verts[0].index
        second = edge.verts[1].index
        if first in relevant and second in relevant:
            neighbors[first].add(second)
            neighbors[second].add(first)

    anchors = []
    for layer_index, (layer, profile_span_pair) in enumerate(
        zip(layers, profile_span_pairs)
    ):
        if len(layer) == 1:
            anchors.append(None)
            continue
        if layer_index == 0 or anchors[-1] is None:
            anchors.append(profile_span_pair[0] if profile_span_pair else min(layer))
            continue

        candidates = sorted(neighbors[anchors[-1]] & set(layer))
        # Regular-band validation guarantees one longitudinal match. Keep a
        # deterministic fallback so metadata construction never invents a
        # random orientation if malformed data somehow reaches this helper.
        anchors.append(
            candidates[0]
            if len(candidates) == 1
            else (profile_span_pair[0] if profile_span_pair else min(layer))
        )
    return tuple(anchors)


def _layer_band_normals(bm, layers):
    """Area-weight adjacent selected-band normals into one local vector/layer."""

    bm.normal_update()
    layer_by_vertex = {
        vertex_index: layer_index
        for layer_index, layer in enumerate(layers)
        for vertex_index in layer
    }
    weighted_normals = [Vector((0.0, 0.0, 0.0)) for _layer in layers]
    total_areas = [0.0 for _layer in layers]
    face_counts = [0 for _layer in layers]

    for face in bm.faces:
        indices = tuple(vertex.index for vertex in face.verts)
        if any(index not in layer_by_vertex for index in indices):
            continue
        face_layers = {layer_by_vertex[index] for index in indices}
        if len(face_layers) != 2 or max(face_layers) - min(face_layers) != 1:
            # Same-layer cap faces do not describe profile roll.
            continue
        area = face.calc_area()
        if area <= 0.0 or face.normal.length <= EPSILON:
            continue
        weighted = face.normal * area
        for layer_index in face_layers:
            weighted_normals[layer_index] += weighted
            total_areas[layer_index] += area
            face_counts[layer_index] += 1

    results = []
    for weighted, total_area, face_count in zip(weighted_normals, total_areas, face_counts):
        # A closed tube's radial side normals cancel. Relative cancellation is
        # intentional and signals that the tracked profile-span anchor must carry
        # roll instead of an unstable near-zero average.
        meaningful = total_area > 0.0 and weighted.length > total_area * 1.0e-6
        results.append(
            (
                weighted.normalized() if meaningful else None,
                face_count,
            )
        )
    return tuple(results)


def _build_cross_section_metadata(source_obj, bm, layers, centers, regular_kind):
    """Capture lossless sizing and a stable local frame without shaping the Curve."""

    _validate_source_matrix(source_obj)
    diameters = tuple(_layer_diameter(bm, layer) for layer in layers)
    widths = tuple(value[0] for value in diameters)
    diameter_pairs = tuple(value[1] for value in diameters)
    diameter_vectors = tuple(value[2] for value in diameters)
    tangents = _center_tangents(centers)
    profile_spans = tuple(
        _layer_profile_span(bm, layer, tangent)
        for layer, tangent in zip(layers, tangents)
    )
    profile_span_values = tuple(value[0] for value in profile_spans)
    profile_span_pairs = tuple(value[1] for value in profile_spans)
    profile_span_vectors = tuple(value[2] for value in profile_spans)
    anchors = _track_layer_anchors(bm, layers, profile_span_pairs)
    band_normals = _layer_band_normals(bm, layers)

    sections = []
    previous_axis = None
    previous_tangent = None
    for layer_index, layer in enumerate(layers):
        tangent = tangents[layer_index]
        diameter_pair = diameter_pairs[layer_index]
        diameter_vector = diameter_vectors[layer_index]
        profile_span_pair = profile_span_pairs[layer_index]
        profile_span_vector = profile_span_vectors[layer_index]
        anchor = anchors[layer_index]
        mesh_normal, band_face_count = band_normals[layer_index]
        mesh_roll_normal = (
            _project_to_normal_plane(mesh_normal, tangent)
            if mesh_normal is not None
            else None
        )

        if len(layer) == 1:
            if previous_axis is None or previous_tangent is None:
                axis = _deterministic_perpendicular(tangent)
                axis_source = "DETERMINISTIC"
            else:
                axis = _transport_axis(previous_axis, previous_tangent, tangent)
                axis_source = "TRANSPORTED"
            frame_normal = _unit_vector_or_none(tangent.cross(axis))
            orientation_source = "TRANSPORTED_TIP"
            kind = "POINT"
        else:
            axis = _project_to_normal_plane(profile_span_vector, tangent)
            axis_source = "PROFILE_SPAN"

            anchor_axis = (
                _project_to_normal_plane(bm.verts[anchor].co - centers[layer_index], tangent)
                if anchor is not None
                else None
            )
            if axis is None:
                axis = anchor_axis
                axis_source = "ANCHOR"
            if axis is None:
                axis = _deterministic_perpendicular(tangent)
                axis_source = "DETERMINISTIC"

            # Give the otherwise unoriented profile span a stable sign, first from
            # its tracked mesh column and then from the transported prior frame.
            if anchor_axis is not None and axis.dot(anchor_axis) < 0.0:
                axis.negate()
            if previous_axis is not None and previous_tangent is not None:
                transported = _transport_axis(previous_axis, previous_tangent, tangent)
                if axis.dot(transported) < 0.0:
                    axis.negate()

            frame_normal = _unit_vector_or_none(tangent.cross(axis))
            if frame_normal is None:
                axis = _deterministic_perpendicular(tangent)
                frame_normal = _unit_vector_or_none(tangent.cross(axis))
                axis_source = "DETERMINISTIC"

            if mesh_roll_normal is not None:
                # Preserve the source face winding when it supplies a useful
                # roll direction. The raw area-weighted normal is stored too.
                if frame_normal.dot(mesh_roll_normal) < 0.0:
                    axis.negate()
                    frame_normal.negate()
                orientation_source = "MESH_NORMAL"
            else:
                orientation_source = "PROFILE_ANCHOR"
            kind = regular_kind

        sections.append(
            {
                "kind": kind,
                "max_width_local": float(widths[layer_index]),
                "diameter_pair": list(diameter_pair) if diameter_pair is not None else None,
                "diameter_vector_local": _vector_json(diameter_vector),
                "max_profile_span_local": float(profile_span_values[layer_index]),
                "profile_span_pair": (
                    list(profile_span_pair) if profile_span_pair is not None else None
                ),
                "profile_span_vector_local": _vector_json(profile_span_vector),
                "anchor_vertex": int(anchor) if anchor is not None else None,
                "tangent_local": _vector_json(tangent),
                "width_axis_local": _vector_json(axis),
                "normal_local": _vector_json(frame_normal),
                "mesh_normal_local": _vector_json(mesh_normal),
                "band_face_count": int(band_face_count),
                "width_axis_source": axis_source,
                "orientation_source": orientation_source,
            }
        )
        previous_axis = axis.copy()
        previous_tangent = tangent.copy()

    return {
        "version": METADATA_VERSION,
        "space": METADATA_SPACE,
        "point_count": len(centers),
        "matrix_world_at_build": [
            float(source_obj.matrix_world[row][column])
            for row in range(4)
            for column in range(4)
        ],
        "sections": sections,
    }


def _reject_json_constant(value):
    raise ValueError(f"Non-finite JSON constant: {value}")


def _metadata_pair_is_valid(value):
    return (
        isinstance(value, list)
        and len(value) == 2
        and all(isinstance(index, int) and not isinstance(index, bool) and index >= 0 for index in value)
        and value[0] != value[1]
    )


def _metadata_vector_is_valid(value, *, allow_none=False, require_nonzero=False):
    if value is None:
        return allow_none
    if not isinstance(value, list) or not _vector_is_finite(value):
        return False
    if require_nonzero and not any(abs(float(component)) > EPSILON for component in value):
        return False
    return True


def _metadata_section_is_valid(section, *, is_last):
    if not isinstance(section, dict):
        return False

    kind = section.get("kind")
    if kind not in {"OPEN", "CLOSED", "POINT"} or (kind == "POINT" and not is_last):
        return False
    for key in ("max_width_local", "max_profile_span_local"):
        value = section.get(key)
        if not _is_finite_number(value) or float(value) < 0.0:
            return False

    is_point = kind == "POINT"
    diameter_pair = section.get("diameter_pair")
    profile_span_pair = section.get("profile_span_pair")
    if is_point:
        if diameter_pair is not None or profile_span_pair is not None:
            return False
        if section.get("diameter_vector_local") is not None or (
            section.get("profile_span_vector_local") is not None
        ):
            return False
        if section.get("anchor_vertex") is not None:
            return False
    else:
        if not _metadata_pair_is_valid(diameter_pair) or not _metadata_pair_is_valid(
            profile_span_pair
        ):
            return False
        if not _metadata_vector_is_valid(section.get("diameter_vector_local")) or not (
            _metadata_vector_is_valid(section.get("profile_span_vector_local"))
        ):
            return False
        anchor = section.get("anchor_vertex")
        if not isinstance(anchor, int) or isinstance(anchor, bool) or anchor < 0:
            return False

    for key in ("tangent_local", "width_axis_local", "normal_local"):
        if not _metadata_vector_is_valid(
            section.get(key),
            require_nonzero=True,
        ):
            return False
    if not _metadata_vector_is_valid(
        section.get("mesh_normal_local"),
        allow_none=True,
        require_nonzero=True,
    ):
        return False

    face_count = section.get("band_face_count")
    if not isinstance(face_count, int) or isinstance(face_count, bool) or face_count < 0:
        return False
    if section.get("width_axis_source") not in {
        "PROFILE_SPAN",
        "ANCHOR",
        "DETERMINISTIC",
        "TRANSPORTED",
    }:
        return False
    if section.get("orientation_source") not in {
        "MESH_NORMAL",
        "PROFILE_ANCHOR",
        "TRANSPORTED_TIP",
    }:
        return False
    return True


def _curve_cross_section_metadata(curve_obj):
    if curve_obj is None or curve_obj.type != "CURVE":
        return None
    if curve_obj.get("character_designer_metadata_version") != METADATA_VERSION:
        return None
    try:
        metadata = json.loads(
            curve_obj.get("character_designer_cross_sections", ""),
            parse_constant=_reject_json_constant,
        )
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if (
        not isinstance(metadata, dict)
        or metadata.get("version") != METADATA_VERSION
        or metadata.get("space") != METADATA_SPACE
    ):
        return None

    sections = metadata.get("sections")
    point_count = metadata.get("point_count")
    if (
        not isinstance(sections, list)
        or not isinstance(point_count, int)
        or isinstance(point_count, bool)
        or point_count < 2
        or point_count != len(sections)
    ):
        return None
    matrix = metadata.get("matrix_world_at_build")
    if (
        not isinstance(matrix, list)
        or len(matrix) != 16
        or not all(_is_finite_number(value) for value in matrix)
    ):
        return None
    if any(
        not _metadata_section_is_valid(section, is_last=index == point_count - 1)
        for index, section in enumerate(sections)
    ):
        return None

    splines = curve_obj.data.splines
    if len(splines) != 1 or splines[0].type != "POLY" or len(splines[0].points) != point_count:
        return None
    return metadata


def _metadata_summary(metadata):
    sections = metadata.get("sections", ()) if metadata else ()
    # A point tip correctly stores zero span, but including that zero in the
    # visible range hides the useful size range of the actual cross-sections.
    # Keep the lossless zero in JSON and summarize only non-point layers.
    profile_spans = [
        section.get("max_profile_span_local")
        for section in sections
        if section.get("kind") != "POINT"
    ]
    profile_spans = [
        float(span) for span in profile_spans if isinstance(span, (int, float))
    ]
    if not profile_spans:
        return None

    mesh_count = sum(
        section.get("orientation_source") == "MESH_NORMAL"
        for section in sections
    )
    tip_count = sum(
        section.get("orientation_source") == "TRANSPORTED_TIP"
        for section in sections
    )
    fallback_count = len(sections) - mesh_count - tip_count
    return {
        "minimum_profile_span": min(profile_spans),
        "maximum_profile_span": max(profile_spans),
        "root_profile_span": float(sections[0]["max_profile_span_local"]),
        "tip_profile_span": float(sections[-1]["max_profile_span_local"]),
        "mesh_count": mesh_count,
        "tracked_count": fallback_count,
        "tip_count": tip_count,
    }


def _compact_number(value):
    return "0" if abs(value) <= EPSILON else f"{value:.5g}"


def _visible_collections(context):
    visible_collections = set()

    def visit(layer_collection, parent_visible=True):
        visible = (
            parent_visible
            and not layer_collection.exclude
            and not layer_collection.hide_viewport
            and not layer_collection.collection.hide_viewport
            and not layer_collection.collection.hide_select
        )
        if visible:
            visible_collections.add(layer_collection.collection)
        for child in layer_collection.children:
            visit(child, visible)

    visit(context.view_layer.layer_collection)
    return visible_collections


def _visible_source_collection(context, source_obj):
    visible_collections = _visible_collections(context)
    for collection in source_obj.users_collection:
        if collection in visible_collections:
            return collection
    return context.collection or context.scene.collection


def _output_is_selectable(context, output):
    if not (
        output is not None
        and output.name in bpy.data.objects
        and output.type == "CURVE"
        and context.view_layer.objects.get(output.name) is output
        and not output.hide_viewport
        and not output.hide_select
    ):
        return False
    visible_collections = _visible_collections(context)
    return any(collection in visible_collections for collection in output.users_collection)


def _create_centerline_object(context, source_obj, layers, centers, metadata=None):
    curve_data = None
    curve_obj = None
    try:
        curve_data = bpy.data.curves.new(f"{source_obj.name}_Centerline", type="CURVE")
        curve_data.dimensions = "3D"
        curve_data.resolution_u = 1
        curve_data.render_resolution_u = 1
        curve_data.bevel_depth = 0.0
        curve_data.extrude = 0.0
        curve_data.taper_object = None

        spline = curve_data.splines.new(type="POLY")
        spline.points.add(len(centers) - 1)
        for point, center in zip(spline.points, centers):
            point.co = (*center, 1.0)
        spline.use_cyclic_u = False

        curve_obj = bpy.data.objects.new(f"{source_obj.name}_Centerline", curve_data)
        _visible_source_collection(context, source_obj).objects.link(curve_obj)
        curve_obj.matrix_world = source_obj.matrix_world.copy()
        curve_obj.show_in_front = True
        curve_obj["character_designer_generator"] = GENERATOR_ID
        curve_obj["character_designer_source"] = source_obj.name
        curve_obj["character_designer_layer_vertices"] = json.dumps(layers, separators=(",", ":"))
        if metadata is not None:
            if metadata.get("point_count") != len(centers):
                raise ValueError("Cross-section metadata does not match the Curve point count.")
            curve_obj["character_designer_metadata_version"] = METADATA_VERSION
            curve_obj["character_designer_cross_sections"] = json.dumps(
                metadata,
                separators=(",", ":"),
                allow_nan=False,
            )
        return curve_obj
    except Exception:
        if curve_obj is not None and curve_obj.name in bpy.data.objects:
            bpy.data.objects.remove(curve_obj, do_unlink=True)
        if curve_data is not None and curve_data.name in bpy.data.curves:
            bpy.data.curves.remove(curve_data)
        raise


def _remove_created_curve(curve_obj):
    if curve_obj is None or curve_obj.name not in bpy.data.objects:
        return
    curve_data = curve_obj.data if curve_obj.type == "CURVE" else None
    bpy.data.objects.remove(curve_obj, do_unlink=True)
    if curve_data is not None and curve_data.users == 0:
        bpy.data.curves.remove(curve_data)


class CHARACTERDESIGNER_OT_capture_root(Operator):
    bl_idname = "character_designer.capture_root_slice"
    bl_label = "Capture Selected Root"
    bl_description = "Capture one selected edge row/loop or the boundary of a selected cap region"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.edit_object is not None and context.edit_object.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({"ERROR"}, "Character Designer is not registered correctly.")
            return {"CANCELLED"}
        try:
            (
                obj,
                bm,
                root_indices,
                root_edge_keys,
                kind,
                ignored_indices,
                capture_mode,
            ) = _capture_data(context)
            settings.root_object = obj
            settings.root_mesh = obj.data
            settings.root_indices_json = json.dumps(root_indices, separators=(",", ":"))
            settings.root_edges_json = json.dumps(root_edge_keys, separators=(",", ":"))
            settings.root_ignored_indices_json = json.dumps(
                ignored_indices,
                separators=(",", ":"),
            )
            settings.root_kind = kind
            settings.root_capture_mode = capture_mode
            settings.root_vertex_count = len(root_indices)
            settings.root_ignored_count = len(ignored_indices)
            settings.topology_signature = _topology_signature(bm)
            # Keep previously generated Curve objects, but stop presenting an
            # old strand's measurements as if they belonged to this capture.
            settings.output_object = None
            _set_status(
                settings,
                "SUCCESS",
                (
                    f"Captured cap boundary with {len(root_indices)} vertices; "
                    f"ignored {len(ignored_indices)} interior "
                    f"{'vertex' if len(ignored_indices) == 1 else 'vertices'}."
                    if capture_mode in {"FAN_CAP", "TRI_CAP", "REGION_CAP"}
                    else f"Captured {_root_label(kind)} with {len(root_indices)} vertices."
                ),
            )
        except CenterlineError as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, settings.last_message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_clear_root(Operator):
    bl_idname = "character_designer.clear_root_slice"
    bl_label = "Clear Captured Root"
    bl_description = "Forget the captured root slice"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        settings = _settings(context)
        if settings is not None:
            _clear_capture(settings)
            _set_status(settings, "INFO", "Root capture cleared.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_build_centerline(Operator):
    bl_idname = "character_designer.build_centerline"
    bl_label = "Build Center Curve"
    bl_description = "Create one exact Poly curve point at the arithmetic mean of every selected slice"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.edit_object is not None and context.edit_object.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({"ERROR"}, "Character Designer is not registered correctly.")
            return {"CANCELLED"}

        created = None
        try:
            source_obj, _bm, layers, centers = _extract_layers(context, settings)
            metadata = _build_cross_section_metadata(
                source_obj,
                _bm,
                layers,
                centers,
                settings.root_kind,
            )
            created = _create_centerline_object(
                context,
                source_obj,
                layers,
                centers,
                metadata,
            )
            settings.output_object = created
            summary = _metadata_summary(metadata)
            _set_status(
                settings,
                "SUCCESS",
                (
                    f"Built {created.name}: {len(centers)} points; local profile span "
                    f"{_compact_number(summary['minimum_profile_span'])}-"
                    f"{_compact_number(summary['maximum_profile_span'])} BU."
                ),
            )
        except CenterlineError as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            _remove_created_curve(created)
            if settings.output_object is created:
                settings.output_object = None
            message = f"Center curve failed: {exc}"
            _set_status(settings, "ERROR", message)
            self.report({"ERROR"}, message)
            traceback.print_exc()
            return {"CANCELLED"}

        self.report({"INFO"}, settings.last_message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_select_output(Operator):
    bl_idname = "character_designer.select_output"
    bl_label = "Select Output"
    bl_description = "Leave mesh Edit Mode and select the last generated center curve"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        obj = getattr(settings, "output_object", None) if settings else None
        return _output_is_selectable(context, obj)

    def execute(self, context):
        settings = _settings(context)
        output = settings.output_object
        if not _output_is_selectable(context, output):
            self.report({"WARNING"}, "The output curve is not visible/selectable in this View Layer.")
            return {"CANCELLED"}
        output.hide_set(False)
        if not output.visible_get(view_layer=context.view_layer):
            self.report({"WARNING"}, "The output curve is hidden by its collection or View Layer.")
            return {"CANCELLED"}
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        output.hide_set(False)
        output.select_set(True)
        context.view_layer.objects.active = output
        if not output.select_get(view_layer=context.view_layer):
            self.report({"ERROR"}, "Blender could not select the output curve.")
            return {"CANCELLED"}
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_refresh_addon(Operator):
    bl_idname = "character_designer.refresh_addon"
    bl_label = "Refresh Add-on"
    bl_description = "Validate and reload Character Designer after its Python files change"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, _context):
        return not ADDON_REFRESH_PENDING

    def execute(self, _context):
        global ADDON_REFRESH_PENDING, ADDON_REFRESH_LAST_ERROR, ADDON_REFRESH_LAST_STATE

        if not _source_changed():
            ADDON_REFRESH_LAST_STATE = False
            if not bpy.app.timers.is_registered(_source_watch_deferred):
                if not _register_source_watch():
                    self.report({"ERROR"}, ADDON_REFRESH_LAST_ERROR)
                    return {"CANCELLED"}
            ADDON_REFRESH_LAST_ERROR = ""
            _tag_view3d_redraw()
            self.report({"INFO"}, "Character Designer is already current.")
            return {"CANCELLED"}
        try:
            _validate_source_files()
        except Exception as exc:
            ADDON_REFRESH_LAST_ERROR = str(exc)
            self.report({"ERROR"}, f"Refresh blocked by a Python error: {exc}")
            return {"CANCELLED"}

        ADDON_REFRESH_PENDING = True
        ADDON_REFRESH_LAST_ERROR = ""
        try:
            if not bpy.app.timers.is_registered(_reload_addon_deferred):
                bpy.app.timers.register(_reload_addon_deferred, first_interval=0.1)
        except Exception as exc:
            ADDON_REFRESH_PENDING = False
            ADDON_REFRESH_LAST_ERROR = str(exc)
            self.report({"ERROR"}, f"Could not schedule refresh: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, "Refreshing Character Designer...")
        return {"FINISHED"}


def _draw_message(layout, level, message):
    if not message:
        return
    icon = {"ERROR": "ERROR", "SUCCESS": "CHECKMARK", "INFO": "INFO"}.get(level, "INFO")
    lines = textwrap.wrap(
        message,
        width=52,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [message]
    for index, line in enumerate(lines):
        row = layout.row()
        row.alert = level == "ERROR"
        if index == 0:
            row.label(text=line, icon=icon)
        else:
            row.label(text=line)


class CHARACTERDESIGNER_PT_main(Panel):
    bl_label = "Character Designer"
    bl_idname = "CHARACTERDESIGNER_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Character"

    def draw(self, context):
        layout = self.layout
        settings = _settings(context)
        if settings is None:
            layout.label(text="Add-on state unavailable", icon="ERROR")
            return

        layout.label(text="Hair Centerline", icon="CURVE_DATA")

        root_box = layout.box()
        root_box.label(text="1  Root Slice")
        row = root_box.row(align=True)
        row.operator(
            "character_designer.capture_root_slice",
            text="Recapture Root" if settings.root_object else "Capture Selected Root",
            icon="RESTRICT_SELECT_OFF",
        )
        if settings.root_object:
            row.operator("character_designer.clear_root_slice", text="", icon="X")
            root_box.label(
                text=(
                    f"Captured: {_captured_root_label(settings)} · "
                    f"{settings.root_vertex_count} verts"
                ),
                icon="CHECKMARK",
            )
        else:
            root_box.label(text="Select a root edge row/loop or the full cap region", icon="INFO")

        grow_box = layout.box()
        grow_box.label(text="2  Grow Selection")
        grow_box.label(text="Ctrl + Numpad +  toward the tip", icon="ADD")

        build_ready = False
        try:
            obj, bm = _edit_bmesh(context)
            vertex_count, edge_count, face_count = _selection_counts(bm)
            if settings.root_object is not None and obj is settings.root_object:
                root_indices = set(_indices_from_settings(settings))
                ignored_indices = set(_ignored_indices_from_settings(settings))
                grow_box.label(
                    text=f"Root ready · {len(root_indices)} boundary verts",
                    icon="CHECKMARK",
                )
                if ignored_indices:
                    grow_box.label(
                        text=f"Ignored · {len(ignored_indices)} cap-interior verts",
                        icon="INFO",
                    )
                selected = {
                    vertex.index
                    for vertex in bm.verts
                    if vertex.select and vertex.index not in ignored_indices
                }
                if selected == root_indices:
                    grow_box.label(text="Root captured. Grow toward the tip.", icon="INFO")
                else:
                    _source, _bm, layers, _centers = _extract_layers(context, settings)
                    grow_box.label(
                        text=f"Ready: {len(layers)} layers → {len(layers)} curve points",
                        icon="CHECKMARK",
                    )
                    build_ready = True
            elif settings.root_object is not None:
                grow_box.label(text=f"Selected: {vertex_count} V · {edge_count} E · {face_count} F")
                row = grow_box.row()
                row.alert = True
                row.label(text="Return to the captured hair object.", icon="ERROR")
            else:
                grow_box.label(text=f"Selected: {vertex_count} V · {edge_count} E · {face_count} F")
        except CenterlineError as exc:
            if settings.root_object is not None:
                _draw_message(grow_box, "ERROR", str(exc))

        build_box = layout.box()
        build_box.label(text="3  Build")
        build_box.label(text="One point per cross-section · source local")
        row = build_box.row()
        row.enabled = build_ready
        row.operator("character_designer.build_centerline", icon="CURVE_PATH")

        output = settings.output_object
        if output is not None and output.name in bpy.data.objects:
            row = build_box.row(align=True)
            row.prop(settings, "output_object", text="Output")
            row.operator("character_designer.select_output", text="Select", icon="RESTRICT_SELECT_OFF")
            summary = _metadata_summary(_curve_cross_section_metadata(output))
            if summary is not None:
                build_box.label(
                    text=(
                        "Profile span local (BU): "
                        f"R {_compact_number(summary['root_profile_span'])} · "
                        f"Max {_compact_number(summary['maximum_profile_span'])} · "
                        f"T {_compact_number(summary['tip_profile_span'])}"
                    ),
                    icon="DRIVER_DISTANCE",
                )
                orientation_text = (
                    f"Orientation: {summary['mesh_count']} face-normal / "
                    f"{summary['tracked_count']} tracked"
                )
                if summary["tip_count"]:
                    orientation_text += f" / {summary['tip_count']} tip"
                build_box.label(text=orientation_text, icon="ORIENTATION_NORMAL")

        _draw_message(layout, settings.last_level, settings.last_message)

        if _refresh_ui_visible():
            layout.separator()
            refresh_row = layout.row(align=True)
            if ADDON_REFRESH_LAST_ERROR:
                refresh_row.alert = True
                refresh_row.label(text="Refresh failed", icon="ERROR")
                refresh_row.operator(
                    "character_designer.refresh_addon",
                    text="Retry",
                    icon="FILE_REFRESH",
                )
                _draw_message(layout, "ERROR", ADDON_REFRESH_LAST_ERROR)
            elif ADDON_REFRESH_PENDING:
                refresh_row.enabled = False
                refresh_row.label(text="Refreshing add-on...", icon="FILE_REFRESH")
            else:
                refresh_row.label(text="Source changed", icon="INFO")
                refresh_row.operator(
                    "character_designer.refresh_addon",
                    text="Refresh Add-on",
                    icon="FILE_REFRESH",
                )


CLASSES = (
    CharacterDesignerState,
    CHARACTERDESIGNER_OT_capture_root,
    CHARACTERDESIGNER_OT_clear_root,
    CHARACTERDESIGNER_OT_build_centerline,
    CHARACTERDESIGNER_OT_select_output,
    CHARACTERDESIGNER_OT_refresh_addon,
    CHARACTERDESIGNER_PT_main,
)


def register():
    if hasattr(bpy.types.WindowManager, "character_designer"):
        _register_source_watch()
        return

    registered = []
    property_added = False
    try:
        for cls in CLASSES:
            bpy.utils.register_class(cls)
            registered.append(cls)
        bpy.types.WindowManager.character_designer = PointerProperty(
            type=CharacterDesignerState,
            options={"SKIP_SAVE"},
        )
        property_added = True
        _register_source_watch()
    except Exception:
        _unregister_source_watch()
        if property_added and hasattr(bpy.types.WindowManager, "character_designer"):
            del bpy.types.WindowManager.character_designer
        for cls in reversed(registered):
            try:
                bpy.utils.unregister_class(cls)
            except RuntimeError:
                pass
        raise


def unregister():
    _unregister_source_watch()
    if hasattr(bpy.types.WindowManager, "character_designer"):
        del bpy.types.WindowManager.character_designer
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
