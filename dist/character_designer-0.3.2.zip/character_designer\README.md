# Character Designer

Character Designer is Randy's personal Blender add-on. It stays separate from
RR Helper, which remains focused on the team's Blender/BlackUnity workflow.

## Hair Centerline

This tool does one job: it turns the cross-sections of a selected hair mesh into
an exact, plain center curve.

1. Enter Mesh Edit Mode.
2. Select only the root cross-section: one open edge row, one closed edge loop,
   a single-face cap, or every face of a multi-face cap.
3. Click **Capture Selected Root**.
4. Keep the root selected and grow toward the tip with `Ctrl+Numpad+`.
5. Click **Build Center Curve**.

Each selected topological layer contributes one Poly curve point. The point is
the arithmetic mean of that layer's current vertex positions. A final
single-vertex tip is supported. The curve stores those points in the source
mesh's local space and copies the source object's transform, so it appears in
the exact original position without losing local precision.

The result is deliberately plain: no bevel profile, thickness, material,
USD, or automatic shape generation. Every generated Poly point keeps Blender's
plain defaults of Radius `1.0` and Tilt `0.0`. The source mesh, Edit Mode, and
selection remain untouched when the curve is built.

The Curve object also records lossless source metadata for later profile work.
For every layer it stores the exact maximum local vertex-to-vertex width and
the deterministic vertex pair that produced it. It stores a local tangent,
width axis, frame normal, and the meaningful area-weighted band-face normal
when the mesh supplies one. Closed-tube normal cancellation falls back to a
tracked diameter/anchor frame; a single-vertex tip records width zero and
transports the preceding orientation. The data is versioned JSON in
`SOURCE_OBJECT_LOCAL` space together with the source matrix at build time.
Nothing in this metadata changes the visible Curve. A future profile tool can
derive Radius and Tilt from it without guessing or overwriting the original
measurements.

The Build panel shows only Root/Max/Tip maximum spans in source-local Blender
units and counts of face-normal, tracked-frame, and transported-tip
orientations. Full per-layer values remain on the generated object rather than
crowding the modeling workflow.

A polygonal topological cap such as `12 faces / 13 vertices / 24 edges` is
handled as one semantic cap even when it mixes triangles, quads, or n-gons:
Character Designer extracts its single outer boundary and keeps every enclosed
cap vertex out of later centerline layers. The complete boundary must have a
one-to-one outgoing edge map and an unselected quad collar whose outer edges
form another simple loop (or uniform triangles collapsing to one point tip).
That positive collar proof prevents an entire or partial open hair card, and a
single arbitrary side face, from being mistaken for a cross-section. You can
leave the cap selected and continue growing with `Ctrl+Numpad+` normally.

The extractor accepts a regular quad open strip or closed tube. Every two
non-tip layers must have one-to-one longitudinal edges; the final layer may
collapse to one fully connected point. It rejects a root in the middle,
disconnected selections, branches, ambiguous many-to-many layer links, partial
connections, and topology edits made after root capture instead of silently
producing a wrong curve.

## Refresh Add-on

Character Designer watches its installed Python files. **Refresh Add-on** is
completely hidden while the loaded code matches disk, and appears only after a
real source difference or refresh error. The add-on validates every Python file
first, then reloads itself on a short Blender timer so the running operator is
never unregistered from inside its own callback. The current `.blend` is not
saved or reloaded; session-only root/output state is reset.
