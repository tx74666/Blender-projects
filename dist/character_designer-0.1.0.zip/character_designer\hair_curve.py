import math
from collections import defaultdict, deque

import bmesh
import bpy
from bpy.props import (
    BoolProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
)
from bpy.types import Operator, PropertyGroup
from mathutils import Vector


PROFILE_OBJECT_NAME = "CD_D_Hair_Profile"
PROFILE_COLLECTION_NAME = "Character Designer Profiles"
EPSILON = 1.0e-8


def _curve_profile_poll(_self, obj):
    return obj is not None and obj.type == "CURVE"


class CharacterDesignerHairSettings(PropertyGroup):
    profile_object: PointerProperty(
        name="Profile",
        description="Curve object used as the generated hair curve's bevel profile",
        type=bpy.types.Object,
        poll=_curve_profile_poll,
    )
    profile_size: FloatProperty(
        name="Profile Width",
        description="Width of a newly created D-shaped profile",
        subtype="DISTANCE",
        default=0.01,
        min=0.0001,
        soft_max=0.05,
        precision=4,
    )
    match_source_width: BoolProperty(
        name="Match Source Width",
        description="Scale curve points so the bevel profile follows the source strand width",
        default=True,
    )
    radius_scale: FloatProperty(
        name="Width Scale",
        description="Additional multiplier applied to every extracted curve-point radius",
        default=1.0,
        min=0.01,
        soft_max=4.0,
    )
    resolution_u: IntProperty(
        name="Curve Resolution",
        description="Preview and render resolution between Bézier points",
        default=8,
        min=1,
        max=64,
    )
    use_source_tilt: BoolProperty(
        name="Follow Source Twist",
        description="Estimate curve tilt from a continuous side of the selected source strand",
        default=True,
    )
    flip_tilt: BoolProperty(
        name="Flip Tilt",
        description="Rotate the profile 180 degrees around the strand",
        default=False,
    )
    tilt_offset: FloatProperty(
        name="Tilt Offset",
        description="Additional rotation of the profile around the strand",
        subtype="ANGLE",
        default=0.0,
    )
    fill_caps: BoolProperty(
        name="Fill Caps",
        description="Fill the two ends when a bevel profile is assigned",
        default=True,
    )
    copy_material: BoolProperty(
        name="Copy Material",
        description="Copy the source mesh's first material slot to the generated curve",
        default=True,
    )


def _active_selected_component(active_face, selected_faces):
    selected = set(selected_faces)
    component = set()
    stack = [active_face]
    while stack:
        face = stack.pop()
        if face in component or face not in selected:
            continue
        component.add(face)
        for edge in face.edges:
            for neighbor in edge.link_faces:
                if neighbor in selected and neighbor not in component:
                    stack.append(neighbor)
    return component


def _distance_layers(root_face, component_faces):
    allowed_faces = set(component_faces)
    allowed_vertices = {vert for face in allowed_faces for vert in face.verts}
    allowed_edges = {
        edge
        for face in allowed_faces
        for edge in face.edges
        if edge.verts[0] in allowed_vertices and edge.verts[1] in allowed_vertices
    }

    distances = {}
    queue = deque()
    for vert in root_face.verts:
        distances[vert] = 0
        queue.append(vert)

    while queue:
        vert = queue.popleft()
        next_distance = distances[vert] + 1
        for edge in vert.link_edges:
            if edge not in allowed_edges:
                continue
            other = edge.other_vert(vert)
            if other not in allowed_vertices or other in distances:
                continue
            distances[other] = next_distance
            queue.append(other)

    layers = defaultdict(list)
    for vert, distance in distances.items():
        layers[distance].append(vert)
    return [layers[index] for index in sorted(layers)], distances


def _world_face_normal(source_obj, face):
    normal_matrix = source_obj.matrix_world.to_3x3().inverted_safe().transposed()
    normal = normal_matrix @ face.normal
    if normal.length_squared <= EPSILON:
        return Vector((0.0, 0.0, 1.0))
    return normal.normalized()


def _world_face_area(source_obj, face):
    points = [source_obj.matrix_world @ vert.co for vert in face.verts]
    if len(points) < 3:
        return 0.0
    origin = points[0]
    area = 0.0
    for index in range(1, len(points) - 1):
        area += (points[index] - origin).cross(points[index + 1] - origin).length * 0.5
    return area


def _layer_centers(source_obj, layers):
    matrix = source_obj.matrix_world
    centers = []
    world_layers = []
    for layer in layers:
        points = [matrix @ vert.co for vert in layer]
        center = sum(points, Vector()) / len(points)
        centers.append(center)
        world_layers.append(points)
    return centers, world_layers


def _point_tangents(centers):
    tangents = []
    for index, center in enumerate(centers):
        if index == 0:
            tangent = centers[1] - center
        elif index == len(centers) - 1:
            tangent = center - centers[index - 1]
        else:
            tangent = centers[index + 1] - centers[index - 1]
        if tangent.length_squared <= EPSILON:
            tangent = Vector((0.0, 0.0, 1.0))
        tangents.append(tangent.normalized())
    return tangents


def _layer_radii(world_layers, centers, tangents):
    radii = []
    for points, center, tangent in zip(world_layers, centers, tangents):
        radius = 0.0
        for point in points:
            radial = point - center
            radial -= tangent * radial.dot(tangent)
            radius = max(radius, radial.length)
        radii.append(radius)
    return radii


def _segment_face_candidates(component_faces, distances, segment_count):
    candidates = [[] for _ in range(segment_count)]
    for face in component_faces:
        levels = sorted({distances[vert] for vert in face.verts if vert in distances})
        if len(levels) != 2 or levels[1] != levels[0] + 1:
            continue
        segment = levels[0]
        if 0 <= segment < segment_count:
            candidates[segment].append(face)
    return candidates


def _continuous_guide_normals(source_obj, component_faces, distances, segment_count):
    candidates = _segment_face_candidates(component_faces, distances, segment_count)
    if not candidates or not candidates[0]:
        return []

    guide_faces = [None] * segment_count
    guide_faces[0] = max(
        candidates[0],
        key=lambda face: _world_face_area(source_obj, face),
    )

    for segment in range(1, segment_count):
        if not candidates[segment]:
            continue
        previous_face = next(
            (guide_faces[index] for index in range(segment - 1, -1, -1) if guide_faces[index]),
            None,
        )
        if previous_face is None:
            guide_faces[segment] = max(
                candidates[segment],
                key=lambda face: _world_face_area(source_obj, face),
            )
            continue
        previous_normal = _world_face_normal(source_obj, previous_face)
        guide_faces[segment] = max(
            candidates[segment],
            key=lambda face: previous_normal.dot(_world_face_normal(source_obj, face)),
        )

    normals = []
    last_normal = None
    for face in guide_faces:
        if face is not None:
            last_normal = _world_face_normal(source_obj, face)
        normals.append(last_normal.copy() if last_normal is not None else None)

    next_normal = None
    for index in range(len(normals) - 1, -1, -1):
        if normals[index] is not None:
            next_normal = normals[index]
        elif next_normal is not None:
            normals[index] = next_normal.copy()
    return normals


def _projected_normal(vector, tangent):
    projected = vector - tangent * vector.dot(tangent)
    if projected.length_squared <= EPSILON:
        for fallback in (Vector((0.0, 0.0, 1.0)), Vector((0.0, 1.0, 0.0)), Vector((1.0, 0.0, 0.0))):
            projected = fallback - tangent * fallback.dot(tangent)
            if projected.length_squared > EPSILON:
                break
    return projected.normalized()


def _z_up_reference(tangent):
    for axis in (Vector((0.0, 0.0, 1.0)), Vector((0.0, 1.0, 0.0)), Vector((1.0, 0.0, 0.0))):
        reference = axis - tangent * axis.dot(tangent)
        if reference.length_squared > EPSILON:
            return reference.normalized()
    return Vector((1.0, 0.0, 0.0))


def _signed_angle_around_axis(reference, target, axis):
    return math.atan2(axis.dot(reference.cross(target)), reference.dot(target))


def _point_tilts(tangents, segment_normals, settings):
    if not settings.use_source_tilt or not segment_normals:
        base_offset = settings.tilt_offset + (math.pi if settings.flip_tilt else 0.0)
        return [base_offset] * len(tangents)

    point_normals = []
    for index, tangent in enumerate(tangents):
        nearby = []
        if index > 0 and segment_normals[index - 1] is not None:
            nearby.append(segment_normals[index - 1])
        if index < len(segment_normals) and segment_normals[index] is not None:
            nearby.append(segment_normals[index])
        normal = sum(nearby, Vector()) if nearby else _z_up_reference(tangent)
        point_normals.append(_projected_normal(normal, tangent))

    tilts = []
    extra = settings.tilt_offset + (math.pi if settings.flip_tilt else 0.0)
    for tangent, normal in zip(tangents, point_normals):
        reference = _z_up_reference(tangent)
        tilts.append(_signed_angle_around_axis(reference, normal, tangent) + extra)
    return tilts


def _profile_radius(profile_object):
    if profile_object is None or profile_object.type != "CURVE":
        return 0.0
    scale = profile_object.matrix_world.to_scale()
    radius = 0.0
    for spline in profile_object.data.splines:
        if spline.type == "BEZIER":
            coordinates = (point.co for point in spline.bezier_points)
        else:
            coordinates = (point.co.xyz for point in spline.points)
        for coordinate in coordinates:
            radius = max(
                radius,
                Vector((coordinate.x * scale.x, coordinate.y * scale.y)).length,
            )
    return radius


def _curve_point_radii(source_radii, settings):
    nonzero = [radius for radius in source_radii if radius > EPSILON]
    root_radius = nonzero[0] if nonzero else 1.0
    profile_radius = _profile_radius(settings.profile_object)

    if settings.match_source_width and profile_radius > EPSILON:
        values = [radius / profile_radius for radius in source_radii]
        bevel_depth = 0.0
    else:
        values = [radius / root_radius for radius in source_radii]
        bevel_depth = root_radius

    minimum = 0.001
    return [max(minimum, value * settings.radius_scale) for value in values], bevel_depth


def _create_curve_object(context, source_obj, centers, radii, tilts, bevel_depth, settings):
    curve_data = bpy.data.curves.new(f"{source_obj.name}_HairGuide", type="CURVE")
    curve_data.dimensions = "3D"
    curve_data.resolution_u = settings.resolution_u
    curve_data.render_resolution_u = settings.resolution_u
    curve_data.twist_mode = "Z_UP"
    curve_data.use_fill_caps = settings.fill_caps

    if settings.profile_object is not None:
        curve_data.bevel_mode = "OBJECT"
        curve_data.bevel_object = settings.profile_object
    else:
        curve_data.bevel_mode = "ROUND"
        curve_data.bevel_depth = bevel_depth
        curve_data.bevel_resolution = 3

    spline = curve_data.splines.new(type="BEZIER")
    spline.bezier_points.add(len(centers) - 1)
    for point, center, radius, tilt in zip(spline.bezier_points, centers, radii, tilts):
        point.co = center
        point.handle_left_type = "AUTO"
        point.handle_right_type = "AUTO"
        point.radius = radius
        point.tilt = tilt

    curve_obj = bpy.data.objects.new(f"{source_obj.name}_HairCurve", curve_data)
    target_collection = source_obj.users_collection[0] if source_obj.users_collection else context.collection
    target_collection.objects.link(curve_obj)
    curve_obj["character_designer_source"] = source_obj.name
    curve_obj["character_designer_ring_count"] = len(centers)
    curve_obj["character_designer_generator"] = "selected_hair_strip_v1"

    if settings.copy_material and source_obj.data.materials:
        curve_data.materials.append(source_obj.data.materials[0])
    return curve_obj


class CHARACTERDESIGNER_OT_create_d_profile(Operator):
    bl_idname = "character_designer.create_d_hair_profile"
    bl_label = "Create D Profile"
    bl_description = "Create an eight-point D-shaped bevel profile for anime hair"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.character_designer_hair
        existing = bpy.data.objects.get(PROFILE_OBJECT_NAME)
        if existing is not None and existing.type == "CURVE":
            settings.profile_object = existing
            self.report({"INFO"}, "Using the existing Character Designer D profile")
            return {"FINISHED"}

        size = settings.profile_size
        points = (
            (-0.18, -0.50),
            (0.08, -0.50),
            (0.25, -0.36),
            (0.32, 0.00),
            (0.25, 0.36),
            (0.08, 0.50),
            (-0.18, 0.50),
            (-0.18, 0.00),
        )

        curve_data = bpy.data.curves.new(f"{PROFILE_OBJECT_NAME}_Data", type="CURVE")
        curve_data.dimensions = "2D"
        curve_data.resolution_u = 1
        curve_data.render_resolution_u = 1
        curve_data.fill_mode = "BOTH"
        spline = curve_data.splines.new(type="POLY")
        spline.points.add(len(points) - 1)
        for point, (x_value, y_value) in zip(spline.points, points):
            point.co = (x_value * size, y_value * size, 0.0, 1.0)
        spline.use_cyclic_u = True

        profile_obj = bpy.data.objects.new(PROFILE_OBJECT_NAME, curve_data)
        collection = bpy.data.collections.get(PROFILE_COLLECTION_NAME)
        if collection is None:
            collection = bpy.data.collections.new(PROFILE_COLLECTION_NAME)
            context.scene.collection.children.link(collection)
        collection.objects.link(profile_obj)
        profile_obj.display_type = "WIRE"
        profile_obj.show_in_front = True
        profile_obj.hide_render = True
        profile_obj["character_designer_profile"] = "D_8_POINT"
        settings.profile_object = profile_obj
        try:
            profile_obj.hide_set(True)
        except RuntimeError:
            pass

        self.report({"INFO"}, "Created an eight-point D hair profile")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_selected_hair_strip_to_curve(Operator):
    bl_idname = "character_designer.selected_hair_strip_to_curve"
    bl_label = "Selected Hair Strip to Curve"
    bl_description = "Extract one curve point per topology layer, starting from the active root face"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.edit_object
        return context.mode == "EDIT_MESH" and obj is not None and obj.type == "MESH"

    def execute(self, context):
        source_obj = context.edit_object
        bm = bmesh.from_edit_mesh(source_obj.data)
        bm.faces.ensure_lookup_table()
        active_face = bm.faces.active
        selected_faces = [face for face in bm.faces if face.select]

        if active_face is None or not active_face.select:
            self.report({"ERROR"}, "Select the root cross-section last so it is the active face")
            return {"CANCELLED"}
        if not 3 <= len(active_face.verts) <= 16:
            self.report({"ERROR"}, "The active root face must be a 3-16 sided cross-section")
            return {"CANCELLED"}

        component_faces = _active_selected_component(active_face, selected_faces)
        if not component_faces:
            self.report({"ERROR"}, "No connected selected hair faces were found")
            return {"CANCELLED"}

        layers, distances = _distance_layers(active_face, component_faces)
        if len(layers) < 2:
            self.report({"ERROR"}, "Grow the selection outward by at least one topology layer")
            return {"CANCELLED"}
        if any(not layer for layer in layers):
            self.report({"ERROR"}, "The selected topology does not form continuous layers")
            return {"CANCELLED"}

        centers, world_layers = _layer_centers(source_obj, layers)
        if any((centers[index] - centers[index - 1]).length <= EPSILON for index in range(1, len(centers))):
            self.report({"ERROR"}, "Two extracted layers share the same center; check the root face and selection")
            return {"CANCELLED"}

        settings = context.scene.character_designer_hair
        tangents = _point_tangents(centers)
        source_radii = _layer_radii(world_layers, centers, tangents)
        segment_normals = _continuous_guide_normals(
            source_obj,
            component_faces,
            distances,
            len(centers) - 1,
        )
        tilts = _point_tilts(tangents, segment_normals, settings)
        radii, bevel_depth = _curve_point_radii(source_radii, settings)
        curve_obj = _create_curve_object(
            context,
            source_obj,
            centers,
            radii,
            tilts,
            bevel_depth,
            settings,
        )

        ignored = len(selected_faces) - len(component_faces)
        message = f"Created {curve_obj.name} with {len(centers)} points"
        if ignored > 0:
            message += f"; ignored {ignored} disconnected selected faces"
        self.report({"INFO"}, message)
        return {"FINISHED"}


def draw_hair_curve_tools(layout, context):
    settings = context.scene.character_designer_hair

    instructions = layout.box()
    instructions.label(text="1. Select the root cross-section last", icon="FACESEL")
    instructions.label(text="2. Ctrl+Numpad+ to grow toward the tip")

    action = layout.column(align=True)
    action.scale_y = 1.25
    action.operator(
        "character_designer.selected_hair_strip_to_curve",
        text="Selected Strip to Curve",
        icon="CURVE_BEZCURVE",
    )
    if context.mode != "EDIT_MESH":
        action.enabled = False

    profile_box = layout.box()
    profile_box.label(text="Bevel Profile")
    profile_box.prop(settings, "profile_object")
    row = profile_box.row(align=True)
    row.prop(settings, "profile_size")
    row.operator(
        "character_designer.create_d_hair_profile",
        text="Create D",
        icon="CURVE_NCIRCLE",
    )

    shape_box = layout.box()
    shape_box.label(text="Generated Shape")
    shape_box.prop(settings, "match_source_width")
    shape_box.prop(settings, "radius_scale")
    shape_box.prop(settings, "resolution_u")
    shape_box.prop(settings, "fill_caps")
    shape_box.prop(settings, "copy_material")

    tilt_box = layout.box()
    tilt_box.label(text="Orientation")
    tilt_box.prop(settings, "use_source_tilt")
    row = tilt_box.row(align=True)
    row.prop(settings, "flip_tilt")
    row.prop(settings, "tilt_offset")


CHARACTER_DESIGNER_HAIR_CLASSES = (
    CharacterDesignerHairSettings,
    CHARACTERDESIGNER_OT_create_d_profile,
    CHARACTERDESIGNER_OT_selected_hair_strip_to_curve,
)
