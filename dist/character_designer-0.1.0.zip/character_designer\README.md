# Character Designer

A personal Blender add-on for Randy's character-modeling workflow. It is kept
separate from RR Helper, which remains focused on the team's Blender/BlackUnity
handoff workflow.

## Hair strip to curve

1. Enter Edit Mode on a closed hair mesh made by extruding a root cross-section.
2. Select the root cross-section last so it is the active face.
3. Grow the selection toward the tip with `Ctrl+Numpad+`.
4. Open `3D View > Sidebar > Character > Hair Curve`.
5. Optionally create or assign a D-shaped bevel profile.
6. Run `Selected Strip to Curve`.

The source mesh is left untouched. The generated Bézier curve receives one
point per topological layer, relative point radii based on the source width,
and approximate tilt from a continuous side of the source strand.
