bl_info = {
    "name": "Character Designer",
    "author": "Randy & Codex",
    "version": (0, 1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Character",
    "description": "Character-focused modeling helpers, beginning with hair-strip curve extraction.",
    "category": "3D View",
}

import bpy
from bpy.props import PointerProperty

from .hair_curve import (
    CHARACTER_DESIGNER_HAIR_CLASSES,
    CharacterDesignerHairSettings,
    draw_hair_curve_tools,
)


class CHARACTERDESIGNER_PT_main(bpy.types.Panel):
    bl_label = "Character Designer"
    bl_idname = "CHARACTERDESIGNER_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Character"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Character modeling workflow", icon="OUTLINER_OB_ARMATURE")


class CHARACTERDESIGNER_PT_hair_curve(bpy.types.Panel):
    bl_label = "Hair Curve"
    bl_idname = "CHARACTERDESIGNER_PT_hair_curve"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Character"
    bl_parent_id = "CHARACTERDESIGNER_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        draw_hair_curve_tools(self.layout, context)


CLASSES = (
    *CHARACTER_DESIGNER_HAIR_CLASSES,
    CHARACTERDESIGNER_PT_main,
    CHARACTERDESIGNER_PT_hair_curve,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.character_designer_hair = PointerProperty(
        type=CharacterDesignerHairSettings
    )


def unregister():
    if hasattr(bpy.types.Scene, "character_designer_hair"):
        del bpy.types.Scene.character_designer_hair
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
