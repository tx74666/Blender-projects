# Character Designer

A personal Blender add-on for Randy's character-modeling workflow. It is kept
separate from RR Helper, which remains focused on the team's Blender/BlackUnity
handoff workflow.

## Hair strip to curve

1. Enter Edit Mode on a closed hair mesh made by extruding a root cross-section.
2. Select the root cross-section last so it is the active face.
3. Grow the selection toward the tip with `Ctrl+Numpad+`.
4. Open `3D View > Sidebar > Character > Hair Curve`.
5. Optionally create or assign a D-shaped bevel profile.
6. Run `Selected Strip to Curve`.

The source mesh is left untouched. The generated Bézier curve receives one
point per topological layer. Each point's Radius is calculated from the exact
projected maximum vertex-to-vertex span of its source loop, so later `Alt+S`
edits have a reliable scale basis.

Character Designer also stores the unscaled source measurements on the curve:

- exact maximum span, normal-axis thickness, and width-axis span per loop;
- loop center, tangent, longest-span axis, width axis, and source side normal;
- the original guide normal for every segment;
- generated Radius/Tilt values and the bevel profile's measured maximum span;
- a versioned JSON copy of all loop metrics for future tools.

Set **Orientation Center** to the head or body object when available. The tool
uses it to choose the broad source face pointing away from the character, then
tracks that same face side through shared ring edges. `Flip Tilt` remains a
non-destructive 180-degree correction when a particular strand needs the
opposite D-profile orientation.

A curve point has only one uniform bevel Radius. It can exactly preserve the
chosen maximum span, but it cannot independently reproduce changing width and
thickness at the same time. The original thickness is therefore retained in
metadata for a later anisotropic or Geometry Nodes workflow.

Exact custom-profile measurement supports Poly and Bézier splines. NURBS are
rejected because their evaluated contour does not equal their control polygon.
Profile sizing follows Blender bevel semantics: the profile object's direct
Scale is included, while parent and Delta Scale are not used by the bevel.
