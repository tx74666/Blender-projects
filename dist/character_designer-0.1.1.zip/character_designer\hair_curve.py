import json
import math
from collections import defaultdict, deque

import bmesh
import bpy
from bpy.props import (
    BoolProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, PropertyGroup
from mathutils import Vector
from mathutils.geometry import interpolate_bezier


PROFILE_OBJECT_NAME = "CD_D_Hair_Profile"
PROFILE_COLLECTION_NAME = "Character Designer Profiles"
EPSILON = 1.0e-8
D_PROFILE_BASE_POINTS = (
    (-0.18, -0.50),
    (0.08, -0.50),
    (0.25, -0.36),
    (0.32, 0.00),
    (0.25, 0.36),
    (0.08, 0.50),
    (-0.18, 0.50),
    (-0.18, 0.00),
)


def _profile_is_supported(obj):
    return (
        obj is not None
        and obj.type == "CURVE"
        and len(obj.data.splines) > 0
        and all(spline.type in {"POLY", "BEZIER"} for spline in obj.data.splines)
    )


def _curve_profile_poll(_self, obj):
    return _profile_is_supported(obj)


def _scaled_d_profile_points(size):
    base_max_width = max(
        math.hypot(second[0] - first[0], second[1] - first[1])
        for first_index, first in enumerate(D_PROFILE_BASE_POINTS)
        for second in D_PROFILE_BASE_POINTS[first_index + 1 :]
    )
    profile_scale = size / base_max_width
    return [
        (x_value * profile_scale, y_value * profile_scale)
        for x_value, y_value in D_PROFILE_BASE_POINTS
    ]


def _write_d_profile_data(curve_data, size):
    curve_data.splines.clear()
    curve_data.dimensions = "2D"
    curve_data.resolution_u = 1
    curve_data.render_resolution_u = 1
    curve_data.fill_mode = "BOTH"
    coordinates = _scaled_d_profile_points(size)
    spline = curve_data.splines.new(type="POLY")
    spline.points.add(len(coordinates) - 1)
    for point, (x_value, y_value) in zip(spline.points, coordinates):
        point.co = (x_value, y_value, 0.0, 1.0)
    spline.use_cyclic_u = True


class CharacterDesignerHairSettings(PropertyGroup):
    profile_object: PointerProperty(
        name="Profile",
        description="Curve object used as the generated hair curve's bevel profile",
        type=bpy.types.Object,
        poll=_curve_profile_poll,
    )
    profile_size: FloatProperty(
        name="Profile Max Width",
        description="Exact longest vertex-to-vertex span of a newly created D-shaped profile",
        subtype="DISTANCE",
        default=0.01,
        min=0.0001,
        soft_max=0.05,
        precision=4,
    )
    match_source_width: BoolProperty(
        name="Match Source Width",
        description="Set point Radius from exact source-loop max width divided by profile max width",
        default=True,
    )
    radius_scale: FloatProperty(
        name="Width Scale",
        description="Additional multiplier applied to every extracted curve-point radius",
        default=1.0,
        min=0.01,
        soft_max=4.0,
    )
    resolution_u: IntProperty(
        name="Curve Resolution",
        description="Preview and render resolution between Bézier points",
        default=8,
        min=1,
        max=64,
    )
    use_source_tilt: BoolProperty(
        name="Follow Source Twist",
        description="Estimate curve tilt from a continuous side of the selected source strand",
        default=True,
    )
    orientation_center: PointerProperty(
        name="Orientation Center",
        description="Optional head/body object used to choose the source side normal that points outward",
        type=bpy.types.Object,
    )
    flip_tilt: BoolProperty(
        name="Flip Tilt",
        description="Rotate the profile 180 degrees around the strand",
        default=False,
    )
    tilt_offset: FloatProperty(
        name="Tilt Offset",
        description="Additional rotation of the profile around the strand",
        subtype="ANGLE",
        default=0.0,
    )
    fill_caps: BoolProperty(
        name="Fill Caps",
        description="Fill the two ends when a bevel profile is assigned",
        default=True,
    )
    copy_material: BoolProperty(
        name="Copy Material",
        description="Copy the source mesh's first material slot to the generated curve",
        default=True,
    )
    last_status: StringProperty(
        name="Last Extraction",
        default="",
        options={"HIDDEN"},
    )
    last_loop_count: IntProperty(
        name="Loops",
        default=0,
        min=0,
        options={"HIDDEN"},
    )
    last_root_width: FloatProperty(
        name="Root Max Width",
        subtype="DISTANCE",
        default=0.0,
        min=0.0,
        options={"HIDDEN"},
    )
    last_min_width: FloatProperty(
        name="Minimum Max Width",
        subtype="DISTANCE",
        default=0.0,
        min=0.0,
        options={"HIDDEN"},
    )
    last_max_width: FloatProperty(
        name="Maximum Max Width",
        subtype="DISTANCE",
        default=0.0,
        min=0.0,
        options={"HIDDEN"},
    )


def _active_selected_component(active_face, selected_faces):
    selected = set(selected_faces)
    component = set()
    stack = [active_face]
    while stack:
        face = stack.pop()
        if face in component or face not in selected:
            continue
        component.add(face)
        for edge in face.edges:
            for neighbor in edge.link_faces:
                if neighbor in selected and neighbor not in component:
                    stack.append(neighbor)
    return component


def _distance_layers(root_face, component_faces):
    allowed_faces = set(component_faces)
    allowed_vertices = {vert for face in allowed_faces for vert in face.verts}
    allowed_edges = {
        edge
        for face in allowed_faces
        for edge in face.edges
        if edge.verts[0] in allowed_vertices and edge.verts[1] in allowed_vertices
    }

    distances = {}
    queue = deque()
    for vert in root_face.verts:
        distances[vert] = 0
        queue.append(vert)

    while queue:
        vert = queue.popleft()
        next_distance = distances[vert] + 1
        for edge in vert.link_edges:
            if edge not in allowed_edges:
                continue
            other = edge.other_vert(vert)
            if other not in allowed_vertices or other in distances:
                continue
            distances[other] = next_distance
            queue.append(other)

    layers = defaultdict(list)
    for vert, distance in distances.items():
        layers[distance].append(vert)
    return [layers[index] for index in sorted(layers)], distances


def _world_face_normal(source_obj, face):
    normal_matrix = source_obj.matrix_world.to_3x3().inverted_safe().transposed()
    normal = normal_matrix @ face.normal
    if normal.length_squared <= EPSILON:
        return Vector((0.0, 0.0, 1.0))
    return normal.normalized()


def _world_face_area(source_obj, face):
    points = [source_obj.matrix_world @ vert.co for vert in face.verts]
    if len(points) < 3:
        return 0.0
    origin = points[0]
    area = 0.0
    for index in range(1, len(points) - 1):
        area += (points[index] - origin).cross(points[index + 1] - origin).length * 0.5
    return area


def _world_face_center(source_obj, face):
    return source_obj.matrix_world @ face.calc_center_median()


def _world_edge_length(source_obj, edge):
    first = source_obj.matrix_world @ edge.verts[0].co
    second = source_obj.matrix_world @ edge.verts[1].co
    return (second - first).length


def _layer_centers(source_obj, layers):
    matrix = source_obj.matrix_world
    centers = []
    world_layers = []
    for layer in layers:
        points = [matrix @ vert.co for vert in layer]
        center = sum(points, Vector()) / len(points)
        centers.append(center)
        world_layers.append(points)
    return centers, world_layers


def _point_tangents(centers):
    tangents = []
    for index, center in enumerate(centers):
        if index == 0:
            tangent = centers[1] - center
        elif index == len(centers) - 1:
            tangent = center - centers[index - 1]
        else:
            tangent = centers[index + 1] - centers[index - 1]
        if tangent.length_squared <= EPSILON:
            tangent = Vector((0.0, 0.0, 1.0))
        tangents.append(tangent.normalized())
    return tangents


def _maximum_projected_width(points, tangent):
    maximum = 0.0
    width_axis = None
    for first_index, first in enumerate(points):
        for second in points[first_index + 1 :]:
            difference = second - first
            difference -= tangent * difference.dot(tangent)
            width = difference.length
            if width > maximum:
                maximum = width
                width_axis = difference.normalized() if width > EPSILON else None
    return maximum, width_axis


def _layer_metrics(world_layers, centers, tangents, point_normals):
    metrics = []
    previous_width_axis = None
    previous_profile_width_axis = None
    for index, (points, center, tangent, source_normal) in enumerate(
        zip(world_layers, centers, tangents, point_normals)
    ):
        max_width, width_axis = _maximum_projected_width(points, tangent)
        if width_axis is None:
            width_axis = _z_up_reference(tangent)
        if previous_width_axis is not None and width_axis.dot(previous_width_axis) < 0.0:
            width_axis.negate()
        previous_width_axis = width_axis.copy()

        source_normal = _projected_normal(source_normal, tangent)
        profile_width_axis = source_normal.cross(tangent)
        if profile_width_axis.length_squared <= EPSILON:
            profile_width_axis = width_axis.copy()
        else:
            profile_width_axis.normalize()
        if (
            previous_profile_width_axis is not None
            and profile_width_axis.dot(previous_profile_width_axis) < 0.0
        ):
            profile_width_axis.negate()
        previous_profile_width_axis = profile_width_axis.copy()

        normal_coordinates = [(point - center).dot(source_normal) for point in points]
        width_coordinates = [
            (point - center).dot(profile_width_axis) for point in points
        ]
        thickness = (
            max(normal_coordinates) - min(normal_coordinates)
            if normal_coordinates
            else 0.0
        )
        width_span = (
            max(width_coordinates) - min(width_coordinates)
            if width_coordinates
            else 0.0
        )
        metrics.append(
            {
                "index": index,
                "center": center.copy(),
                "tangent": tangent.copy(),
                "source_normal": source_normal.copy(),
                "width_axis": width_axis.copy(),
                "profile_width_axis": profile_width_axis.copy(),
                "max_width": max_width,
                "width_span": width_span,
                "thickness": thickness,
                "vertex_count": len(points),
            }
        )
    return metrics


def _segment_face_candidates(component_faces, distances, segment_count):
    candidates = [[] for _ in range(segment_count)]
    for face in component_faces:
        levels = sorted({distances[vert] for vert in face.verts if vert in distances})
        if len(levels) != 2 or levels[1] != levels[0] + 1:
            continue
        segment = levels[0]
        if 0 <= segment < segment_count:
            candidates[segment].append(face)
    return candidates


def _patch_normal(source_obj, faces):
    weighted = Vector()
    for face in faces:
        weighted += _world_face_normal(source_obj, face) * _world_face_area(
            source_obj,
            face,
        )
    if weighted.length_squared <= EPSILON:
        return _world_face_normal(source_obj, faces[0])
    return weighted.normalized()


def _patch_center(source_obj, faces):
    total_area = sum(_world_face_area(source_obj, face) for face in faces)
    if total_area <= EPSILON:
        return _world_face_center(source_obj, faces[0])
    return sum(
        (
            _world_face_center(source_obj, face)
            * _world_face_area(source_obj, face)
            for face in faces
        ),
        Vector(),
    ) / total_area


def _farthest_vertex_pair(source_obj, vertices):
    vertices = list(vertices)
    if len(vertices) <= 2:
        return vertices
    matrix = source_obj.matrix_world
    return list(
        max(
            (
                (first, second)
                for first_index, first in enumerate(vertices)
                for second in vertices[first_index + 1 :]
            ),
            key=lambda pair: (matrix @ pair[0].co - matrix @ pair[1].co).length_squared,
        )
    )


def _trace_segment_patch(
    source_obj,
    segment_faces,
    current_ring_vertices,
    distances,
    segment,
    reference_point,
    previous_normal=None,
):
    current_ring_vertices = set(current_ring_vertices)
    if not segment_faces or not current_ring_vertices:
        return [], [], None

    starts = [
        face
        for face in segment_faces
        if current_ring_vertices.issubset(set(face.verts))
    ]
    if not starts:
        maximum_overlap = max(
            len(current_ring_vertices.intersection(face.verts))
            for face in segment_faces
        )
        starts = [
            face
            for face in segment_faces
            if len(current_ring_vertices.intersection(face.verts)) == maximum_overlap
        ]

    if previous_normal is not None:
        start = max(
            starts,
            key=lambda face: (
                previous_normal.dot(_world_face_normal(source_obj, face)),
                -face.index,
            ),
        )
    else:
        start = max(
            starts,
            key=lambda face: (
                _world_face_normal(source_obj, face).dot(
                    _world_face_center(source_obj, face) - reference_point
                ),
                -face.index,
            ),
        )

    patch = [start]
    patch_set = {start}
    far_vertices = {
        vert
        for vert in start.verts
        if distances.get(vert) == segment + 1
    }
    segment_face_set = set(segment_faces)
    available_far_vertices = {
        vert
        for face in segment_faces
        for vert in face.verts
        if distances.get(vert) == segment + 1
    }
    target_far_count = min(2, len(available_far_vertices))
    while (
        len(far_vertices) < target_far_count
        and len(patch_set) < len(segment_face_set)
    ):
        current_normal = _patch_normal(source_obj, patch)
        neighbors = []
        for patch_face in patch:
            for edge in patch_face.edges:
                edge_levels = {distances.get(vert) for vert in edge.verts}
                if edge_levels != {segment, segment + 1}:
                    continue
                for neighbor in edge.link_faces:
                    if neighbor in segment_face_set and neighbor not in patch_set:
                        neighbors.append((neighbor, edge))
        if not neighbors:
            break
        neighbor, _shared_edge = max(
            neighbors,
            key=lambda item: (
                current_normal.dot(_world_face_normal(source_obj, item[0])),
                _world_edge_length(source_obj, item[1]),
                -item[0].index,
            ),
        )
        patch.append(neighbor)
        patch_set.add(neighbor)
        far_vertices.update(
            vert
            for vert in neighbor.verts
            if distances.get(vert) == segment + 1
        )

    far_vertices = _farthest_vertex_pair(source_obj, far_vertices)
    return patch, far_vertices, _patch_normal(source_obj, patch)


def _continuous_guide_normals(
    source_obj,
    root_face,
    component_faces,
    distances,
    segment_count,
    reference_point,
):
    candidates = _segment_face_candidates(component_faces, distances, segment_count)
    if not candidates or not candidates[0]:
        return []

    longest_root_edge = max(_world_edge_length(source_obj, edge) for edge in root_face.edges)
    width_edges = [
        edge
        for edge in root_face.edges
        if _world_edge_length(source_obj, edge) >= longest_root_edge * 0.9
    ]
    first_choices = []
    for root_edge in width_edges:
        patch, far_vertices, normal = _trace_segment_patch(
            source_obj,
            candidates[0],
            root_edge.verts,
            distances,
            0,
            reference_point,
        )
        if patch and normal is not None:
            first_choices.append(
                (
                    normal.dot(_patch_center(source_obj, patch) - reference_point),
                    -min(face.index for face in patch),
                    far_vertices,
                    normal,
                )
            )
    if not first_choices:
        return []

    _score, _tie_breaker, current_ring_vertices, previous_normal = max(
        first_choices,
        key=lambda choice: (choice[0], choice[1]),
    )
    normals = [previous_normal.copy()]
    for segment in range(1, segment_count):
        patch, far_vertices, normal = _trace_segment_patch(
            source_obj,
            candidates[segment],
            current_ring_vertices,
            distances,
            segment,
            reference_point,
            previous_normal=previous_normal,
        )
        if not patch or normal is None:
            normals.append(previous_normal.copy())
            continue
        normals.append(normal.copy())
        current_ring_vertices = far_vertices
        previous_normal = normal
    return normals


def _projected_normal(vector, tangent):
    projected = vector - tangent * vector.dot(tangent)
    if projected.length_squared <= EPSILON:
        for fallback in (Vector((0.0, 0.0, 1.0)), Vector((0.0, 1.0, 0.0)), Vector((1.0, 0.0, 0.0))):
            projected = fallback - tangent * fallback.dot(tangent)
            if projected.length_squared > EPSILON:
                break
    return projected.normalized()


def _z_up_reference(tangent):
    for axis in (Vector((0.0, 0.0, 1.0)), Vector((0.0, 1.0, 0.0)), Vector((1.0, 0.0, 0.0))):
        reference = axis - tangent * axis.dot(tangent)
        if reference.length_squared > EPSILON:
            return reference.normalized()
    return Vector((1.0, 0.0, 0.0))


def _z_up_profile_x_reference(tangent):
    reference = tangent.cross(Vector((0.0, 0.0, 1.0)))
    if reference.length_squared > EPSILON:
        return reference.normalized()
    for axis in (Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0))):
        reference = axis - tangent * axis.dot(tangent)
        if reference.length_squared > EPSILON:
            return reference.normalized()
    return Vector((1.0, 0.0, 0.0))


def _signed_angle_around_axis(reference, target, axis):
    return math.atan2(axis.dot(reference.cross(target)), reference.dot(target))


def _point_source_normals(tangents, segment_normals):
    point_normals = []
    for index, tangent in enumerate(tangents):
        nearby = []
        if index > 0 and segment_normals[index - 1] is not None:
            nearby.append(segment_normals[index - 1])
        if index < len(segment_normals) and segment_normals[index] is not None:
            nearby.append(segment_normals[index])
        normal = sum(nearby, Vector()) if nearby else _z_up_reference(tangent)
        point_normals.append(_projected_normal(normal, tangent))
    return point_normals


def _point_tilts(tangents, point_normals, settings):
    if not settings.use_source_tilt:
        base_offset = settings.tilt_offset + (math.pi if settings.flip_tilt else 0.0)
        return [base_offset] * len(tangents)

    tilts = []
    extra = settings.tilt_offset + (math.pi if settings.flip_tilt else 0.0)
    for tangent, normal in zip(tangents, point_normals):
        reference = _z_up_profile_x_reference(tangent)
        tilt = _signed_angle_around_axis(reference, normal, tangent) + extra
        if tilts:
            while tilt - tilts[-1] > math.pi:
                tilt -= math.tau
            while tilt - tilts[-1] < -math.pi:
                tilt += math.tau
        tilts.append(tilt)
    return tilts


def _profile_sample_points(profile_object):
    if not _profile_is_supported(profile_object):
        return []
    scale = profile_object.scale
    coordinates = []
    for spline in profile_object.data.splines:
        if spline.type == "BEZIER":
            points = list(spline.bezier_points)
            segment_count = len(points) if spline.use_cyclic_u else len(points) - 1
            samples_per_segment = max(4, profile_object.data.resolution_u + 1)
            for index in range(max(0, segment_count)):
                first = points[index]
                second = points[(index + 1) % len(points)]
                coordinates.extend(
                    interpolate_bezier(
                        first.co,
                        first.handle_right,
                        second.handle_left,
                        second.co,
                        samples_per_segment,
                    )
                )
        else:
            coordinates.extend(point.co.xyz for point in spline.points)
    return [
        Vector((coordinate.x * scale.x, coordinate.y * scale.y, 0.0))
        for coordinate in coordinates
    ]


def _profile_max_width(profile_object):
    points = _profile_sample_points(profile_object)
    maximum = 0.0
    for first_index, first in enumerate(points):
        for second in points[first_index + 1 :]:
            maximum = max(maximum, (second - first).length)
    return maximum


def _curve_point_radii(source_widths, settings):
    nonzero = [width for width in source_widths if width > EPSILON]
    root_width = nonzero[0] if nonzero else 1.0
    profile_width = _profile_max_width(settings.profile_object)

    if settings.match_source_width and profile_width > EPSILON:
        values = [width / profile_width for width in source_widths]
        bevel_depth = 0.0
        radius_mode = "MATCH_PROFILE_MAX_WIDTH"
        reference_width = profile_width
        radius_contract = "source_max_width / profile_max_width * radius_scale"
    else:
        values = [width / root_width for width in source_widths]
        bevel_depth = root_width * 0.5
        radius_mode = "NORMALIZE_TO_SOURCE_ROOT"
        reference_width = root_width
        radius_contract = "source_max_width / source_root_max_width * radius_scale"

    radii = [max(0.0, value * settings.radius_scale) for value in values]
    radius_info = {
        "mode": radius_mode,
        "contract": radius_contract,
        "reference_width": reference_width,
        "profile_width": profile_width,
        "round_bevel_depth": bevel_depth,
    }
    return radii, bevel_depth, radius_info


def _flat_vectors(vectors):
    return [float(component) for vector in vectors for component in vector]


def _store_curve_metrics(
    curve_obj,
    metrics,
    segment_normals,
    radii,
    tilts,
    radius_info,
    settings,
):
    max_widths = [float(metric["max_width"]) for metric in metrics]
    width_spans = [float(metric["width_span"]) for metric in metrics]
    thicknesses = [float(metric["thickness"]) for metric in metrics]
    centers = [metric["center"] for metric in metrics]
    tangents = [metric["tangent"] for metric in metrics]
    source_normals = [metric["source_normal"] for metric in metrics]
    width_axes = [metric["width_axis"] for metric in metrics]
    profile_width_axes = [metric["profile_width_axis"] for metric in metrics]
    stored_segment_normals = [
        normal if normal is not None else Vector((0.0, 0.0, 0.0))
        for normal in segment_normals
    ]

    curve_obj["character_designer_metrics_schema"] = "hair_loop_metrics_v3"
    curve_obj["character_designer_measurement_space"] = "WORLD"
    curve_obj["character_designer_source_loop_max_widths"] = max_widths
    curve_obj["character_designer_source_loop_width_spans"] = width_spans
    curve_obj["character_designer_source_loop_thicknesses"] = thicknesses
    curve_obj["character_designer_source_loop_vertex_counts"] = [
        int(metric["vertex_count"]) for metric in metrics
    ]
    curve_obj["character_designer_source_loop_centers"] = _flat_vectors(centers)
    curve_obj["character_designer_source_loop_tangents"] = _flat_vectors(tangents)
    curve_obj["character_designer_source_loop_normals"] = _flat_vectors(source_normals)
    curve_obj["character_designer_source_loop_max_width_axes"] = _flat_vectors(width_axes)
    curve_obj["character_designer_source_loop_width_axes"] = _flat_vectors(
        profile_width_axes
    )
    curve_obj["character_designer_source_segment_normals"] = _flat_vectors(
        stored_segment_normals
    )
    curve_obj["character_designer_generated_point_radii"] = [
        float(radius) for radius in radii
    ]
    curve_obj["character_designer_generated_point_tilts"] = [
        float(tilt) for tilt in tilts
    ]
    curve_obj["character_designer_profile_max_width"] = float(
        radius_info["profile_width"]
    )
    curve_obj["character_designer_radius_scale"] = float(settings.radius_scale)
    curve_obj["character_designer_radius_mode"] = radius_info["mode"]
    curve_obj["character_designer_radius_reference_width"] = float(
        radius_info["reference_width"]
    )
    actual_round_bevel_depth = (
        float(radius_info["round_bevel_depth"])
        if settings.profile_object is None
        else 0.0
    )
    curve_obj["character_designer_round_bevel_depth"] = float(
        actual_round_bevel_depth
    )

    document = {
        "schema": "hair_loop_metrics_v3",
        "measurement_space": "WORLD",
        "radius_mode": radius_info["mode"],
        "radius_contract": radius_info["contract"],
        "radius_reference_width": float(radius_info["reference_width"]),
        "bevel_mode": "OBJECT" if settings.profile_object else "ROUND",
        "round_bevel_depth": actual_round_bevel_depth,
        "profile": settings.profile_object.name if settings.profile_object else None,
        "profile_max_width": float(radius_info["profile_width"]),
        "radius_scale": float(settings.radius_scale),
        "orientation_center": (
            settings.orientation_center.name if settings.orientation_center else None
        ),
        "loops": [
            {
                "index": metric["index"],
                "vertex_count": metric["vertex_count"],
                "center_world": list(metric["center"]),
                "tangent_world": list(metric["tangent"]),
                "source_normal_world": list(metric["source_normal"]),
                "max_width_axis_world": list(metric["width_axis"]),
                "width_axis_world": list(metric["profile_width_axis"]),
                "max_width": float(metric["max_width"]),
                "width_span": float(metric["width_span"]),
                "thickness": float(metric["thickness"]),
                "curve_radius": float(radius),
                "curve_tilt": float(tilt),
            }
            for metric, radius, tilt in zip(metrics, radii, tilts)
        ],
        "segments": [
            {
                "index": index,
                "guide_normal_world": list(normal),
            }
            for index, normal in enumerate(stored_segment_normals)
        ],
    }
    curve_obj["character_designer_loop_metrics_json"] = json.dumps(
        document,
        ensure_ascii=False,
        separators=(",", ":"),
    )


def _create_curve_object(
    context,
    source_obj,
    centers,
    tangents,
    radii,
    tilts,
    bevel_depth,
    metrics,
    segment_normals,
    radius_info,
    settings,
):
    curve_data = bpy.data.curves.new(f"{source_obj.name}_HairGuide", type="CURVE")
    curve_data.dimensions = "3D"
    curve_data.resolution_u = settings.resolution_u
    curve_data.render_resolution_u = settings.resolution_u
    curve_data.twist_mode = "Z_UP"
    curve_data.use_fill_caps = settings.fill_caps

    if settings.profile_object is not None:
        curve_data.bevel_mode = "OBJECT"
        curve_data.bevel_object = settings.profile_object
    else:
        curve_data.bevel_mode = "ROUND"
        curve_data.bevel_depth = bevel_depth
        curve_data.bevel_resolution = 3

    spline = curve_data.splines.new(type="BEZIER")
    spline.bezier_points.add(len(centers) - 1)
    for index, (point, center, tangent, radius, tilt) in enumerate(
        zip(spline.bezier_points, centers, tangents, radii, tilts)
    ):
        point.co = center
        point.handle_left_type = "FREE"
        point.handle_right_type = "FREE"
        previous_length = (
            (center - centers[index - 1]).length
            if index > 0
            else (centers[1] - center).length
        )
        next_length = (
            (centers[index + 1] - center).length
            if index < len(centers) - 1
            else (center - centers[index - 1]).length
        )
        point.handle_left = center - tangent * (previous_length / 3.0)
        point.handle_right = center + tangent * (next_length / 3.0)
        point.radius = radius
        point.tilt = tilt

    curve_obj = bpy.data.objects.new(f"{source_obj.name}_HairCurve", curve_data)
    target_collection = source_obj.users_collection[0] if source_obj.users_collection else context.collection
    target_collection.objects.link(curve_obj)
    curve_obj["character_designer_source"] = source_obj.name
    curve_obj["character_designer_ring_count"] = len(centers)
    curve_obj["character_designer_generator"] = "selected_hair_strip_v3"
    curve_data["character_designer_metrics_schema"] = "hair_loop_metrics_v3"
    _store_curve_metrics(
        curve_obj,
        metrics,
        segment_normals,
        radii,
        tilts,
        radius_info,
        settings,
    )

    if settings.copy_material and source_obj.data.materials:
        curve_data.materials.append(source_obj.data.materials[0])
    return curve_obj


def _d_profile_objects():
    return [
        obj
        for obj in bpy.data.objects
        if obj.type == "CURVE"
        and obj.get("character_designer_profile") == "D_8_POINT"
    ]


def _profile_consumers(profile_object):
    return [
        obj
        for obj in bpy.data.objects
        if obj.type == "CURVE"
        and getattr(obj.data, "bevel_object", None) == profile_object
    ]


class CHARACTERDESIGNER_OT_create_d_profile(Operator):
    bl_idname = "character_designer.create_d_hair_profile"
    bl_label = "Create D Profile"
    bl_description = "Create an eight-point D-shaped bevel profile for anime hair"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.character_designer_hair
        size = settings.profile_size
        profiles = _d_profile_objects()
        matching = next(
            (
                profile
                for profile in profiles
                if abs(_profile_max_width(profile) - size) <= max(EPSILON, size * 1.0e-6)
            ),
            None,
        )
        if matching is not None:
            matching["character_designer_max_width"] = size
            settings.profile_object = matching
            self.report({"INFO"}, "Using the matching Character Designer D profile")
            return {"FINISHED"}

        existing = next(
            (profile for profile in profiles if not _profile_consumers(profile)),
            None,
        )
        if existing is not None:
            existing.scale = (1.0, 1.0, 1.0)
            _write_d_profile_data(existing.data, settings.profile_size)
            existing["character_designer_max_width"] = settings.profile_size
            settings.profile_object = existing
            self.report({"INFO"}, "Updated the Character Designer D profile")
            return {"FINISHED"}

        curve_data = bpy.data.curves.new(f"{PROFILE_OBJECT_NAME}_Data", type="CURVE")
        _write_d_profile_data(curve_data, size)

        profile_obj = bpy.data.objects.new(PROFILE_OBJECT_NAME, curve_data)
        collection = bpy.data.collections.get(PROFILE_COLLECTION_NAME)
        if collection is None:
            collection = bpy.data.collections.new(PROFILE_COLLECTION_NAME)
            context.scene.collection.children.link(collection)
        collection.objects.link(profile_obj)
        profile_obj.display_type = "WIRE"
        profile_obj.show_in_front = True
        profile_obj.hide_render = True
        profile_obj["character_designer_profile"] = "D_8_POINT"
        profile_obj["character_designer_max_width"] = size
        settings.profile_object = profile_obj
        try:
            profile_obj.hide_set(True)
        except RuntimeError:
            pass

        self.report({"INFO"}, "Created an eight-point D hair profile")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_selected_hair_strip_to_curve(Operator):
    bl_idname = "character_designer.selected_hair_strip_to_curve"
    bl_label = "Selected Hair Strip to Curve"
    bl_description = "Extract one curve point per topology layer, starting from the active root face"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.edit_object
        return context.mode == "EDIT_MESH" and obj is not None and obj.type == "MESH"

    def execute(self, context):
        source_obj = context.edit_object
        bm = bmesh.from_edit_mesh(source_obj.data)
        bm.faces.ensure_lookup_table()
        active_face = bm.faces.active
        selected_faces = [face for face in bm.faces if face.select]

        if active_face is None or not active_face.select:
            self.report({"ERROR"}, "Select the root cross-section last so it is the active face")
            return {"CANCELLED"}
        if not 3 <= len(active_face.verts) <= 16:
            self.report({"ERROR"}, "The active root face must be a 3-16 sided cross-section")
            return {"CANCELLED"}

        component_faces = _active_selected_component(active_face, selected_faces)
        if not component_faces:
            self.report({"ERROR"}, "No connected selected hair faces were found")
            return {"CANCELLED"}

        layers, distances = _distance_layers(active_face, component_faces)
        if len(layers) < 2:
            self.report({"ERROR"}, "Grow the selection outward by at least one topology layer")
            return {"CANCELLED"}
        if any(not layer for layer in layers):
            self.report({"ERROR"}, "The selected topology does not form continuous layers")
            return {"CANCELLED"}

        centers, world_layers = _layer_centers(source_obj, layers)
        if any(
            (centers[index] - centers[index - 1]).length <= EPSILON
            for index in range(1, len(centers))
        ):
            self.report(
                {"ERROR"},
                "Two extracted layers share the same center; check the root face and selection",
            )
            return {"CANCELLED"}

        settings = context.scene.character_designer_hair
        if settings.profile_object is not None:
            if not _profile_is_supported(settings.profile_object):
                self.report(
                    {"ERROR"},
                    "Profile must contain only Poly or Bézier splines",
                )
                return {"CANCELLED"}
            if _profile_max_width(settings.profile_object) <= EPSILON:
                self.report(
                    {"ERROR"},
                    "The selected Profile has zero width",
                )
                return {"CANCELLED"}
        tangents = _point_tangents(centers)
        reference_point = (
            settings.orientation_center.matrix_world.translation
            if settings.orientation_center is not None
            else source_obj.matrix_world.translation
        )
        segment_normals = _continuous_guide_normals(
            source_obj,
            active_face,
            component_faces,
            distances,
            len(centers) - 1,
            reference_point,
        )
        point_normals = _point_source_normals(tangents, segment_normals)
        metrics = _layer_metrics(world_layers, centers, tangents, point_normals)
        source_widths = [metric["max_width"] for metric in metrics]
        tilts = _point_tilts(tangents, point_normals, settings)
        radii, bevel_depth, radius_info = _curve_point_radii(
            source_widths,
            settings,
        )
        curve_obj = _create_curve_object(
            context,
            source_obj,
            centers,
            tangents,
            radii,
            tilts,
            bevel_depth,
            metrics,
            segment_normals,
            radius_info,
            settings,
        )

        settings.last_loop_count = len(metrics)
        settings.last_root_width = source_widths[0]
        settings.last_min_width = min(source_widths)
        settings.last_max_width = max(source_widths)
        settings.last_status = curve_obj.name

        ignored = len(selected_faces) - len(component_faces)
        message = f"Created {curve_obj.name} with {len(centers)} points"
        if ignored > 0:
            message += f"; ignored {ignored} disconnected selected faces"
        self.report({"INFO"}, message)
        return {"FINISHED"}


def draw_hair_curve_tools(layout, context):
    settings = context.scene.character_designer_hair

    instructions = layout.box()
    instructions.label(text="1. Select the root cross-section last", icon="FACESEL")
    instructions.label(text="2. Ctrl+Numpad+ to grow toward the tip")

    action = layout.column(align=True)
    action.scale_y = 1.25
    action.operator(
        "character_designer.selected_hair_strip_to_curve",
        text="Selected Strip to Curve",
        icon="CURVE_BEZCURVE",
    )
    if context.mode != "EDIT_MESH":
        action.enabled = False

    profile_box = layout.box()
    profile_box.label(text="Bevel Profile")
    profile_box.prop(settings, "profile_object")
    row = profile_box.row(align=True)
    row.prop(settings, "profile_size")
    row.operator(
        "character_designer.create_d_hair_profile",
        text="Create D",
        icon="CURVE_NCIRCLE",
    )

    shape_box = layout.box()
    shape_box.label(text="Generated Shape")
    shape_box.prop(settings, "match_source_width")
    shape_box.prop(settings, "radius_scale")
    shape_box.prop(settings, "resolution_u")
    shape_box.prop(settings, "fill_caps")
    shape_box.prop(settings, "copy_material")

    tilt_box = layout.box()
    tilt_box.label(text="Orientation")
    tilt_box.prop(settings, "orientation_center")
    if settings.orientation_center is None:
        tilt_box.label(text="Optional: assign the head/body center", icon="INFO")
    tilt_box.prop(settings, "use_source_tilt")
    row = tilt_box.row(align=True)
    row.prop(settings, "flip_tilt")
    row.prop(settings, "tilt_offset")

    if settings.last_status:
        result_box = layout.box()
        result_box.label(text=f"Last: {settings.last_status}", icon="CHECKMARK")
        result_box.label(text="Exact projected loop spans")
        values = result_box.column(align=True)
        values.enabled = False
        values.prop(settings, "last_loop_count")
        values.prop(settings, "last_root_width")
        values.prop(settings, "last_min_width")
        values.prop(settings, "last_max_width")


CHARACTER_DESIGNER_HAIR_CLASSES = (
    CharacterDesignerHairSettings,
    CHARACTERDESIGNER_OT_create_d_profile,
    CHARACTERDESIGNER_OT_selected_hair_strip_to_curve,
)
