import json
import math
from collections import defaultdict, deque

import bmesh
import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, PropertyGroup
from mathutils import Vector
from mathutils.geometry import interpolate_bezier


PROFILE_OBJECT_NAME = "CD_D_Hair_Profile"
PROFILE_COLLECTION_NAME = "Character Designer Profiles"
EPSILON = 1.0e-8
METRICS_SCHEMA = "hair_loop_metrics_v3"
GENERATOR_ID = "selected_hair_strip_v4"
D_PROFILE_BASE_POINTS = (
    (-0.18, -0.50),
    (0.08, -0.50),
    (0.25, -0.36),
    (0.32, 0.00),
    (0.25, 0.36),
    (0.08, 0.50),
    (-0.18, 0.50),
    (-0.18, 0.00),
)


def _profile_is_supported(obj):
    if obj is None or obj.type != "CURVE":
        return False
    data = obj.data
    if data.dimensions != "2D" or len(data.splines) != 1:
        return False
    spline = data.splines[0]
    point_count = (
        len(spline.bezier_points) if spline.type == "BEZIER" else len(spline.points)
    )
    return (
        spline.type in {"POLY", "BEZIER"}
        and spline.use_cyclic_u
        and point_count >= 3
        and abs(data.extrude) <= EPSILON
        and abs(data.bevel_depth) <= EPSILON
        and data.taper_object is None
        and len(obj.modifiers) == 0
    )


def _curve_profile_poll(_self, obj):
    return _profile_is_supported(obj)


def _is_generated_hair_curve(obj):
    return (
        obj is not None
        and obj.type == "CURVE"
        and obj.get("character_designer_metrics_schema") == METRICS_SCHEMA
        and bool(obj.get("character_designer_loop_metrics_json"))
    )


def _generated_hair_curve_poll(_self, obj):
    return _is_generated_hair_curve(obj)


class HairAnalysisError(ValueError):
    """A selection or stored-output problem that can be shown to the artist."""


def _scaled_d_profile_points(size):
    base_max_width = max(
        math.hypot(second[0] - first[0], second[1] - first[1])
        for first_index, first in enumerate(D_PROFILE_BASE_POINTS)
        for second in D_PROFILE_BASE_POINTS[first_index + 1 :]
    )
    profile_scale = size / base_max_width
    return [
        (x_value * profile_scale, y_value * profile_scale)
        for x_value, y_value in D_PROFILE_BASE_POINTS
    ]


def _write_d_profile_data(curve_data, size):
    curve_data.splines.clear()
    curve_data.dimensions = "2D"
    curve_data.resolution_u = 1
    curve_data.render_resolution_u = 1
    curve_data.fill_mode = "BOTH"
    coordinates = _scaled_d_profile_points(size)
    spline = curve_data.splines.new(type="POLY")
    spline.points.add(len(coordinates) - 1)
    for point, (x_value, y_value) in zip(spline.points, coordinates):
        point.co = (x_value, y_value, 0.0, 1.0)
    spline.use_cyclic_u = True


class CharacterDesignerLoopMetric(PropertyGroup):
    loop_index: IntProperty(name="Loop", default=0, min=0)
    vertex_count: IntProperty(name="Vertices", default=0, min=0)
    max_width: FloatProperty(name="Longest Span", subtype="DISTANCE", min=0.0)
    raw_span: FloatProperty(name="Raw 3D Span", subtype="DISTANCE", min=0.0)
    width_span: FloatProperty(name="Width-Axis Span", subtype="DISTANCE", min=0.0)
    thickness: FloatProperty(name="Thickness", subtype="DISTANCE", min=0.0)
    curve_radius: FloatProperty(name="Curve Radius", min=0.0)
    curve_tilt: FloatProperty(name="Curve Tilt", subtype="ANGLE")
    source_normal: FloatVectorProperty(name="Source Normal", size=3, subtype="XYZ")
    max_width_axis: FloatVectorProperty(name="Max-Span Axis", size=3, subtype="XYZ")
    raw_span_axis: FloatVectorProperty(name="Raw-Span Axis", size=3, subtype="XYZ")
    profile_width_axis: FloatVectorProperty(name="Profile Width Axis", size=3, subtype="XYZ")


class CharacterDesignerHairSettings(PropertyGroup):
    profile_object: PointerProperty(
        name="Profile",
        description="Curve object used as the generated hair curve's bevel profile",
        type=bpy.types.Object,
        poll=_curve_profile_poll,
    )
    profile_size: FloatProperty(
        name="D Profile Base Width",
        description=(
            "Exact maximum span of a D profile; with Match Source Width enabled, "
            "this changes the reusable base profile rather than final hair width"
        ),
        subtype="DISTANCE",
        default=0.01,
        min=0.0001,
        soft_max=0.05,
        precision=4,
    )
    match_source_width: BoolProperty(
        name="Match Source Width",
        description="Set point Radius from exact source-loop max width divided by profile max width",
        default=True,
    )
    radius_scale: FloatProperty(
        name="Width Scale",
        description=(
            "Non-destructive multiplier applied to measured source widths; "
            "Update Output reapplies it without compounding"
        ),
        default=1.0,
        min=0.01,
        soft_max=4.0,
    )
    resolution_u: IntProperty(
        name="Curve Resolution",
        description="Preview and render resolution between Bezier points",
        default=8,
        min=1,
        max=64,
    )
    use_source_tilt: BoolProperty(
        name="Follow Source Twist",
        description="Estimate curve tilt from a continuous side of the selected source strand",
        default=True,
    )
    orientation_center: PointerProperty(
        name="Orientation Center",
        description="Optional head/body object used to choose the source side normal that points outward",
        type=bpy.types.Object,
    )
    flip_tilt: BoolProperty(
        name="Flip Tilt",
        description="Rotate the profile 180 degrees around the strand",
        default=False,
    )
    tilt_offset: FloatProperty(
        name="Tilt Offset",
        description="Additional rotation of the profile around the strand",
        subtype="ANGLE",
        default=0.0,
    )
    fill_caps: BoolProperty(
        name="Fill Caps",
        description="Fill the two ends when a bevel profile is assigned",
        default=True,
    )
    copy_material: BoolProperty(
        name="Copy Material",
        description="Copy the source mesh's first material slot to the generated curve",
        default=True,
    )
    output_curve: PointerProperty(
        name="Output Curve",
        description="Generated Character Designer hair curve to update or select",
        type=bpy.types.Object,
        poll=_generated_hair_curve_poll,
    )
    show_advanced: BoolProperty(
        name="Advanced",
        description="Show lower-frequency curve and material settings",
        default=False,
    )
    show_loop_metrics: BoolProperty(
        name="Loop Measurements",
        description="Show exact measurements cached by Analyze Selection",
        default=False,
    )
    analysis_signature: StringProperty(default="", options={"HIDDEN"})
    analysis_status: StringProperty(default="", options={"HIDDEN"})
    analysis_warning: StringProperty(default="", options={"HIDDEN"})
    analysis_ready: BoolProperty(default=False, options={"HIDDEN"})
    analysis_selected_face_count: IntProperty(default=0, min=0, options={"HIDDEN"})
    analysis_connected_face_count: IntProperty(default=0, min=0, options={"HIDDEN"})
    analysis_ignored_face_count: IntProperty(default=0, min=0, options={"HIDDEN"})
    analysis_root_sides: IntProperty(default=0, min=0, options={"HIDDEN"})
    analysis_loop_count: IntProperty(default=0, min=0, options={"HIDDEN"})
    analysis_root_width: FloatProperty(
        default=0.0, min=0.0, subtype="DISTANCE", options={"HIDDEN"}
    )
    analysis_tip_width: FloatProperty(
        default=0.0, min=0.0, subtype="DISTANCE", options={"HIDDEN"}
    )
    analysis_min_width: FloatProperty(
        default=0.0, min=0.0, subtype="DISTANCE", options={"HIDDEN"}
    )
    analysis_max_width: FloatProperty(
        default=0.0, min=0.0, subtype="DISTANCE", options={"HIDDEN"}
    )
    analysis_profile_object: PointerProperty(
        type=bpy.types.Object,
        poll=_curve_profile_poll,
        options={"HIDDEN", "SKIP_SAVE"},
    )
    analysis_profile_width: FloatProperty(
        default=0.0, min=0.0, subtype="DISTANCE", options={"HIDDEN"}
    )
    analysis_normal_quality: StringProperty(default="", options={"HIDDEN"})
    analysis_loops: CollectionProperty(
        type=CharacterDesignerLoopMetric,
        options={"HIDDEN", "SKIP_SAVE"},
    )
    analysis_loop_index: IntProperty(default=0, min=0, options={"HIDDEN"})
    last_status: StringProperty(
        name="Last Extraction",
        default="",
        options={"HIDDEN"},
    )
    last_loop_count: IntProperty(
        name="Loops",
        default=0,
        min=0,
        options={"HIDDEN"},
    )
    last_root_width: FloatProperty(
        name="Root Max Width",
        subtype="DISTANCE",
        default=0.0,
        min=0.0,
        options={"HIDDEN"},
    )
    last_tip_width: FloatProperty(
        name="Tip Max Width",
        subtype="DISTANCE",
        default=0.0,
        min=0.0,
        options={"HIDDEN"},
    )
    last_min_width: FloatProperty(
        name="Minimum Max Width",
        subtype="DISTANCE",
        default=0.0,
        min=0.0,
        options={"HIDDEN"},
    )
    last_max_width: FloatProperty(
        name="Maximum Max Width",
        subtype="DISTANCE",
        default=0.0,
        min=0.0,
        options={"HIDDEN"},
    )


def _profile_validation_error(profile_object):
    if profile_object is None:
        return None
    if not _profile_is_supported(profile_object):
        return (
            "Profile must be one closed 2D Poly/Bezier spline with no Extrude, "
            "Bevel, Taper, or modifiers"
        )
    if _profile_max_width(profile_object) <= EPSILON:
        return "The selected Profile has zero width"
    return None


def _light_selection_state(context):
    state = {
        "ready": False,
        "message": "Enter Mesh Edit Mode and select a root face",
        "signature": "",
        "object": None,
        "active_face": None,
        "selected_face_count": 0,
        "root_sides": 0,
    }
    source_obj = getattr(context, "edit_object", None)
    if context.mode != "EDIT_MESH" or source_obj is None or source_obj.type != "MESH":
        return state

    edit_objects = tuple(getattr(context, "objects_in_mode_unique_data", ()) or ())
    if len(edit_objects) > 1:
        state["message"] = "Use single-object Edit Mode for precise extraction"
        return state
    if not context.tool_settings.mesh_select_mode[2]:
        state["message"] = "Switch to Face Select mode (3)"
        return state

    try:
        bm = bmesh.from_edit_mesh(source_obj.data)
        bm.faces.ensure_lookup_table()
        active_face = bm.faces.active
        selected_indices = [face.index for face in bm.faces if face.select]
    except (ReferenceError, RuntimeError, ValueError):
        state["message"] = "The edit selection is updating; try again"
        return state

    state["object"] = source_obj
    state["active_face"] = active_face
    state["selected_face_count"] = len(selected_indices)
    state["root_sides"] = len(active_face.verts) if active_face is not None else 0

    active_index = active_face.index if active_face is not None else -1
    selected_sum = sum(selected_indices)
    selected_square_sum = sum(index * index for index in selected_indices)
    matrix_signature = ",".join(
        f"{value:.7g}" for row in source_obj.matrix_world for value in row
    )
    state["signature"] = (
        f"{source_obj.as_pointer()}:{source_obj.data.as_pointer()}:{active_index}:"
        f"{len(selected_indices)}:{selected_sum}:{selected_square_sum}:{matrix_signature}"
    )

    if active_face is None or not active_face.select:
        state["message"] = "Select the root cross-section last (active face)"
        return state
    if not 3 <= len(active_face.verts) <= 16:
        state["message"] = "Active root must be a 3-16 sided cross-section"
        return state
    if len(selected_indices) < 2:
        state["message"] = "Grow the root selection toward the tip"
        return state

    state["ready"] = True
    state["message"] = (
        f"Root {len(active_face.verts)}-gon · {len(selected_indices)} selected faces"
    )
    return state


def _analyze_selected_hair(context, settings):
    light_state = _light_selection_state(context)
    if not light_state["ready"]:
        raise HairAnalysisError(light_state["message"])

    source_obj = light_state["object"]
    bm = bmesh.from_edit_mesh(source_obj.data)
    bm.faces.ensure_lookup_table()
    active_face = bm.faces.active
    selected_faces = [face for face in bm.faces if face.select]
    component_faces = _active_selected_component(active_face, selected_faces)
    if not component_faces:
        raise HairAnalysisError("No connected selected hair faces were found")

    layers, distances = _distance_layers(active_face, component_faces)
    if len(layers) < 2:
        raise HairAnalysisError("Grow the selection outward by at least one topology layer")
    component_vertices = {vert for face in component_faces for vert in face.verts}
    if len(distances) != len(component_vertices):
        raise HairAnalysisError("The selected topology contains an unreachable branch")
    layers = _validated_ordered_layers(
        active_face,
        component_faces,
        layers,
        distances,
    )

    centers, world_layers = _layer_centers(source_obj, layers)
    if any(
        (centers[index] - centers[index - 1]).length <= EPSILON
        for index in range(1, len(centers))
    ):
        raise HairAnalysisError(
            "Two extracted layers share the same center; check the root and selection"
        )

    profile_error = _profile_validation_error(settings.profile_object)
    if profile_error:
        raise HairAnalysisError(profile_error)

    tangents = _point_tangents(centers)
    reference_point = (
        settings.orientation_center.matrix_world.translation
        if settings.orientation_center is not None
        else source_obj.matrix_world.translation
    )
    segment_count = len(centers) - 1
    candidates = _segment_face_candidates(component_faces, distances, segment_count)
    missing_normal_segments = sum(not faces for faces in candidates)
    segment_normals = _continuous_guide_normals(
        source_obj,
        active_face,
        component_faces,
        distances,
        segment_count,
        reference_point,
    )
    if settings.use_source_tilt and (
        missing_normal_segments or len(segment_normals) != segment_count
    ):
        raise HairAnalysisError(
            "Source-normal tracking is incomplete; check for missing or branched side faces"
        )
    point_normals = _point_source_normals(tangents, segment_normals)
    metrics = _layer_metrics(world_layers, centers, tangents, point_normals)
    source_widths = [metric["max_width"] for metric in metrics]
    if max(source_widths, default=0.0) <= EPSILON:
        raise HairAnalysisError("The extracted cross-sections all have zero width")
    if any(width <= EPSILON for width in source_widths[:-1]):
        raise HairAnalysisError("Only the final layer may collapse to a point tip")

    tilts = _point_tilts(tangents, point_normals, settings)
    radii, bevel_depth, radius_info = _curve_point_radii(source_widths, settings)
    for metric, radius, tilt in zip(metrics, radii, tilts):
        metric["curve_radius"] = radius
        metric["curve_tilt"] = tilt

    ignored_face_count = len(selected_faces) - len(component_faces)
    warnings = []
    if ignored_face_count:
        warnings.append(f"{ignored_face_count} disconnected selected faces will be ignored")
    if settings.orientation_center is None:
        warnings.append("Outward side uses the hair object's origin")
    visible_modifiers = [modifier for modifier in source_obj.modifiers if modifier.show_viewport]
    if visible_modifiers:
        warnings.append("Visible modifiers are not baked into this Edit-cage snapshot")
    if source_obj.parent is not None:
        warnings.append("Output is a world-space snapshot and will not follow the source parent")
    if settings.use_source_tilt and (
        missing_normal_segments or len(segment_normals) != segment_count
    ):
        warnings.append("Some source-normal segments require propagation fallback")

    traced_segments = max(0, segment_count - missing_normal_segments)
    if len(segment_normals) != segment_count:
        traced_segments = 0
    max_normal_turn = 0.0
    for first, second in zip(segment_normals, segment_normals[1:]):
        dot_value = max(-1.0, min(1.0, first.dot(second)))
        max_normal_turn = max(max_normal_turn, math.degrees(math.acos(dot_value)))
    normal_quality = (
        f"Normals {traced_segments}/{segment_count} · max turn {max_normal_turn:.1f}°"
        if settings.use_source_tilt
        else f"Normals stored {segment_count} · source twist off"
    )

    return {
        "signature": light_state["signature"],
        "source_obj": source_obj,
        "active_face": active_face,
        "selected_faces": selected_faces,
        "component_faces": component_faces,
        "layers": layers,
        "distances": distances,
        "centers": centers,
        "world_layers": world_layers,
        "tangents": tangents,
        "segment_normals": segment_normals,
        "point_normals": point_normals,
        "metrics": metrics,
        "source_widths": source_widths,
        "tilts": tilts,
        "radii": radii,
        "bevel_depth": bevel_depth,
        "radius_info": radius_info,
        "selected_face_count": len(selected_faces),
        "connected_face_count": len(component_faces),
        "ignored_face_count": ignored_face_count,
        "root_sides": len(active_face.verts),
        "normal_quality": normal_quality,
        "warnings": warnings,
    }


def _cache_analysis(settings, analysis):
    widths = analysis["source_widths"]
    settings.analysis_signature = analysis["signature"]
    settings.analysis_ready = True
    settings.analysis_status = (
        f"Ready · {len(widths)} loops from {analysis['connected_face_count']} faces"
    )
    settings.analysis_warning = " | ".join(analysis["warnings"])
    settings.analysis_selected_face_count = analysis["selected_face_count"]
    settings.analysis_connected_face_count = analysis["connected_face_count"]
    settings.analysis_ignored_face_count = analysis["ignored_face_count"]
    settings.analysis_root_sides = analysis["root_sides"]
    settings.analysis_loop_count = len(widths)
    settings.analysis_root_width = widths[0]
    settings.analysis_tip_width = widths[-1]
    settings.analysis_min_width = min(widths)
    settings.analysis_max_width = max(widths)
    settings.analysis_profile_object = settings.profile_object
    settings.analysis_profile_width = analysis["radius_info"]["profile_width"]
    settings.analysis_normal_quality = analysis["normal_quality"]
    settings.analysis_loops.clear()
    for metric in analysis["metrics"]:
        item = settings.analysis_loops.add()
        item.loop_index = metric["index"]
        item.vertex_count = metric["vertex_count"]
        item.max_width = metric["max_width"]
        item.raw_span = metric["raw_span"]
        item.width_span = metric["width_span"]
        item.thickness = metric["thickness"]
        item.curve_radius = metric["curve_radius"]
        item.curve_tilt = metric["curve_tilt"]
        item.source_normal = metric["source_normal"]
        item.max_width_axis = metric["width_axis"]
        item.raw_span_axis = metric["raw_span_axis"]
        item.profile_width_axis = metric["profile_width_axis"]
    settings.analysis_loop_index = min(
        settings.analysis_loop_index,
        max(0, len(settings.analysis_loops) - 1),
    )


def _cache_analysis_failure(settings, signature, message):
    settings.analysis_signature = signature
    settings.analysis_ready = False
    settings.analysis_status = message
    settings.analysis_warning = ""
    settings.analysis_normal_quality = ""
    settings.analysis_profile_object = None
    settings.analysis_profile_width = 0.0
    settings.analysis_loops.clear()


def _set_last_result(settings, curve_obj, source_widths):
    settings.output_curve = curve_obj
    settings.last_status = curve_obj.name
    settings.last_loop_count = len(source_widths)
    settings.last_root_width = source_widths[0]
    settings.last_tip_width = source_widths[-1]
    settings.last_min_width = min(source_widths)
    settings.last_max_width = max(source_widths)


def _refresh_cached_curve_values(settings, metrics, radius_info):
    if len(settings.analysis_loops) != len(metrics):
        return
    if any(
        abs(item.max_width - metric["max_width"])
        > max(EPSILON, metric["max_width"] * 1.0e-6)
        for item, metric in zip(settings.analysis_loops, metrics)
    ):
        return
    for item, metric in zip(settings.analysis_loops, metrics):
        item.curve_radius = metric["curve_radius"]
        item.curve_tilt = metric["curve_tilt"]
    settings.analysis_profile_object = settings.profile_object
    settings.analysis_profile_width = radius_info["profile_width"]


def _active_selected_component(active_face, selected_faces):
    selected = set(selected_faces)
    component = set()
    stack = [active_face]
    while stack:
        face = stack.pop()
        if face in component or face not in selected:
            continue
        component.add(face)
        for edge in face.edges:
            for neighbor in edge.link_faces:
                if neighbor in selected and neighbor not in component:
                    stack.append(neighbor)
    return component


def _distance_layers(root_face, component_faces):
    allowed_faces = set(component_faces)
    allowed_vertices = {vert for face in allowed_faces for vert in face.verts}
    allowed_edges = {
        edge
        for face in allowed_faces
        for edge in face.edges
        if edge.verts[0] in allowed_vertices and edge.verts[1] in allowed_vertices
    }

    distances = {}
    queue = deque()
    for vert in root_face.verts:
        distances[vert] = 0
        queue.append(vert)

    while queue:
        vert = queue.popleft()
        next_distance = distances[vert] + 1
        for edge in vert.link_edges:
            if edge not in allowed_edges:
                continue
            other = edge.other_vert(vert)
            if other not in allowed_vertices or other in distances:
                continue
            distances[other] = next_distance
            queue.append(other)

    layers = defaultdict(list)
    for vert, distance in distances.items():
        layers[distance].append(vert)
    return [layers[index] for index in sorted(layers)], distances


def _ordered_cycle(layer, component_faces, layer_index):
    layer_set = set(layer)
    layer_edges = {
        edge
        for face in component_faces
        for edge in face.edges
        if edge.verts[0] in layer_set and edge.verts[1] in layer_set
    }
    neighbors = {vert: [] for vert in layer}
    for edge in layer_edges:
        first, second = edge.verts
        neighbors[first].append(second)
        neighbors[second].append(first)
    if any(len(linked) != 2 for linked in neighbors.values()):
        raise HairAnalysisError(
            f"Layer {layer_index} is not one closed cross-section loop"
        )

    start = min(layer, key=lambda vert: vert.index)
    previous = None
    current = start
    ordered = []
    while current not in ordered:
        ordered.append(current)
        choices = [neighbor for neighbor in neighbors[current] if neighbor is not previous]
        if not choices:
            break
        next_vert = min(choices, key=lambda vert: vert.index)
        previous, current = current, next_vert
    if len(ordered) != len(layer) or current is not start:
        raise HairAnalysisError(
            f"Layer {layer_index} contains a split or disconnected ring"
        )
    return ordered


def _validated_ordered_layers(root_face, component_faces, layers, distances):
    if any(len(layer) == 1 for layer in layers[:-1]):
        raise HairAnalysisError("A point tip is only supported on the final topology layer")

    component_set = set(component_faces)
    component_edges = {edge for face in component_faces for edge in face.edges}
    for edge in component_edges:
        selected_links = [face for face in edge.link_faces if face in component_set]
        if len(selected_links) >= 2 and (
            not edge.is_manifold or not edge.is_contiguous
        ):
            raise HairAnalysisError(
                f"Face winding is inconsistent or non-manifold at edge {edge.index}"
            )

    last_index = len(layers) - 1
    same_level_faces = defaultdict(list)
    segment_faces = defaultdict(list)
    for face in component_faces:
        levels = sorted({distances[vert] for vert in face.verts})
        if len(levels) == 1:
            same_level_faces[levels[0]].append(face)
        elif len(levels) == 2 and levels[1] == levels[0] + 1:
            segment_faces[levels[0]].append(face)
        else:
            raise HairAnalysisError(
                f"Face {face.index} skips topology layers or crosses a branch"
            )

    if same_level_faces.get(0) != [root_face]:
        raise HairAnalysisError("The active face must be the only selected root cap")
    for layer_index, faces in same_level_faces.items():
        if layer_index == 0:
            continue
        if layer_index != last_index or len(faces) != 1:
            raise HairAnalysisError(
                f"Unexpected cap or internal face on layer {layer_index}"
            )
        if set(faces[0].verts) != set(layers[layer_index]):
            raise HairAnalysisError("The selected tip cap does not match the final loop")

    ordered_layers = []
    for layer_index, layer in enumerate(layers):
        if len(layer) == 1:
            if layer_index != last_index:
                raise HairAnalysisError("Only the final layer may be a point tip")
            ordered_layers.append(list(layer))
        elif len(layer) < 3:
            raise HairAnalysisError(
                f"Layer {layer_index} has fewer than three cross-section vertices"
            )
        else:
            ordered_layers.append(
                _ordered_cycle(layer, component_faces, layer_index)
            )

    for segment in range(last_index):
        band = segment_faces.get(segment, [])
        if not band:
            raise HairAnalysisError(f"No side faces connect layers {segment} and {segment + 1}")
        current_set = set(layers[segment])
        next_set = set(layers[segment + 1])
        band_set = set(band)

        ring_edges = {
            edge
            for face in component_faces
            for edge in face.edges
            if (
                edge.verts[0] in current_set and edge.verts[1] in current_set
            )
            or (edge.verts[0] in next_set and edge.verts[1] in next_set)
        }
        for edge in ring_edges:
            coverage = sum(face in band_set for face in edge.link_faces)
            if coverage != 1:
                raise HairAnalysisError(
                    f"Layer {segment} side band is incomplete or non-manifold"
                )

        cross_edges = {
            edge
            for face in band
            for edge in face.edges
            if (
                edge.verts[0] in current_set and edge.verts[1] in next_set
            )
            or (edge.verts[1] in current_set and edge.verts[0] in next_set)
        }
        touched_current = {
            vert for edge in cross_edges for vert in edge.verts if vert in current_set
        }
        touched_next = {
            vert for edge in cross_edges for vert in edge.verts if vert in next_set
        }
        if touched_current != current_set or touched_next != next_set:
            raise HairAnalysisError(
                f"Layers {segment} and {segment + 1} are only partially connected"
            )
        for edge in cross_edges:
            coverage = sum(face in band_set for face in edge.link_faces)
            if coverage != 2:
                raise HairAnalysisError(
                    f"Layers {segment} and {segment + 1} contain an open or branched edge"
                )

        connected = set()
        stack = [band[0]]
        while stack:
            face = stack.pop()
            if face in connected:
                continue
            connected.add(face)
            for edge in face.edges:
                for neighbor in edge.link_faces:
                    if neighbor in band_set and neighbor not in connected:
                        stack.append(neighbor)
        if connected != band_set:
            raise HairAnalysisError(
                f"The side band between layers {segment} and {segment + 1} is split"
            )

    return ordered_layers


def _world_face_normal(source_obj, face):
    normal_matrix = source_obj.matrix_world.to_3x3().inverted_safe().transposed()
    normal = normal_matrix @ face.normal
    if normal.length_squared <= EPSILON:
        return Vector((0.0, 0.0, 1.0))
    return normal.normalized()


def _world_face_area(source_obj, face):
    points = [source_obj.matrix_world @ vert.co for vert in face.verts]
    if len(points) < 3:
        return 0.0
    origin = points[0]
    area = 0.0
    for index in range(1, len(points) - 1):
        area += (points[index] - origin).cross(points[index + 1] - origin).length * 0.5
    return area


def _world_face_center(source_obj, face):
    return source_obj.matrix_world @ face.calc_center_median()


def _world_edge_length(source_obj, edge):
    first = source_obj.matrix_world @ edge.verts[0].co
    second = source_obj.matrix_world @ edge.verts[1].co
    return (second - first).length


def _layer_centers(source_obj, layers):
    matrix = source_obj.matrix_world
    centers = []
    world_layers = []
    for layer in layers:
        points = [matrix @ vert.co for vert in layer]
        if len(points) < 3:
            center = sum(points, Vector()) / len(points)
        else:
            origin = points[0]
            weighted_center = Vector()
            total_area = 0.0
            for index in range(1, len(points) - 1):
                first = points[index]
                second = points[index + 1]
                area = (first - origin).cross(second - origin).length * 0.5
                weighted_center += (origin + first + second) / 3.0 * area
                total_area += area
            center = (
                weighted_center / total_area
                if total_area > EPSILON
                else sum(points, Vector()) / len(points)
            )
        centers.append(center)
        world_layers.append(points)
    return centers, world_layers


def _point_tangents(centers):
    tangents = []
    for index, center in enumerate(centers):
        if index == 0:
            tangent = centers[1] - center
        elif index == len(centers) - 1:
            tangent = center - centers[index - 1]
        else:
            tangent = centers[index + 1] - centers[index - 1]
        if tangent.length_squared <= EPSILON:
            tangent = Vector((0.0, 0.0, 1.0))
        tangents.append(tangent.normalized())
    return tangents


def _maximum_projected_width(points, tangent):
    maximum = 0.0
    width_axis = None
    for first_index, first in enumerate(points):
        for second in points[first_index + 1 :]:
            difference = second - first
            difference -= tangent * difference.dot(tangent)
            width = difference.length
            if width > maximum:
                maximum = width
                width_axis = difference.normalized() if width > EPSILON else None
    return maximum, width_axis


def _maximum_raw_span(points):
    maximum = 0.0
    axis = None
    for first_index, first in enumerate(points):
        for second in points[first_index + 1 :]:
            difference = second - first
            span = difference.length
            if span > maximum:
                maximum = span
                axis = difference.normalized() if span > EPSILON else None
    return maximum, axis


def _layer_metrics(world_layers, centers, tangents, point_normals):
    metrics = []
    previous_width_axis = None
    previous_profile_width_axis = None
    for index, (points, center, tangent, source_normal) in enumerate(
        zip(world_layers, centers, tangents, point_normals)
    ):
        max_width, width_axis = _maximum_projected_width(points, tangent)
        raw_span, raw_span_axis = _maximum_raw_span(points)
        if width_axis is None:
            width_axis = _z_up_reference(tangent)
        if previous_width_axis is not None and width_axis.dot(previous_width_axis) < 0.0:
            width_axis.negate()
        previous_width_axis = width_axis.copy()

        source_normal = _projected_normal(source_normal, tangent)
        profile_width_axis = source_normal.cross(tangent)
        if profile_width_axis.length_squared <= EPSILON:
            profile_width_axis = width_axis.copy()
        else:
            profile_width_axis.normalize()
        if (
            previous_profile_width_axis is not None
            and profile_width_axis.dot(previous_profile_width_axis) < 0.0
        ):
            profile_width_axis.negate()
        previous_profile_width_axis = profile_width_axis.copy()

        normal_coordinates = [(point - center).dot(source_normal) for point in points]
        width_coordinates = [
            (point - center).dot(profile_width_axis) for point in points
        ]
        thickness = (
            max(normal_coordinates) - min(normal_coordinates)
            if normal_coordinates
            else 0.0
        )
        width_span = (
            max(width_coordinates) - min(width_coordinates)
            if width_coordinates
            else 0.0
        )
        metrics.append(
            {
                "index": index,
                "center": center.copy(),
                "tangent": tangent.copy(),
                "source_normal": source_normal.copy(),
                "width_axis": width_axis.copy(),
                "profile_width_axis": profile_width_axis.copy(),
                "max_width": max_width,
                "raw_span": raw_span,
                "raw_span_axis": (
                    raw_span_axis.copy()
                    if raw_span_axis is not None
                    else width_axis.copy()
                ),
                "width_span": width_span,
                "thickness": thickness,
                "vertex_count": len(points),
            }
        )
    return metrics


def _segment_face_candidates(component_faces, distances, segment_count):
    candidates = [[] for _ in range(segment_count)]
    for face in component_faces:
        levels = sorted({distances[vert] for vert in face.verts if vert in distances})
        if len(levels) != 2 or levels[1] != levels[0] + 1:
            continue
        segment = levels[0]
        if 0 <= segment < segment_count:
            candidates[segment].append(face)
    return candidates


def _patch_normal(source_obj, faces):
    weighted = Vector()
    for face in faces:
        weighted += _world_face_normal(source_obj, face) * _world_face_area(
            source_obj,
            face,
        )
    if weighted.length_squared <= EPSILON:
        return _world_face_normal(source_obj, faces[0])
    return weighted.normalized()


def _patch_center(source_obj, faces):
    total_area = sum(_world_face_area(source_obj, face) for face in faces)
    if total_area <= EPSILON:
        return _world_face_center(source_obj, faces[0])
    return sum(
        (
            _world_face_center(source_obj, face)
            * _world_face_area(source_obj, face)
            for face in faces
        ),
        Vector(),
    ) / total_area


def _farthest_vertex_pair(source_obj, vertices):
    vertices = list(vertices)
    if len(vertices) <= 2:
        return vertices
    matrix = source_obj.matrix_world
    return list(
        max(
            (
                (first, second)
                for first_index, first in enumerate(vertices)
                for second in vertices[first_index + 1 :]
            ),
            key=lambda pair: (matrix @ pair[0].co - matrix @ pair[1].co).length_squared,
        )
    )


def _trace_segment_patch(
    source_obj,
    segment_faces,
    current_ring_vertices,
    distances,
    segment,
    reference_point,
    previous_normal=None,
):
    current_ring_vertices = set(current_ring_vertices)
    if not segment_faces or not current_ring_vertices:
        return [], [], None

    starts = [
        face
        for face in segment_faces
        if current_ring_vertices.issubset(set(face.verts))
    ]
    if not starts:
        maximum_overlap = max(
            len(current_ring_vertices.intersection(face.verts))
            for face in segment_faces
        )
        starts = [
            face
            for face in segment_faces
            if len(current_ring_vertices.intersection(face.verts)) == maximum_overlap
        ]

    if previous_normal is not None:
        start = max(
            starts,
            key=lambda face: (
                previous_normal.dot(_world_face_normal(source_obj, face)),
                -face.index,
            ),
        )
    else:
        start = max(
            starts,
            key=lambda face: (
                _world_face_normal(source_obj, face).dot(
                    _world_face_center(source_obj, face) - reference_point
                ),
                -face.index,
            ),
        )

    patch = [start]
    patch_set = {start}
    far_vertices = {
        vert
        for vert in start.verts
        if distances.get(vert) == segment + 1
    }
    segment_face_set = set(segment_faces)
    available_far_vertices = {
        vert
        for face in segment_faces
        for vert in face.verts
        if distances.get(vert) == segment + 1
    }
    target_far_count = min(2, len(available_far_vertices))
    while (
        len(far_vertices) < target_far_count
        and len(patch_set) < len(segment_face_set)
    ):
        current_normal = _patch_normal(source_obj, patch)
        neighbors = []
        for patch_face in patch:
            for edge in patch_face.edges:
                edge_levels = {distances.get(vert) for vert in edge.verts}
                if edge_levels != {segment, segment + 1}:
                    continue
                for neighbor in edge.link_faces:
                    if neighbor in segment_face_set and neighbor not in patch_set:
                        neighbors.append((neighbor, edge))
        if not neighbors:
            break
        neighbor, _shared_edge = max(
            neighbors,
            key=lambda item: (
                current_normal.dot(_world_face_normal(source_obj, item[0])),
                _world_edge_length(source_obj, item[1]),
                -item[0].index,
            ),
        )
        patch.append(neighbor)
        patch_set.add(neighbor)
        far_vertices.update(
            vert
            for vert in neighbor.verts
            if distances.get(vert) == segment + 1
        )

    far_vertices = _farthest_vertex_pair(source_obj, far_vertices)
    return patch, far_vertices, _patch_normal(source_obj, patch)


def _continuous_guide_normals(
    source_obj,
    root_face,
    component_faces,
    distances,
    segment_count,
    reference_point,
):
    candidates = _segment_face_candidates(component_faces, distances, segment_count)
    if not candidates or not candidates[0]:
        return []

    longest_root_edge = max(_world_edge_length(source_obj, edge) for edge in root_face.edges)
    width_edges = [
        edge
        for edge in root_face.edges
        if _world_edge_length(source_obj, edge) >= longest_root_edge * 0.9
    ]
    first_choices = []
    for root_edge in width_edges:
        patch, far_vertices, normal = _trace_segment_patch(
            source_obj,
            candidates[0],
            root_edge.verts,
            distances,
            0,
            reference_point,
        )
        if patch and normal is not None:
            first_choices.append(
                (
                    normal.dot(_patch_center(source_obj, patch) - reference_point),
                    -min(face.index for face in patch),
                    far_vertices,
                    normal,
                )
            )
    if not first_choices:
        return []

    _score, _tie_breaker, current_ring_vertices, previous_normal = max(
        first_choices,
        key=lambda choice: (choice[0], choice[1]),
    )
    normals = [previous_normal.copy()]
    for segment in range(1, segment_count):
        patch, far_vertices, normal = _trace_segment_patch(
            source_obj,
            candidates[segment],
            current_ring_vertices,
            distances,
            segment,
            reference_point,
            previous_normal=previous_normal,
        )
        if not patch or normal is None:
            normals.append(previous_normal.copy())
            continue
        normals.append(normal.copy())
        current_ring_vertices = far_vertices
        previous_normal = normal
    return normals


def _projected_normal(vector, tangent):
    projected = vector - tangent * vector.dot(tangent)
    if projected.length_squared <= EPSILON:
        for fallback in (Vector((0.0, 0.0, 1.0)), Vector((0.0, 1.0, 0.0)), Vector((1.0, 0.0, 0.0))):
            projected = fallback - tangent * fallback.dot(tangent)
            if projected.length_squared > EPSILON:
                break
    return projected.normalized()


def _z_up_reference(tangent):
    for axis in (Vector((0.0, 0.0, 1.0)), Vector((0.0, 1.0, 0.0)), Vector((1.0, 0.0, 0.0))):
        reference = axis - tangent * axis.dot(tangent)
        if reference.length_squared > EPSILON:
            return reference.normalized()
    return Vector((1.0, 0.0, 0.0))


def _z_up_profile_x_reference(tangent):
    reference = tangent.cross(Vector((0.0, 0.0, 1.0)))
    if reference.length_squared > EPSILON:
        return reference.normalized()
    for axis in (Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0))):
        reference = axis - tangent * axis.dot(tangent)
        if reference.length_squared > EPSILON:
            return reference.normalized()
    return Vector((1.0, 0.0, 0.0))


def _signed_angle_around_axis(reference, target, axis):
    return math.atan2(axis.dot(reference.cross(target)), reference.dot(target))


def _point_source_normals(tangents, segment_normals):
    point_normals = []
    for index, tangent in enumerate(tangents):
        nearby = []
        if index > 0 and segment_normals[index - 1] is not None:
            nearby.append(segment_normals[index - 1])
        if index < len(segment_normals) and segment_normals[index] is not None:
            nearby.append(segment_normals[index])
        normal = sum(nearby, Vector()) if nearby else _z_up_reference(tangent)
        point_normals.append(_projected_normal(normal, tangent))
    return point_normals


def _point_tilts(tangents, point_normals, settings):
    if not settings.use_source_tilt:
        base_offset = settings.tilt_offset + (math.pi if settings.flip_tilt else 0.0)
        return [base_offset] * len(tangents)

    tilts = []
    extra = settings.tilt_offset + (math.pi if settings.flip_tilt else 0.0)
    for tangent, normal in zip(tangents, point_normals):
        reference = _z_up_profile_x_reference(tangent)
        tilt = _signed_angle_around_axis(reference, normal, tangent) + extra
        if tilts:
            while tilt - tilts[-1] > math.pi:
                tilt -= math.tau
            while tilt - tilts[-1] < -math.pi:
                tilt += math.tau
        tilts.append(tilt)
    return tilts


def _profile_sample_points(profile_object):
    if not _profile_is_supported(profile_object):
        return []
    scale = profile_object.scale
    coordinates = []
    evaluated = None
    try:
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = profile_object.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        coordinates = [vertex.co.copy() for vertex in mesh.vertices]
    except (ReferenceError, RuntimeError, ValueError):
        coordinates = []
    finally:
        if evaluated is not None:
            try:
                evaluated.to_mesh_clear()
            except RuntimeError:
                pass

    if not coordinates:
        for spline in profile_object.data.splines:
            if spline.type == "BEZIER":
                points = list(spline.bezier_points)
                segment_count = len(points) if spline.use_cyclic_u else len(points) - 1
                samples_per_segment = max(2, profile_object.data.resolution_u + 1)
                for index in range(max(0, segment_count)):
                    first = points[index]
                    second = points[(index + 1) % len(points)]
                    coordinates.extend(
                        interpolate_bezier(
                            first.co,
                            first.handle_right,
                            second.handle_left,
                            second.co,
                            samples_per_segment,
                        )
                    )
            else:
                coordinates.extend(point.co.xyz for point in spline.points)
    return [
        Vector((coordinate.x * scale.x, coordinate.y * scale.y, 0.0))
        for coordinate in coordinates
    ]


def _profile_max_width(profile_object):
    if not _profile_is_supported(profile_object):
        return 0.0

    probe_data = None
    probe_obj = None
    try:
        probe_data = bpy.data.curves.new("CD_ProfileMeasure_Data", type="CURVE")
        probe_data.dimensions = "3D"
        probe_data.resolution_u = 1
        probe_data.render_resolution_u = 1
        probe_data.twist_mode = "Z_UP"
        probe_data.bevel_mode = "OBJECT"
        probe_data.bevel_object = profile_object
        spline = probe_data.splines.new(type="POLY")
        spline.points.add(1)
        spline.points[0].co = (0.0, 0.0, 0.0, 1.0)
        spline.points[1].co = (0.0, 0.0, 1.0, 1.0)
        probe_obj = bpy.data.objects.new("CD_ProfileMeasure", probe_data)
        bpy.context.scene.collection.objects.link(probe_obj)
        evaluated = probe_obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        mesh = evaluated.to_mesh()
        try:
            points = [Vector((vertex.co.x, vertex.co.y, 0.0)) for vertex in mesh.vertices]
        finally:
            evaluated.to_mesh_clear()
    except (ReferenceError, RuntimeError, ValueError):
        points = _profile_sample_points(profile_object)
    finally:
        if probe_obj is not None:
            bpy.data.objects.remove(probe_obj, do_unlink=True)
        if probe_data is not None and probe_data.users == 0:
            bpy.data.curves.remove(probe_data)

    maximum = 0.0
    for first_index, first in enumerate(points):
        for second in points[first_index + 1 :]:
            maximum = max(maximum, (second - first).length)
    return maximum


def _curve_point_radii(source_widths, settings):
    nonzero = [width for width in source_widths if width > EPSILON]
    root_width = nonzero[0] if nonzero else 1.0
    profile_width = _profile_max_width(settings.profile_object)

    if settings.match_source_width and profile_width > EPSILON:
        values = [width / profile_width for width in source_widths]
        bevel_depth = 0.0
        radius_mode = "MATCH_PROFILE_MAX_WIDTH"
        reference_width = profile_width
        radius_contract = "source_max_width / profile_max_width * radius_scale"
    else:
        values = [width / root_width for width in source_widths]
        bevel_depth = root_width * 0.5
        radius_mode = "NORMALIZE_TO_SOURCE_ROOT"
        reference_width = root_width
        radius_contract = "source_max_width / source_root_max_width * radius_scale"

    radii = [max(0.0, value * settings.radius_scale) for value in values]
    radius_info = {
        "mode": radius_mode,
        "contract": radius_contract,
        "reference_width": reference_width,
        "profile_width": profile_width,
        "round_bevel_depth": bevel_depth,
    }
    return radii, bevel_depth, radius_info


def _flat_vectors(vectors):
    return [float(component) for vector in vectors for component in vector]


def _store_curve_metrics(
    curve_obj,
    metrics,
    segment_normals,
    radii,
    tilts,
    radius_info,
    settings,
):
    max_widths = [float(metric["max_width"]) for metric in metrics]
    raw_spans = [float(metric["raw_span"]) for metric in metrics]
    width_spans = [float(metric["width_span"]) for metric in metrics]
    thicknesses = [float(metric["thickness"]) for metric in metrics]
    centers = [metric["center"] for metric in metrics]
    tangents = [metric["tangent"] for metric in metrics]
    source_normals = [metric["source_normal"] for metric in metrics]
    width_axes = [metric["width_axis"] for metric in metrics]
    raw_span_axes = [metric["raw_span_axis"] for metric in metrics]
    profile_width_axes = [metric["profile_width_axis"] for metric in metrics]
    stored_segment_normals = [
        normal if normal is not None else Vector((0.0, 0.0, 0.0))
        for normal in segment_normals
    ]

    curve_obj["character_designer_metrics_schema"] = METRICS_SCHEMA
    curve_obj["character_designer_measurement_space"] = "WORLD"
    curve_obj["character_designer_source_loop_max_widths"] = max_widths
    curve_obj["character_designer_source_loop_raw_spans"] = raw_spans
    curve_obj["character_designer_source_loop_width_spans"] = width_spans
    curve_obj["character_designer_source_loop_thicknesses"] = thicknesses
    curve_obj["character_designer_source_loop_vertex_counts"] = [
        int(metric["vertex_count"]) for metric in metrics
    ]
    curve_obj["character_designer_source_loop_centers"] = _flat_vectors(centers)
    curve_obj["character_designer_source_loop_tangents"] = _flat_vectors(tangents)
    curve_obj["character_designer_source_loop_normals"] = _flat_vectors(source_normals)
    curve_obj["character_designer_source_loop_max_width_axes"] = _flat_vectors(width_axes)
    curve_obj["character_designer_source_loop_raw_span_axes"] = _flat_vectors(
        raw_span_axes
    )
    curve_obj["character_designer_source_loop_width_axes"] = _flat_vectors(
        profile_width_axes
    )
    curve_obj["character_designer_source_segment_normals"] = _flat_vectors(
        stored_segment_normals
    )
    curve_obj["character_designer_generated_point_radii"] = [
        float(radius) for radius in radii
    ]
    curve_obj["character_designer_generated_point_tilts"] = [
        float(tilt) for tilt in tilts
    ]
    curve_obj["character_designer_profile_max_width"] = float(
        radius_info["profile_width"]
    )
    curve_obj["character_designer_radius_scale"] = float(settings.radius_scale)
    curve_obj["character_designer_radius_mode"] = radius_info["mode"]
    curve_obj["character_designer_radius_reference_width"] = float(
        radius_info["reference_width"]
    )
    actual_round_bevel_depth = (
        float(radius_info["round_bevel_depth"])
        if settings.profile_object is None
        else 0.0
    )
    curve_obj["character_designer_round_bevel_depth"] = float(
        actual_round_bevel_depth
    )
    curve_obj["character_designer_match_source_width"] = bool(
        settings.match_source_width
    )
    curve_obj["character_designer_use_source_tilt"] = bool(settings.use_source_tilt)
    curve_obj["character_designer_flip_tilt"] = bool(settings.flip_tilt)
    curve_obj["character_designer_tilt_offset"] = float(settings.tilt_offset)
    curve_obj["character_designer_curve_resolution"] = int(settings.resolution_u)
    curve_obj["character_designer_fill_caps"] = bool(settings.fill_caps)

    document = {
        "schema": METRICS_SCHEMA,
        "measurement_space": "WORLD",
        "radius_mode": radius_info["mode"],
        "radius_contract": radius_info["contract"],
        "radius_reference_width": float(radius_info["reference_width"]),
        "bevel_mode": "OBJECT" if settings.profile_object else "ROUND",
        "round_bevel_depth": actual_round_bevel_depth,
        "profile": settings.profile_object.name if settings.profile_object else None,
        "profile_max_width": float(radius_info["profile_width"]),
        "radius_scale": float(settings.radius_scale),
        "match_source_width": bool(settings.match_source_width),
        "use_source_tilt": bool(settings.use_source_tilt),
        "flip_tilt": bool(settings.flip_tilt),
        "tilt_offset": float(settings.tilt_offset),
        "curve_resolution": int(settings.resolution_u),
        "fill_caps": bool(settings.fill_caps),
        "orientation_center": (
            settings.orientation_center.name if settings.orientation_center else None
        ),
        "loops": [
            {
                "index": metric["index"],
                "vertex_count": metric["vertex_count"],
                "center_world": list(metric["center"]),
                "tangent_world": list(metric["tangent"]),
                "source_normal_world": list(metric["source_normal"]),
                "max_width_axis_world": list(metric["width_axis"]),
                "raw_span_axis_world": list(metric["raw_span_axis"]),
                "width_axis_world": list(metric["profile_width_axis"]),
                "max_width": float(metric["max_width"]),
                "raw_span": float(metric["raw_span"]),
                "width_span": float(metric["width_span"]),
                "thickness": float(metric["thickness"]),
                "curve_radius": float(radius),
                "curve_tilt": float(tilt),
            }
            for metric, radius, tilt in zip(metrics, radii, tilts)
        ],
        "segments": [
            {
                "index": index,
                "guide_normal_world": list(normal),
            }
            for index, normal in enumerate(stored_segment_normals)
        ],
    }
    curve_obj["character_designer_loop_metrics_json"] = json.dumps(
        document,
        ensure_ascii=False,
        separators=(",", ":"),
    )


def _load_stored_curve_metrics(curve_obj):
    if not _is_generated_hair_curve(curve_obj):
        raise HairAnalysisError("Choose a generated Character Designer hair curve")
    try:
        document = json.loads(curve_obj["character_designer_loop_metrics_json"])
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise HairAnalysisError("The output curve's stored measurements are unreadable") from exc
    if document.get("schema") != METRICS_SCHEMA:
        raise HairAnalysisError("The output curve uses an unsupported measurement schema")
    loops = document.get("loops")
    if not isinstance(loops, list) or len(loops) < 2:
        raise HairAnalysisError("The output curve does not contain enough stored loops")

    if not curve_obj.data.splines or curve_obj.data.splines[0].type != "BEZIER":
        raise HairAnalysisError("The output's first spline is no longer Bezier")
    points = curve_obj.data.splines[0].bezier_points
    if len(points) != len(loops):
        raise HairAnalysisError(
            "The output point count changed; use a new conversion to avoid corrupting edits"
        )

    metrics = []
    for expected_index, loop in enumerate(loops):
        try:
            center = Vector(loop["center_world"])
            tangent = Vector(loop["tangent_world"])
            source_normal = Vector(loop["source_normal_world"])
            width_axis = Vector(loop["max_width_axis_world"])
            profile_width_axis = Vector(loop["width_axis_world"])
            raw_span_axis = Vector(loop.get("raw_span_axis_world", width_axis))
            values = (
                *center,
                *tangent,
                *source_normal,
                *width_axis,
                *profile_width_axis,
                *raw_span_axis,
                float(loop["max_width"]),
                float(loop.get("raw_span", loop["max_width"])),
                float(loop["width_span"]),
                float(loop["thickness"]),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise HairAnalysisError(
                f"Stored measurements are incomplete at loop {expected_index}"
            ) from exc
        if not all(math.isfinite(value) for value in values):
            raise HairAnalysisError(
                f"Stored measurements contain invalid values at loop {expected_index}"
            )
        metrics.append(
            {
                "index": expected_index,
                "vertex_count": int(loop.get("vertex_count", 0)),
                "center": center,
                "tangent": tangent.normalized(),
                "source_normal": source_normal.normalized(),
                "width_axis": width_axis.normalized(),
                "profile_width_axis": profile_width_axis.normalized(),
                "raw_span_axis": raw_span_axis.normalized(),
                "max_width": float(loop["max_width"]),
                "raw_span": float(loop.get("raw_span", loop["max_width"])),
                "width_span": float(loop["width_span"]),
                "thickness": float(loop["thickness"]),
            }
        )

    segment_normals = []
    for segment in document.get("segments", []):
        normal = Vector(segment.get("guide_normal_world", (0.0, 0.0, 0.0)))
        segment_normals.append(normal if normal.length_squared > EPSILON else None)
    expected_segments = len(metrics) - 1
    if len(segment_normals) != expected_segments:
        segment_normals = [None] * expected_segments
    return document, metrics, segment_normals


def _apply_settings_to_curve(curve_obj, settings):
    profile_error = _profile_validation_error(settings.profile_object)
    if profile_error:
        raise HairAnalysisError(profile_error)
    if getattr(curve_obj.data, "is_editmode", False):
        raise HairAnalysisError("Exit Curve Edit Mode before updating this Output")
    linear = curve_obj.matrix_world.to_3x3()
    axes = [Vector(linear.col[index]) for index in range(3)]
    if any(abs(axis.length - 1.0) > 1.0e-6 for axis in axes) or any(
        abs(axes[first].dot(axes[second])) > 1.0e-6
        for first in range(3)
        for second in range(first + 1, 3)
    ):
        raise HairAnalysisError(
            "Output world transform contains scale/shear; apply object, delta, and parent scale"
        )

    _document, metrics, segment_normals = _load_stored_curve_metrics(curve_obj)
    source_widths = [metric["max_width"] for metric in metrics]
    tangents = [metric["tangent"] for metric in metrics]
    point_normals = [metric["source_normal"] for metric in metrics]
    tilts = _point_tilts(tangents, point_normals, settings)
    radii, bevel_depth, radius_info = _curve_point_radii(source_widths, settings)
    for metric, radius, tilt in zip(metrics, radii, tilts):
        metric["curve_radius"] = radius
        metric["curve_tilt"] = tilt

    original_data = curve_obj.data
    original_data_name = original_data.name
    curve_data = original_data.copy()
    property_snapshot = {}
    for key in curve_obj.keys():
        if not key.startswith("character_designer_"):
            continue
        value = curve_obj[key]
        property_snapshot[key] = (
            list(value) if hasattr(value, "to_list") else value
        )
    try:
        curve_data.dimensions = "3D"
        curve_data.resolution_u = settings.resolution_u
        curve_data.render_resolution_u = settings.resolution_u
        curve_data.twist_mode = "Z_UP"
        curve_data.use_fill_caps = settings.fill_caps
        if settings.profile_object is not None:
            curve_data.bevel_mode = "OBJECT"
            curve_data.bevel_object = settings.profile_object
        else:
            curve_data.bevel_object = None
            curve_data.bevel_mode = "ROUND"
            curve_data.bevel_depth = bevel_depth
            curve_data.bevel_resolution = 3

        spline = curve_data.splines[0]
        for point, radius, tilt in zip(spline.bezier_points, radii, tilts):
            point.radius = radius
            point.tilt = tilt
        curve_data["character_designer_metrics_schema"] = METRICS_SCHEMA
        curve_data.update_tag()

        _store_curve_metrics(
            curve_obj,
            metrics,
            segment_normals,
            radii,
            tilts,
            radius_info,
            settings,
        )
        curve_obj["character_designer_generator"] = GENERATOR_ID
        curve_obj.data = curve_data
        if curve_obj.data != curve_data:
            raise RuntimeError("Blender did not commit the single-user curve data")
    except Exception:
        for key in list(curve_obj.keys()):
            if key.startswith("character_designer_"):
                del curve_obj[key]
        for key, value in property_snapshot.items():
            curve_obj[key] = value
        if curve_data.users == 0:
            bpy.data.curves.remove(curve_data)
        raise

    if original_data.users == 0:
        bpy.data.curves.remove(original_data)
        curve_data.name = original_data_name
    return source_widths, metrics, radius_info


def _create_curve_object(
    context,
    source_obj,
    centers,
    tangents,
    radii,
    tilts,
    bevel_depth,
    metrics,
    segment_normals,
    radius_info,
    settings,
):
    curve_data = None
    curve_obj = None
    try:
        curve_data = bpy.data.curves.new(
            f"{source_obj.name}_HairGuide",
            type="CURVE",
        )
        curve_data.dimensions = "3D"
        curve_data.resolution_u = settings.resolution_u
        curve_data.render_resolution_u = settings.resolution_u
        curve_data.twist_mode = "Z_UP"
        curve_data.use_fill_caps = settings.fill_caps

        if settings.profile_object is not None:
            curve_data.bevel_mode = "OBJECT"
            curve_data.bevel_object = settings.profile_object
        else:
            curve_data.bevel_mode = "ROUND"
            curve_data.bevel_depth = bevel_depth
            curve_data.bevel_resolution = 3

        spline = curve_data.splines.new(type="BEZIER")
        spline.bezier_points.add(len(centers) - 1)
        for index, (point, center, tangent, radius, tilt) in enumerate(
            zip(spline.bezier_points, centers, tangents, radii, tilts)
        ):
            point.co = center
            point.handle_left_type = "FREE"
            point.handle_right_type = "FREE"
            previous_length = (
                (center - centers[index - 1]).length
                if index > 0
                else (centers[1] - center).length
            )
            next_length = (
                (centers[index + 1] - center).length
                if index < len(centers) - 1
                else (center - centers[index - 1]).length
            )
            point.handle_left = center - tangent * (previous_length / 3.0)
            point.handle_right = center + tangent * (next_length / 3.0)
            point.radius = radius
            point.tilt = tilt

        curve_obj = bpy.data.objects.new(
            f"{source_obj.name}_HairCurve",
            curve_data,
        )
        target_collection = (
            source_obj.users_collection[0]
            if source_obj.users_collection
            else context.collection
        )
        target_collection.objects.link(curve_obj)
        curve_obj["character_designer_source"] = source_obj.name
        curve_obj["character_designer_ring_count"] = len(centers)
        curve_obj["character_designer_generator"] = GENERATOR_ID
        curve_data["character_designer_metrics_schema"] = METRICS_SCHEMA
        _store_curve_metrics(
            curve_obj,
            metrics,
            segment_normals,
            radii,
            tilts,
            radius_info,
            settings,
        )

        if settings.copy_material and source_obj.data.materials:
            curve_data.materials.append(source_obj.data.materials[0])
        return curve_obj
    except Exception:
        if curve_obj is not None:
            bpy.data.objects.remove(curve_obj, do_unlink=True)
        if curve_data is not None and curve_data.users == 0:
            bpy.data.curves.remove(curve_data)
        raise


def _d_profile_objects():
    return [
        obj
        for obj in bpy.data.objects
        if obj.type == "CURVE"
        and obj.get("character_designer_profile") == "D_8_POINT"
    ]


def _profile_consumers(profile_object):
    return [
        obj
        for obj in bpy.data.objects
        if obj.type == "CURVE"
        and getattr(obj.data, "bevel_object", None) == profile_object
    ]


class CHARACTERDESIGNER_OT_create_d_profile(Operator):
    bl_idname = "character_designer.create_d_hair_profile"
    bl_label = "Create D Profile"
    bl_description = "Create an eight-point D-shaped bevel profile for anime hair"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.character_designer_hair
        size = settings.profile_size
        profiles = _d_profile_objects()
        matching = next(
            (
                profile
                for profile in profiles
                if abs(_profile_max_width(profile) - size) <= max(EPSILON, size * 1.0e-6)
            ),
            None,
        )
        if matching is not None:
            if matching.library is None:
                matching["character_designer_max_width"] = size
            settings.profile_object = matching
            self.report({"INFO"}, "Using the matching Character Designer D profile")
            return {"FINISHED"}

        existing = next(
            (
                profile
                for profile in profiles
                if (
                    profile.library is None
                    and not getattr(profile.data, "is_editmode", False)
                    and not _profile_consumers(profile)
                )
            ),
            None,
        )
        if existing is not None:
            replacement_data = None
            old_data = existing.data
            old_scale = existing.scale.copy()
            had_width = "character_designer_max_width" in existing
            old_width = existing.get("character_designer_max_width", 0.0)
            old_setting_profile = settings.profile_object
            try:
                replacement_data = bpy.data.curves.new(
                    f"{PROFILE_OBJECT_NAME}_Data",
                    type="CURVE",
                )
                _write_d_profile_data(replacement_data, size)
                existing.data = replacement_data
                if existing.data != replacement_data:
                    raise RuntimeError("Blender did not commit the replacement profile data")
                existing.scale = (1.0, 1.0, 1.0)
                existing["character_designer_max_width"] = size
                settings.profile_object = existing
            except Exception as exc:
                if replacement_data is not None and existing.data == replacement_data:
                    existing.data = old_data
                existing.scale = old_scale
                if had_width:
                    existing["character_designer_max_width"] = old_width
                elif "character_designer_max_width" in existing:
                    del existing["character_designer_max_width"]
                settings.profile_object = old_setting_profile
                if replacement_data is not None and replacement_data.users == 0:
                    bpy.data.curves.remove(replacement_data)
                self.report({"ERROR"}, f"Could not update D Profile: {exc}")
                return {"CANCELLED"}
            if old_data.users == 0:
                bpy.data.curves.remove(old_data)
            self.report({"INFO"}, "Updated an unused Character Designer D profile")
            return {"FINISHED"}

        curve_data = None
        profile_obj = None
        collection = None
        created_collection = False
        try:
            curve_data = bpy.data.curves.new(
                f"{PROFILE_OBJECT_NAME}_Data",
                type="CURVE",
            )
            _write_d_profile_data(curve_data, size)
            profile_obj = bpy.data.objects.new(PROFILE_OBJECT_NAME, curve_data)
            collection = bpy.data.collections.get(PROFILE_COLLECTION_NAME)
            if collection is None:
                collection = bpy.data.collections.new(PROFILE_COLLECTION_NAME)
                context.scene.collection.children.link(collection)
                created_collection = True
            collection.objects.link(profile_obj)
            profile_obj.display_type = "WIRE"
            profile_obj.show_in_front = True
            profile_obj.hide_render = True
            profile_obj["character_designer_profile"] = "D_8_POINT"
            profile_obj["character_designer_max_width"] = size
            settings.profile_object = profile_obj
            try:
                profile_obj.hide_set(True)
            except RuntimeError:
                pass
        except Exception as exc:
            if profile_obj is not None:
                bpy.data.objects.remove(profile_obj, do_unlink=True)
            if curve_data is not None and curve_data.users == 0:
                bpy.data.curves.remove(curve_data)
            if (
                created_collection
                and collection is not None
                and not collection.objects
                and not collection.children
            ):
                bpy.data.collections.remove(collection)
            self.report({"ERROR"}, f"Could not create D Profile: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, "Created an eight-point D hair profile")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_analyze_hair_selection(Operator):
    bl_idname = "character_designer.analyze_hair_selection"
    bl_label = "Analyze Hair Selection"
    bl_description = "Validate the selected tube and cache exact per-loop measurements"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        state = _light_selection_state(context)
        if not state["ready"]:
            cls.poll_message_set(state["message"])
            return False
        return True

    def execute(self, context):
        settings = context.scene.character_designer_hair
        state = _light_selection_state(context)
        try:
            analysis = _analyze_selected_hair(context, settings)
        except HairAnalysisError as exc:
            _cache_analysis_failure(settings, state["signature"], str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            message = f"Analysis failed safely: {exc}"
            _cache_analysis_failure(settings, state["signature"], message)
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        _cache_analysis(settings, analysis)
        self.report(
            {"INFO"},
            f"Ready: {len(analysis['metrics'])} loops, exact projected spans cached",
        )
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_selected_hair_strip_to_curve(Operator):
    bl_idname = "character_designer.selected_hair_strip_to_curve"
    bl_label = "Convert to Hair Curve"
    bl_description = (
        "Validate the selected tube, then extract one Bezier point per topology layer"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        state = _light_selection_state(context)
        if not state["ready"]:
            cls.poll_message_set(state["message"])
            return False
        settings = getattr(context.scene, "character_designer_hair", None)
        profile_error = None
        if settings is None:
            profile_error = "Character Designer settings are unavailable"
        elif (
            settings.profile_object is not None
            and not _profile_is_supported(settings.profile_object)
        ):
            profile_error = "Profile must be one simple closed 2D Poly/Bezier spline"
        if profile_error:
            cls.poll_message_set(profile_error)
            return False
        return True

    def execute(self, context):
        settings = context.scene.character_designer_hair
        state = _light_selection_state(context)
        try:
            analysis = _analyze_selected_hair(context, settings)
            curve_obj = _create_curve_object(
                context,
                analysis["source_obj"],
                analysis["centers"],
                analysis["tangents"],
                analysis["radii"],
                analysis["tilts"],
                analysis["bevel_depth"],
                analysis["metrics"],
                analysis["segment_normals"],
                analysis["radius_info"],
                settings,
            )
        except HairAnalysisError as exc:
            _cache_analysis_failure(settings, state["signature"], str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            message = f"Conversion failed safely: {exc}"
            _cache_analysis_failure(settings, state["signature"], message)
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        _cache_analysis(settings, analysis)
        _set_last_result(settings, curve_obj, analysis["source_widths"])
        message = f"Created {curve_obj.name} with {len(analysis['centers'])} points"
        if analysis["ignored_face_count"]:
            message += f"; ignored {analysis['ignored_face_count']} disconnected faces"
        self.report({"INFO"}, message)
        return {"FINISHED"}


def _output_curve_from_context(context):
    settings = context.scene.character_designer_hair
    if (
        _is_generated_hair_curve(settings.output_curve)
        and context.view_layer.objects.get(settings.output_curve.name)
        == settings.output_curve
    ):
        return settings.output_curve
    active = context.view_layer.objects.active
    return active if _is_generated_hair_curve(active) else None


class CHARACTERDESIGNER_OT_update_hair_curve(Operator):
    bl_idname = "character_designer.update_hair_curve"
    bl_label = "Update Output"
    bl_description = (
        "Reapply Profile, Width Scale, resolution and tilt from original stored measurements"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if not hasattr(context.scene, "character_designer_hair"):
            return False
        curve_obj = _output_curve_from_context(context)
        if curve_obj is None:
            cls.poll_message_set("Choose an Output Curve in the current View Layer")
            return False
        if curve_obj.hide_select:
            cls.poll_message_set("Enable selection for the Output Curve first")
            return False
        return True

    def execute(self, context):
        settings = context.scene.character_designer_hair
        curve_obj = _output_curve_from_context(context)
        try:
            source_widths, metrics, radius_info = _apply_settings_to_curve(
                curve_obj,
                settings,
            )
        except HairAnalysisError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            self.report({"ERROR"}, f"Update failed safely: {exc}")
            return {"CANCELLED"}
        _set_last_result(settings, curve_obj, source_widths)
        _refresh_cached_curve_values(settings, metrics, radius_info)
        self.report(
            {"INFO"},
            f"Updated {curve_obj.name} from {len(source_widths)} original loop spans",
        )
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_select_hair_curve(Operator):
    bl_idname = "character_designer.select_hair_curve"
    bl_label = "Select Output"
    bl_description = "Exit Edit Mode and select the generated Output Curve"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if not hasattr(context.scene, "character_designer_hair"):
            return False
        if _output_curve_from_context(context) is None:
            cls.poll_message_set("Choose a generated Output Curve")
            return False
        return True

    def execute(self, context):
        settings = context.scene.character_designer_hair
        curve_obj = _output_curve_from_context(context)
        if curve_obj is None:
            self.report({"ERROR"}, "Output Curve is not in the current View Layer")
            return {"CANCELLED"}
        if curve_obj.hide_select:
            self.report({"ERROR"}, "Selection is disabled for the Output Curve")
            return {"CANCELLED"}
        previous_active = context.view_layer.objects.active
        previous_selected = [obj for obj in context.view_layer.objects if obj.select_get()]
        previous_mode = previous_active.mode if previous_active is not None else "OBJECT"
        try:
            if context.mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            curve_obj.hide_set(False)
            curve_obj.hide_viewport = False
            curve_obj.select_set(True)
            for obj in context.view_layer.objects:
                if obj != curve_obj:
                    obj.select_set(False)
            context.view_layer.objects.active = curve_obj
            settings.output_curve = curve_obj
        except (ReferenceError, RuntimeError) as exc:
            try:
                if context.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
                for obj in context.view_layer.objects:
                    obj.select_set(obj in previous_selected)
                context.view_layer.objects.active = previous_active
                if previous_active is not None and previous_mode != "OBJECT":
                    previous_active.select_set(True)
                    bpy.ops.object.mode_set(mode=previous_mode)
            except (ReferenceError, RuntimeError):
                pass
            self.report({"ERROR"}, f"Could not select Output Curve: {exc}")
            return {"CANCELLED"}
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_reset_tilt_overrides(Operator):
    bl_idname = "character_designer.reset_tilt_overrides"
    bl_label = "Reset Tilt Overrides"
    bl_description = "Clear Flip 180 degrees and Tilt Offset"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.character_designer_hair
        settings.flip_tilt = False
        settings.tilt_offset = 0.0
        return {"FINISHED"}


class CHARACTERDESIGNER_UL_hair_loop_metrics(bpy.types.UIList):
    bl_idname = "CHARACTERDESIGNER_UL_hair_loop_metrics"

    def draw_item(
        self,
        _context,
        layout,
        _data,
        item,
        _icon,
        _active_data,
        _active_property,
        _index=0,
        _filter_flag=0,
    ):
        row = layout.row(align=True)
        row.label(text=f"#{item.loop_index:02d}")
        values = row.row(align=True)
        values.enabled = False
        values.prop(item, "max_width", text="")
        values.prop(item, "thickness", text="")


def _format_distance(context, value):
    unit_settings = context.scene.unit_settings
    if unit_settings.system == "NONE":
        return f"{value:.5g} BU"
    try:
        return bpy.utils.units.to_string(
            unit_settings.system,
            "LENGTH",
            value * unit_settings.scale_length,
            precision=4,
            split_unit=False,
        )
    except (TypeError, ValueError):
        return f"{value:.5g} BU"


def _cached_profile_width(settings):
    if settings.profile_object is None:
        return 0.0
    if (
        settings.analysis_profile_object == settings.profile_object
        and settings.analysis_profile_width > EPSILON
    ):
        return settings.analysis_profile_width
    if (
        settings.profile_object.get("character_designer_profile") == "D_8_POINT"
        and all(abs(value - 1.0) <= 1.0e-6 for value in settings.profile_object.scale)
    ):
        return float(settings.profile_object.get("character_designer_max_width", 0.0))
    return 0.0


def draw_hair_curve_tools(layout, context):
    settings = context.scene.character_designer_hair

    state = _light_selection_state(context)
    cache_current = (
        state["ready"]
        and settings.analysis_signature
        and settings.analysis_signature == state["signature"]
    )

    status_box = layout.box()
    status_row = status_box.row(align=True)
    if cache_current and settings.analysis_ready:
        status_row.label(
            text=f"Root {settings.analysis_root_sides}-gon · {settings.analysis_loop_count} loops",
            icon="CHECKMARK",
        )
    elif cache_current and settings.analysis_status:
        status_row.label(text=settings.analysis_status, icon="ERROR")
    else:
        status_row.label(
            text=state["message"],
            icon="INFO" if state["ready"] else "ERROR",
        )
    status_row.operator(
        "character_designer.analyze_hair_selection",
        text="",
        icon="FILE_REFRESH",
    )

    if cache_current and settings.analysis_ready:
        summary = status_box.grid_flow(
            row_major=True,
            columns=2,
            even_columns=True,
            align=True,
        )
        summary.enabled = False
        summary.prop(settings, "analysis_root_width", text="Root Span")
        summary.prop(settings, "analysis_tip_width", text="Tip Span")
        summary.prop(settings, "analysis_min_width", text="Min Span")
        summary.prop(settings, "analysis_max_width", text="Max Span")
        status_box.label(text=settings.analysis_normal_quality, icon="NORMALS_FACE")
        if settings.analysis_warning:
            for warning in settings.analysis_warning.split(" | "):
                status_box.label(text=warning, icon="ERROR")
        status_box.label(text="Cached preview · refresh after mesh edits", icon="INFO")
    elif not state["ready"]:
        status_box.label(text="Active root last; grow toward tip with Ctrl+Numpad+", icon="FACESEL")

    profile_box = layout.box()
    profile_box.label(text="Profile and Width")
    row = profile_box.row(align=True)
    row.prop(settings, "profile_object", text="Profile")
    row.operator(
        "character_designer.create_d_hair_profile",
        text="Use D",
        icon="CURVE_NCIRCLE",
    )
    if settings.profile_object is None:
        profile_box.label(text="Round bevel fallback", icon="INFO")
    else:
        profile_width = _cached_profile_width(settings)
        if profile_width > EPSILON:
            profile_box.label(
                text=f"Measured profile span: {_format_distance(context, profile_width)}",
                icon="DRIVER_DISTANCE",
            )
        else:
            profile_box.label(text="Analyze to measure this custom Profile", icon="INFO")
    profile_box.prop(settings, "match_source_width", text="Exact Source Width")
    profile_box.prop(settings, "radius_scale")
    if cache_current and settings.analysis_ready:
        profile_width = _cached_profile_width(settings)
        if settings.match_source_width or settings.profile_object is None:
            predicted_root = settings.analysis_root_width * settings.radius_scale
        elif profile_width > EPSILON:
            predicted_root = profile_width * settings.radius_scale
        else:
            predicted_root = 0.0
        if predicted_root > EPSILON:
            profile_box.label(
                text=f"Predicted output root: {_format_distance(context, predicted_root)}",
                icon="DRIVER_DISTANCE",
            )
    profile_box.prop(settings, "profile_size")

    orientation_box = layout.box()
    orientation_box.label(text="Orientation")
    orientation_box.prop(settings, "orientation_center", text="Outward From")
    if settings.orientation_center is None:
        orientation_box.label(
            text="Using hair origin; D side may flip on offset strands",
            icon="ERROR",
        )
    else:
        orientation_box.label(
            text=f"Outward from {settings.orientation_center.name}",
            icon="CHECKMARK",
        )
    row = orientation_box.row(align=True)
    row.prop(settings, "use_source_tilt", text="Follow Source Normals")
    row.prop(settings, "flip_tilt", text="Flip 180°", toggle=True)
    if settings.flip_tilt or abs(settings.tilt_offset) > 1.0e-8:
        override_row = orientation_box.row(align=True)
        override_row.label(text="Tilt override is active", icon="ERROR")
        override_row.operator(
            "character_designer.reset_tilt_overrides",
            text="Reset",
        )

    action = layout.column(align=True)
    action.scale_y = 1.35
    action.operator(
        "character_designer.selected_hair_strip_to_curve",
        text=(
            f"Convert to Curve · {settings.analysis_loop_count} Points"
            if cache_current and settings.analysis_ready
            else "Convert to Hair Curve"
        ),
        icon="CURVE_BEZCURVE",
    )

    output_box = layout.box()
    output_box.label(text="Adjust Existing Output")
    output_box.prop(settings, "output_curve", text="Output")
    row = output_box.row(align=True)
    row.operator(
        "character_designer.update_hair_curve",
        text="Update from Original Spans",
        icon="FILE_REFRESH",
    )
    row.operator(
        "character_designer.select_hair_curve",
        text="Select",
    )
    if _is_generated_hair_curve(settings.output_curve):
        values = output_box.grid_flow(columns=2, even_columns=True, align=True)
        values.enabled = False
        values.prop(settings, "last_loop_count", text="Loops")
        values.prop(settings, "last_root_width", text="Root Span")
        values.prop(settings, "last_tip_width", text="Tip Span")
        values.prop(settings, "last_max_width", text="Max Span")

    advanced_row = layout.row(align=True)
    advanced_row.prop(
        settings,
        "show_advanced",
        text="Advanced",
        icon="TRIA_DOWN" if settings.show_advanced else "TRIA_RIGHT",
        emboss=False,
    )
    if settings.show_advanced:
        advanced = layout.box()
        advanced.prop(settings, "resolution_u")
        advanced.prop(settings, "fill_caps")
        advanced.prop(settings, "copy_material")
        advanced.prop(settings, "tilt_offset")
        advanced.label(
            text="Orientation Center is sampled only during conversion",
            icon="INFO",
        )

    metrics_row = layout.row(align=True)
    metrics_row.prop(
        settings,
        "show_loop_metrics",
        text="Loop Measurements",
        icon="TRIA_DOWN" if settings.show_loop_metrics else "TRIA_RIGHT",
        emboss=False,
    )
    if settings.show_loop_metrics:
        metrics_box = layout.box()
        if not (cache_current and settings.analysis_ready and settings.analysis_loops):
            metrics_box.label(text="Analyze the current selection first", icon="INFO")
        else:
            header = metrics_box.row(align=True)
            header.label(text="Loop")
            header.label(text="Projected Span / Thickness")
            metrics_box.template_list(
                "CHARACTERDESIGNER_UL_hair_loop_metrics",
                "",
                settings,
                "analysis_loops",
                settings,
                "analysis_loop_index",
                rows=5,
            )
            index = min(settings.analysis_loop_index, len(settings.analysis_loops) - 1)
            item = settings.analysis_loops[index]
            detail = metrics_box.column(align=True)
            detail.enabled = False
            detail.prop(item, "vertex_count")
            detail.prop(item, "max_width", text="Projected Longest Span")
            detail.prop(item, "raw_span")
            detail.prop(item, "width_span")
            detail.prop(item, "thickness")
            detail.prop(item, "curve_radius", text="Generated Radius Factor")
            detail.prop(item, "curve_tilt")
            detail.prop(item, "source_normal")
            detail.prop(item, "max_width_axis")
            detail.prop(item, "profile_width_axis")


CHARACTER_DESIGNER_HAIR_CLASSES = (
    CharacterDesignerLoopMetric,
    CharacterDesignerHairSettings,
    CHARACTERDESIGNER_UL_hair_loop_metrics,
    CHARACTERDESIGNER_OT_create_d_profile,
    CHARACTERDESIGNER_OT_analyze_hair_selection,
    CHARACTERDESIGNER_OT_selected_hair_strip_to_curve,
    CHARACTERDESIGNER_OT_update_hair_curve,
    CHARACTERDESIGNER_OT_select_hair_curve,
    CHARACTERDESIGNER_OT_reset_tilt_overrides,
)
