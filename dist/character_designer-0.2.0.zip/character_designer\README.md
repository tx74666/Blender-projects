# Character Designer

A personal Blender add-on for Randy's character-modeling workflow. It is kept
separate from RR Helper, which remains focused on the team's Blender/BlackUnity
handoff workflow.

## Hair strip to curve

1. Enter Edit Mode on a closed hair mesh made by extruding a root cross-section.
2. Select the root cross-section last so it is the active face.
3. Grow the selection toward the tip with `Ctrl+Numpad+`.
4. Open `3D View > Sidebar > Character > Hair Curve`.
5. Optionally create or assign a D-shaped bevel profile.
6. Use **Analyze/Refresh** when you want a preflight measurement, then run
   **Convert to Hair Curve**. Conversion always performs the full validation
   again, so cached preview values are never trusted as geometry input.

The panel keeps the high-frequency controls at the top: selection readiness,
Profile, exact-width matching, Width Scale, Orientation Center, and Flip 180°.
Resolution, caps, material copying, and Tilt Offset live under **Advanced**.
The optional **Loop Measurements** list exposes projected span, raw 3D span,
thickness, axes, Radius, and Tilt without opening Custom Properties.

The source mesh is left untouched. The generated Bézier curve receives one
point per topological layer. Each point's Radius is calculated from the exact
projected maximum vertex-to-vertex span of its source loop, so later `Alt+S`
edits have a reliable scale basis.

Character Designer also stores the unscaled source measurements on the curve:

- exact maximum span, normal-axis thickness, and width-axis span per loop;
- loop center, tangent, longest-span axis, width axis, and source side normal;
- the original guide normal for every segment;
- generated Radius/Tilt values and the bevel profile's measured maximum span;
- a versioned JSON copy of all loop metrics for future tools.

## Adjusting an existing result

**Output Curve > Update from Original Spans** reapplies the current Profile,
Width Scale, resolution, caps, Follow Source Normals, Flip, and Tilt Offset to
an existing Character Designer result. It always starts from the stored source
loop measurements, so repeated updates do not compound the scale. Curve point
positions and Bezier handles are preserved. A linked curve data-block is made
single-user before the selected result is updated.

Use **Select Output** to leave mesh Edit Mode and continue editing the generated
curve. Conversion itself deliberately leaves the source mesh and selection
untouched so multiple strands can be processed in sequence.

Set **Orientation Center** to the head or body object when available. The tool
uses it to choose the broad source face pointing away from the character, then
tracks that same face side through shared ring edges. `Flip Tilt` remains a
non-destructive 180-degree correction when a particular strand needs the
opposite D-profile orientation.

A curve point has only one uniform bevel Radius. It can exactly preserve the
chosen maximum span, but it cannot independently reproduce changing width and
thickness at the same time. The original thickness is therefore retained in
metadata for a later anisotropic or Geometry Nodes workflow.

Exact custom-profile measurement supports one closed 2D Poly or Bézier spline
without its own Extrude, Bevel, Taper, or modifiers. NURBS and compound Profiles
are rejected because their evaluated contour is not a reliable bevel contract.
Profile width is measured through a temporary evaluated bevel probe, matching
Blender's actual tessellation rather than an arbitrary Bézier sample count.
Profile sizing follows Blender bevel semantics: the profile object's direct
Scale is included, while parent and Delta Scale are not used by the bevel.

Selections are accepted only when every non-tip layer is one closed ring and
every adjacent pair is joined by one complete manifold side band. Partial
bands, internal caps, split loops, branches, and non-manifold edges are rejected
before an output is created. A final single-vertex point tip is supported.
