# Character Designer 0.5.0

Character Designer is Randy's personal Blender add-on. It stays separate from
RR Helper and focuses on character-modeling tools.

## Live Hair Centerline Preview

Character Designer turns the cross-sections of a hair mesh into an exact,
plain center curve.

1. Turn on **Live Preview**. It may be enabled before or after entering Mesh
   Edit Mode.
2. Select the complete connected part of the hair that should define the
   centerline. Every regular cross-section becomes one preview point and a
   collapsed endpoint vertex becomes one final point.
3. Grow, shrink, or replace the selection as needed; Preview follows it live.
4. Click **Confirm Centerline** to re-read the current selection and create the
   Curve. Turning Live Preview off simply clears the preview.

Leaving Edit Mode pauses Preview without turning the toggle off. Returning to
Edit Mode resumes it from the current selection. A single selected row, loop,
or point displays one preview point, while confirmation becomes available with
two or more validated cross-sections.

Open rows, closed profile loops, and a collapsed `POINT` tip are supported. The
selection parser is independent of Blender's vertex/edge/face selection mode.
For example, four selected triangular profile loops plus one pointed tip are
read as `3 → 3 → 3 → 3 → 1` and create five center points; selected side faces
are never mistaken for one large root cap.

Each valid topological layer contributes one preview point at the arithmetic
mean of that layer's current vertices. The points stay in source-object local
space and the source transform is copied to the confirmed Curve, preserving
the original placement and local precision.

The confirmed Curve remains deliberately plain. It has no bevel profile,
generated thickness, material, or automatic shaping; point Radius and Tilt
remain at Blender's defaults. Preview and confirmation do not modify the source
mesh or its selection.

## Source Metadata

The confirmed Curve keeps lossless, versioned source metadata for later profile
work. For every layer it records:

- the raw maximum vertex-to-vertex chord and the vertex pair that defines it;
- the maximum profile span used as the cross-section sizing reference;
- the local center, tangent, width axis, normal, and orientation source.

The metadata is stored in `SOURCE_OBJECT_LOCAL` space together with the source
matrix at confirmation time. It does not change the visible Curve. Later tools
can derive Radius, Tilt, or a profile without guessing or overwriting the raw
measurements.

The live panel keeps the working information in front: current layer-to-point
count, start/maximum/end profile span, pause state, and short errors.
Detailed per-layer measurements remain on the confirmed Curve.

## Refresh Add-on

Character Designer watches its installed Python files. **Refresh Add-on** is
hidden while the loaded code matches disk and appears only when the source has
changed, a refresh is running, or an error needs attention. Refresh validates
the Python files before reloading the add-on. It does not save or reload the
current `.blend`; session-only preview and output state is reset.
