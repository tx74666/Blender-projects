# Character Designer 0.4.0

Character Designer is Randy's personal Blender add-on. It stays separate from
RR Helper and focuses on character-modeling tools.

## Live Hair Centerline Preview

Character Designer turns the cross-sections of a hair mesh into an exact,
plain center curve.

1. Enter Mesh Edit Mode and select only the root: a complete cap, one open or
   closed edge row, or one endpoint vertex.
2. Click **Preview Selected Root**.
3. Grow the selection toward the other end with `Ctrl+Numpad+`. The centerline
   preview updates automatically as layers are added or removed.
4. Click **Confirm Centerline** to create the Curve, or cancel to discard the
   preview.

Both a normal cap/edge root and a single-vertex `POINT` root are supported. A
multi-face cap, including a triangulated fan, is treated as one semantic cap:
its outer boundary defines the root layer and enclosed cap vertices are not
mistaken for later centerline layers.

Each valid topological layer contributes one preview point at the arithmetic
mean of that layer's current vertices. The points stay in source-object local
space and the source transform is copied to the confirmed Curve, preserving
the original placement and local precision.

The confirmed Curve remains deliberately plain. It has no bevel profile,
generated thickness, material, or automatic shaping; point Radius and Tilt
remain at Blender's defaults. Preview and confirmation do not modify the source
mesh or its selection.

## Source Metadata

The confirmed Curve keeps lossless, versioned source metadata for later profile
work. For every layer it records:

- the raw maximum vertex-to-vertex chord and the vertex pair that defines it;
- the maximum profile span used as the cross-section sizing reference;
- the local center, tangent, width axis, normal, and orientation source.

The metadata is stored in `SOURCE_OBJECT_LOCAL` space together with the source
matrix at confirmation time. It does not change the visible Curve. Later tools
can derive Radius, Tilt, or a profile without guessing or overwriting the raw
measurements.

The live panel keeps the working information in front: current layer-to-point
count, start/maximum/end profile span, orientation validity, and short errors.
Detailed per-layer measurements remain on the confirmed Curve.

## Refresh Add-on

Character Designer watches its installed Python files. **Refresh Add-on** is
hidden while the loaded code matches disk and appears only when the source has
changed, a refresh is running, or an error needs attention. Refresh validates
the Python files before reloading the add-on. It does not save or reload the
current `.blend`; session-only preview and output state is reset.
