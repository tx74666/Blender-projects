bl_info = {
    "name": "Character Designer",
    "author": "Randy & Codex",
    "version": (0, 4, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Character",
    "description": "Build exact center curves from selected character-mesh slices.",
    "category": "3D View",
}

import hashlib
import importlib
import json
import math
import os
import sys
import textwrap
import time
import traceback
from array import array
from collections import defaultdict, deque

import bmesh
import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Vector


GENERATOR_ID = "character_designer_centerline_v1"
METADATA_VERSION = 2
METADATA_SPACE = "SOURCE_OBJECT_LOCAL"
EPSILON = 1.0e-8

ADDON_SOURCE_ROOT = os.path.dirname(os.path.abspath(__file__))
ADDON_MODULE_NAME = (__package__ or os.path.basename(ADDON_SOURCE_ROOT)).split(".")[0]
ADDON_REFRESH_PENDING = False
ADDON_REFRESH_LAST_STATE = False
ADDON_REFRESH_LAST_ERROR = ""

LIVE_PREVIEW_INTERVAL = 0.1
LIVE_PREVIEW_TOPOLOGY_DEBOUNCE = 0.35
LIVE_PREVIEW_COLOR = (1.0, 0.32, 0.04, 1.0)
_LIVE_PREVIEW_INPUT_SIGNATURE = None
_LIVE_PREVIEW_WORLD_POINTS = ()
_LIVE_PREVIEW_LAYERS = ()
_LIVE_PREVIEW_METADATA_JSON = ""
_LIVE_PREVIEW_SOURCE_KEY = None
_LIVE_PREVIEW_TRACKED_SOURCE_KEY = None
_LIVE_PREVIEW_DRAW_HANDLE = None
_LIVE_PREVIEW_SHADER = None
_LIVE_PREVIEW_LINE_BATCH = None
_LIVE_PREVIEW_POINT_BATCH = None
_LIVE_PREVIEW_BATCH_REVISION = -1
_LIVE_PREVIEW_DRAW_FAILED = False
_LIVE_PREVIEW_DRAW_RETRY_AT = 0.0
_LIVE_PREVIEW_DEPSGRAPH_REVISION = 0
_LIVE_PREVIEW_TOPOLOGY_SIGNATURE = ""
_LIVE_PREVIEW_TOPOLOGY_DIRTY = True
_LIVE_PREVIEW_TOPOLOGY_AUDIT_AT = 0.0
_LIVE_PREVIEW_TOPOLOGY_VERIFIED = False


class CenterlineError(ValueError):
    """A topology or selection problem that can be shown directly to the artist."""


class TopologyChangedError(CenterlineError):
    """The captured mesh connectivity is no longer the connectivity being edited."""


def _source_files():
    paths = []
    for root, directory_names, file_names in os.walk(ADDON_SOURCE_ROOT):
        directory_names[:] = [
            name
            for name in directory_names
            if name != "__pycache__" and not name.startswith(".")
        ]
        for file_name in file_names:
            if file_name.endswith(".py"):
                paths.append(os.path.join(root, file_name))
    return sorted(paths)


def _source_signature():
    signature = []
    for path in _source_files():
        try:
            stat = os.stat(path)
        except OSError:
            continue
        relative_path = os.path.relpath(path, ADDON_SOURCE_ROOT).replace(os.sep, "/")
        signature.append((relative_path, stat.st_mtime_ns, stat.st_size))
    return tuple(signature)


ADDON_LOADED_SIGNATURE = _source_signature()


def _source_changed():
    return _source_signature() != ADDON_LOADED_SIGNATURE


def _refresh_ui_visible():
    return bool(
        ADDON_REFRESH_PENDING
        or ADDON_REFRESH_LAST_STATE
        or ADDON_REFRESH_LAST_ERROR
    )


def _validate_source_files():
    for path in _source_files():
        with open(path, "rb") as handle:
            compile(handle.read(), path, "exec")


def _tag_view3d_redraw():
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _source_watch_deferred():
    global ADDON_REFRESH_LAST_STATE, ADDON_REFRESH_LAST_ERROR

    try:
        changed = _source_changed()
        if changed != ADDON_REFRESH_LAST_STATE:
            ADDON_REFRESH_LAST_STATE = changed
            _tag_view3d_redraw()
    except Exception as exc:
        ADDON_REFRESH_LAST_ERROR = f"Source watcher failed: {exc}"
        _tag_view3d_redraw()
    return 1.0


def _register_source_watch():
    global ADDON_REFRESH_LAST_STATE, ADDON_REFRESH_LAST_ERROR

    try:
        ADDON_REFRESH_LAST_STATE = _source_changed()
        if not bpy.app.timers.is_registered(_source_watch_deferred):
            bpy.app.timers.register(
                _source_watch_deferred,
                first_interval=1.0,
                persistent=True,
            )
    except Exception as exc:
        ADDON_REFRESH_LAST_ERROR = f"Source watcher failed: {exc}"
        print(f"[Character Designer] Could not start source watcher: {exc}")
        _tag_view3d_redraw()
        return False
    return True


def _unregister_source_watch():
    try:
        if bpy.app.timers.is_registered(_source_watch_deferred):
            bpy.app.timers.unregister(_source_watch_deferred)
    except Exception:
        pass


def _reload_addon_deferred():
    global ADDON_REFRESH_PENDING, ADDON_REFRESH_LAST_ERROR

    import addon_utils

    module_name = ADDON_MODULE_NAME
    old_modules = {
        name: module
        for name, module in list(sys.modules.items())
        if name == module_name or name.startswith(f"{module_name}.")
    }
    old_main = old_modules.get(module_name)
    persistent = bool(getattr(old_main, "__addon_persistent__", False)) if old_main else False

    try:
        try:
            addon_utils.disable(module_name, default_set=False, refresh_handled=True)
        except TypeError:
            addon_utils.disable(module_name, default_set=False)

        for name in old_modules:
            sys.modules.pop(name, None)
        importlib.invalidate_caches()

        try:
            reloaded = addon_utils.enable(
                module_name,
                default_set=False,
                persistent=persistent,
                refresh_handled=True,
            )
        except TypeError:
            reloaded = addon_utils.enable(
                module_name,
                default_set=False,
                persistent=persistent,
            )
        if reloaded is None:
            raise RuntimeError("Blender could not enable the refreshed add-on.")
        print("[Character Designer] Add-on refreshed successfully.")
    except Exception as exc:
        traceback.print_exc()
        for name in list(sys.modules):
            if name == module_name or name.startswith(f"{module_name}."):
                sys.modules.pop(name, None)
        sys.modules.update(old_modules)
        if old_main is not None:
            try:
                old_main.ADDON_REFRESH_PENDING = False
                old_main.ADDON_REFRESH_LAST_ERROR = str(exc)
                # register() is deliberately idempotent. If disable failed before
                # unregistering anything this is a no-op; if enable failed after a
                # successful disable it restores the old, known-good classes.
                old_main.register()
                old_main.__addon_enabled__ = True
            except Exception:
                traceback.print_exc()
        ADDON_REFRESH_PENDING = False
        ADDON_REFRESH_LAST_ERROR = str(exc)
    return None


def _mesh_object_poll(_self, obj):
    return obj is not None and obj.type == "MESH"


def _curve_object_poll(_self, obj):
    return obj is not None and obj.type == "CURVE"


class CharacterDesignerState(PropertyGroup):
    root_object: PointerProperty(
        name="Root Object",
        type=bpy.types.Object,
        poll=_mesh_object_poll,
        options={"SKIP_SAVE"},
    )
    root_mesh: PointerProperty(
        name="Root Mesh",
        type=bpy.types.Mesh,
        options={"SKIP_SAVE"},
    )
    root_indices_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_edges_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_ignored_indices_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_kind: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_capture_mode: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    root_vertex_count: IntProperty(default=0, min=0, options={"SKIP_SAVE"})
    root_ignored_count: IntProperty(default=0, min=0, options={"SKIP_SAVE"})
    topology_signature: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    output_object: PointerProperty(
        name="Output",
        type=bpy.types.Object,
        poll=_curve_object_poll,
        options={"SKIP_SAVE"},
    )
    last_level: StringProperty(default="NONE", options={"HIDDEN", "SKIP_SAVE"})
    last_message: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    preview_active: BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    preview_valid: BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    preview_confirmable: BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    preview_layer_count: IntProperty(default=0, min=0, options={"HIDDEN", "SKIP_SAVE"})
    preview_message: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    preview_action_error: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    preview_revision: IntProperty(default=0, min=0, options={"HIDDEN", "SKIP_SAVE"})
    preview_root_span: FloatProperty(default=0.0, min=0.0, options={"HIDDEN", "SKIP_SAVE"})
    preview_max_span: FloatProperty(default=0.0, min=0.0, options={"HIDDEN", "SKIP_SAVE"})
    preview_tip_span: FloatProperty(default=0.0, min=0.0, options={"HIDDEN", "SKIP_SAVE"})
    preview_orientation_valid: BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})


def _settings(context):
    window_manager = getattr(context, "window_manager", None)
    return getattr(window_manager, "character_designer", None)


def _set_status(settings, level, message):
    settings.last_level = level
    settings.last_message = message


def _clear_capture(settings):
    settings.root_object = None
    settings.root_mesh = None
    settings.root_indices_json = ""
    settings.root_edges_json = ""
    settings.root_ignored_indices_json = ""
    settings.root_kind = ""
    settings.root_capture_mode = ""
    settings.root_vertex_count = 0
    settings.root_ignored_count = 0
    settings.topology_signature = ""


def _edit_bmesh(context):
    obj = context.edit_object
    if obj is None or obj.type != "MESH" or obj.mode != "EDIT":
        raise CenterlineError("Enter Mesh Edit Mode on one hair object.")
    if context.object is not obj:
        raise CenterlineError("The edited hair object must be active.")

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.verts.index_update()
    bm.edges.index_update()
    bm.faces.index_update()
    return obj, bm


def _topology_signature(bm):
    """Hash connectivity canonically while preserving polygon winding."""

    digest = hashlib.sha256()
    digest.update(f"v{len(bm.verts)}e{len(bm.edges)}f{len(bm.faces)}|".encode("ascii"))
    edge_keys = sorted(
        tuple(sorted((edge.verts[0].index, edge.verts[1].index)))
        for edge in bm.edges
    )
    edge_values = array("i")
    for first, second in edge_keys:
        edge_values.extend((first, second))
    face_keys = []
    for face in bm.faces:
        indices = tuple(vertex.index for vertex in face.verts)
        start = indices.index(min(indices))
        # Rotating a polygon's loop start is semantically irrelevant; reversing
        # it is not, because source winding is used for the saved normal frame.
        face_keys.append(indices[start:] + indices[:start])
    face_keys.sort()
    face_values = array("i")
    for face_key in face_keys:
        face_values.append(len(face_key))
        face_values.extend(face_key)
    digest.update(edge_values.tobytes())
    digest.update(b"|")
    digest.update(face_values.tobytes())
    return digest.hexdigest()


def _indices_from_settings(settings):
    try:
        values = json.loads(settings.root_indices_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CenterlineError("The captured root is invalid. Capture it again.") from exc
    if not isinstance(values, list) or not values:
        raise CenterlineError("Capture a root slice first.")
    try:
        indices = tuple(sorted({int(value) for value in values}))
    except (TypeError, ValueError) as exc:
        raise CenterlineError("The captured root is invalid. Capture it again.") from exc
    if len(indices) != len(values):
        raise CenterlineError("The captured root is invalid. Capture it again.")
    return indices


def _ignored_indices_from_settings(settings):
    if not settings.root_ignored_indices_json:
        return ()
    try:
        values = json.loads(settings.root_ignored_indices_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CenterlineError("The captured cap interior is invalid. Capture the root again.") from exc
    if not isinstance(values, list):
        raise CenterlineError("The captured cap interior is invalid. Capture the root again.")
    try:
        indices = tuple(sorted({int(value) for value in values}))
    except (TypeError, ValueError) as exc:
        raise CenterlineError("The captured cap interior is invalid. Capture the root again.") from exc
    if len(indices) != len(values):
        raise CenterlineError("The captured cap interior is invalid. Capture the root again.")
    return indices


def _root_edges_from_settings(settings):
    try:
        values = json.loads(settings.root_edges_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise CenterlineError("The captured root edges are invalid. Capture the root again.") from exc
    if not isinstance(values, list):
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")
    if not values:
        if settings.root_kind == "POINT":
            return ()
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")

    edge_keys = []
    try:
        for value in values:
            if not isinstance(value, list) or len(value) != 2:
                raise ValueError
            first, second = sorted((int(value[0]), int(value[1])))
            if first == second:
                raise ValueError
            edge_keys.append((first, second))
    except (TypeError, ValueError) as exc:
        raise CenterlineError("The captured root edges are invalid. Capture the root again.") from exc
    if len(set(edge_keys)) != len(edge_keys):
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")
    return tuple(sorted(edge_keys))


def _adjacency_from_edge_keys(vertex_indices, edge_keys):
    vertex_indices = set(vertex_indices)
    adjacency = {index: set() for index in vertex_indices}
    for first, second in edge_keys:
        if first in vertex_indices and second in vertex_indices:
            adjacency[first].add(second)
            adjacency[second].add(first)
    return adjacency


def _selected_edge_keys(bm, vertex_indices):
    vertex_indices = set(vertex_indices)
    edge_keys = set()
    for vertex_index in vertex_indices:
        for edge in bm.verts[vertex_index].link_edges:
            if not edge.select:
                continue
            first = edge.verts[0].index
            second = edge.verts[1].index
            if first in vertex_indices and second in vertex_indices:
                edge_keys.add(tuple(sorted((first, second))))
    return tuple(sorted(edge_keys))


def _is_connected(indices, adjacency):
    indices = set(indices)
    if not indices:
        return False
    visited = set()
    queue = deque((next(iter(indices)),))
    while queue:
        current = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        queue.extend((adjacency[current] & indices) - visited)
    return visited == indices


def _classify_slice(indices, adjacency, *, label):
    indices = set(indices)
    count = len(indices)
    if count == 1:
        return "POINT"
    if not _is_connected(indices, adjacency):
        raise CenterlineError(f"{label} is split into multiple pieces.")

    degrees = {index: len(adjacency[index] & indices) for index in indices}
    edge_count = sum(degrees.values()) // 2
    if count >= 3 and edge_count == count and all(value == 2 for value in degrees.values()):
        return "CLOSED"
    if edge_count == count - 1:
        end_count = sum(value == 1 for value in degrees.values())
        middle_ok = all(value in {1, 2} for value in degrees.values())
        if end_count == 2 and middle_ok:
            return "OPEN"
    raise CenterlineError(
        f"{label} branches or is not one simple row/loop. Select one clean cross-section."
    )


def _root_label(kind):
    return {
        "POINT": "point root",
        "CLOSED": "closed loop",
        "OPEN": "open row",
    }.get(kind, "cross-section")


def _captured_root_label(settings):
    if settings.root_capture_mode in {"CAP", "FAN_CAP", "TRI_CAP", "REGION_CAP"}:
        return "cap boundary"
    return _root_label(settings.root_kind)


def _slice_edge_keys(indices, adjacency):
    indices = set(indices)
    return {
        tuple(sorted((first, second)))
        for first in indices
        for second in adjacency[first] & indices
        if first < second
    }


def _validate_face_bands(bm, selected, layers, distances, adjacency):
    """Confirm that graph layers are backed by complete quad surface bands."""

    final_layer_index = len(layers) - 1
    band_faces = defaultdict(list)
    relevant_band_faces = set()
    candidate_faces = {
        face
        for vertex_index in selected
        for face in bm.verts[vertex_index].link_faces
    }
    for face in sorted(candidate_faces, key=lambda value: value.index):
        indices = tuple(vertex.index for vertex in face.verts)
        if not all(index in selected for index in indices):
            continue
        face_layers = {distances[index] for index in indices}
        if len(face_layers) == 1:
            layer_index = next(iter(face_layers))
            if layer_index not in {0, final_layer_index}:
                raise CenterlineError(
                    f"Layer {layer_index + 1} contains an internal cap face."
                )
            continue
        if len(face_layers) != 2:
            raise CenterlineError("A selected face crosses more than one layer.")

        lower_layer = min(face_layers)
        upper_layer = max(face_layers)
        if upper_layer != lower_layer + 1:
            raise CenterlineError("A selected face skips a centerline layer.")
        lower_vertices = tuple(index for index in indices if distances[index] == lower_layer)
        upper_vertices = tuple(index for index in indices if distances[index] == upper_layer)
        lower_is_point = len(layers[lower_layer]) == 1
        upper_is_point = len(layers[upper_layer]) == 1
        if lower_is_point:
            valid_counts = (
                not upper_is_point
                and len(face.verts) == 3
                and len(lower_vertices) == 1
                and len(upper_vertices) == 2
            )
            expected = "a 1+2 root triangle"
        elif upper_is_point:
            valid_counts = (
                len(face.verts) == 3
                and len(lower_vertices) == 2
                and len(upper_vertices) == 1
            )
            expected = "a 2+1 tip triangle"
        else:
            valid_counts = (
                len(face.verts) == 4
                and len(lower_vertices) == 2
                and len(upper_vertices) == 2
            )
            expected = "a 2+2 quad"
        if not valid_counts:
            raise CenterlineError(
                f"The band between layers {lower_layer + 1} and {upper_layer + 1} "
                f"contains a face that is not {expected}."
            )

        face_edges = {
            tuple(sorted((edge.verts[0].index, edge.verts[1].index)))
            for edge in face.edges
        }
        lower_edge = None
        if not lower_is_point:
            lower_edge = tuple(sorted(lower_vertices))
            if lower_edge not in face_edges or lower_edge not in _slice_edge_keys(
                layers[lower_layer], adjacency
            ):
                raise CenterlineError(
                    f"A face between layers {lower_layer + 1} and {upper_layer + 1} is twisted."
                )
        upper_edge = None
        if not upper_is_point:
            upper_edge = tuple(sorted(upper_vertices))
            if upper_edge not in face_edges or upper_edge not in _slice_edge_keys(
                layers[upper_layer], adjacency
            ):
                raise CenterlineError(
                    f"A face between layers {lower_layer + 1} and {upper_layer + 1} is twisted."
                )
        band_faces[lower_layer].append((lower_edge, upper_edge))
        relevant_band_faces.add(face)

    # The undirected edge/face counts above cannot distinguish a coherent band
    # from one containing a flipped polygon.  Check every shared band edge with
    # BMesh's winding-aware manifold predicate before any normals are averaged
    # into persistent orientation metadata.
    relevant_band_edges = {
        edge for face in relevant_band_faces for edge in face.edges
    }
    for edge in sorted(relevant_band_edges, key=lambda value: value.index):
        linked_band_faces = [
            face for face in edge.link_faces if face in relevant_band_faces
        ]
        if len(linked_band_faces) > 2:
            first, second = sorted(vertex.index for vertex in edge.verts)
            raise CenterlineError(
                f"Selected side-band edge {first}-{second} is non-manifold."
            )
        if len(linked_band_faces) == 2:
            first, second = sorted(vertex.index for vertex in edge.verts)
            if not edge.is_manifold:
                raise CenterlineError(
                    f"Selected side-band edge {first}-{second} is non-manifold."
                )
            if not edge.is_contiguous:
                raise CenterlineError(
                    "Selected side-band faces have inconsistent winding across "
                    f"edge {first}-{second}."
                )

    for lower_layer in range(final_layer_index):
        upper_layer = lower_layer + 1
        actual_faces = band_faces.get(lower_layer, [])
        lower_is_point = len(layers[lower_layer]) == 1
        upper_is_point = len(layers[upper_layer]) == 1

        if lower_is_point:
            expected_upper_edges = _slice_edge_keys(layers[upper_layer], adjacency)
            actual_upper_edges = [upper_edge for _lower_edge, upper_edge in actual_faces]
            if (
                len(actual_faces) != len(expected_upper_edges)
                or set(actual_upper_edges) != expected_upper_edges
                or len(set(actual_upper_edges)) != len(actual_upper_edges)
            ):
                raise CenterlineError(
                    f"Layers {lower_layer + 1} and {upper_layer + 1} do not have "
                    "one complete point-root triangle band."
                )
            continue

        expected_lower_edges = _slice_edge_keys(layers[lower_layer], adjacency)
        actual_lower_edges = [lower_edge for lower_edge, _upper_edge in actual_faces]
        if (
            len(actual_faces) != len(expected_lower_edges)
            or set(actual_lower_edges) != expected_lower_edges
            or len(set(actual_lower_edges)) != len(actual_lower_edges)
        ):
            raise CenterlineError(
                f"Layers {lower_layer + 1} and {upper_layer + 1} do not have one complete face band."
            )

        if not upper_is_point:
            expected_upper_edges = _slice_edge_keys(layers[upper_layer], adjacency)
            actual_upper_edges = [upper_edge for _lower_edge, upper_edge in actual_faces]
            if (
                set(actual_upper_edges) != expected_upper_edges
                or len(set(actual_upper_edges)) != len(actual_upper_edges)
            ):
                raise CenterlineError(
                    f"Layers {lower_layer + 1} and {upper_layer + 1} have mismatched quad faces."
                )


def _selection_counts(bm):
    return (
        sum(vertex.select for vertex in bm.verts),
        sum(edge.select for edge in bm.edges),
        sum(face.select for face in bm.faces),
    )


def _selected_faces_are_one_edge_component(selected_faces):
    face_set = set(selected_faces)
    visited = set()
    queue = deque((selected_faces[0],))
    while queue:
        face = queue.popleft()
        if face in visited:
            continue
        visited.add(face)
        for edge in face.edges:
            queue.extend(
                linked_face
                for linked_face in edge.link_faces
                if linked_face in face_set and linked_face not in visited
            )
    return visited == face_set


def _capture_selected_face_boundary(bm, selected_faces):
    """Extract one cap boundary from a face-connected topological disk.

    The selected faces may use any polygon sizes, but their complete boundary
    must meet one provably regular, unselected side band.  That positive collar
    test is important: a whole card, a partial card, and one arbitrary side face
    can all be topological disks too, but none is the cap of a regular tube.
    """

    selected_faces = tuple(selected_faces)
    if not _selected_faces_are_one_edge_component(selected_faces):
        raise CenterlineError("The selected cap contains multiple disconnected face islands.")

    region_vertices = {vertex for face in selected_faces for vertex in face.verts}
    region_edges = {edge for face in selected_faces for edge in face.edges}
    extra_vertices = {vertex for vertex in bm.verts if vertex.select} - region_vertices
    extra_edges = {edge for edge in bm.edges if edge.select} - region_edges
    if extra_vertices or extra_edges:
        raise CenterlineError("Do not mix a cap selection with extra vertices or edges.")

    face_incidence = defaultdict(int)
    for face in selected_faces:
        for edge in face.edges:
            face_incidence[edge] += 1
    if any(count > 2 for count in face_incidence.values()):
        raise CenterlineError("The selected cap contains a non-manifold shared edge.")
    if any(len(edge.link_faces) > 2 for edge in region_edges):
        raise CenterlineError("The selected cap touches non-manifold mesh geometry.")

    boundary_edges = {edge for edge, count in face_incidence.items() if count == 1}
    if not boundary_edges:
        raise CenterlineError("The selected cap has no open boundary.")
    boundary_vertices = {vertex for edge in boundary_edges for vertex in edge.verts}
    boundary_edge_keys = tuple(
        sorted(
            tuple(sorted((edge.verts[0].index, edge.verts[1].index)))
            for edge in boundary_edges
        )
    )
    boundary_indices = tuple(sorted(vertex.index for vertex in boundary_vertices))
    boundary_adjacency = _adjacency_from_edge_keys(boundary_indices, boundary_edge_keys)
    try:
        boundary_kind = _classify_slice(
            boundary_indices,
            boundary_adjacency,
            label="The cap boundary",
        )
    except CenterlineError as exc:
        raise CenterlineError("The selected cap must have exactly one simple boundary loop.") from exc
    if boundary_kind != "CLOSED":
        raise CenterlineError("The selected cap boundary is not closed.")

    interior_vertices = region_vertices - boundary_vertices
    if len(region_vertices) - len(region_edges) + len(selected_faces) != 1:
        raise CenterlineError("The selected faces are not one topological disk.")

    # Every enclosed vertex must really be enclosed by the selected region.  An
    # unselected incident edge means that the artist selected only part of a
    # larger triangulated surface and the apparent boundary is misleading.
    if any(
        edge not in region_edges
        for vertex in interior_vertices
        for edge in vertex.link_edges
    ):
        raise CenterlineError(
            "A cap interior vertex is connected to geometry outside the selected region."
        )

    # A cap boundary vertex has exactly one longitudinal edge into the first
    # unselected side band.  This gives an explicit boundary -> next-layer map,
    # rather than trying to infer cap semantics from polygon sizes.
    next_vertex_by_boundary = {}
    leaving_edge_by_boundary = {}
    for vertex in boundary_vertices:
        leaving_edges = [edge for edge in vertex.link_edges if edge not in region_edges]
        if len(leaving_edges) != 1:
            raise CenterlineError(
                "The selected face region has no complete regular first collar: "
                "each cap boundary vertex needs exactly one outgoing side edge."
            )
        leaving_edge = leaving_edges[0]
        next_vertex = leaving_edge.other_vert(vertex)
        if next_vertex in region_vertices:
            raise CenterlineError(
                "The selected face region has an extra chord instead of a regular first collar."
            )
        leaving_edge_by_boundary[vertex] = leaving_edge
        next_vertex_by_boundary[vertex] = next_vertex

    next_vertices = set(next_vertex_by_boundary.values())
    normal_collar = len(next_vertices) == len(boundary_vertices)
    collapsed_collar = len(next_vertices) == 1
    if not normal_collar and not collapsed_collar:
        raise CenterlineError(
            "The selected cap collar branches between its boundary and the next layer."
        )

    # Every boundary edge must own exactly one outside band face.  For a normal
    # collar that face is the exact quad (root edge, two longitudinal edges,
    # outer edge); a uniformly collapsed collar uses one triangle and a shared
    # point tip.  Checking edge sets as well as vertices rejects twisted faces.
    selected_face_set = set(selected_faces)
    outside_face_use = defaultdict(int)
    outer_edge_keys = []
    for edge in boundary_edges:
        first, second = edge.verts
        next_first = next_vertex_by_boundary[first]
        next_second = next_vertex_by_boundary[second]
        outside_faces = [face for face in edge.link_faces if face not in selected_face_set]
        if len(outside_faces) != 1:
            raise CenterlineError(
                "The selected face region has no complete regular first collar: "
                "every cap edge must meet one unselected side face."
            )
        outside_face = outside_faces[0]
        outside_face_use[outside_face] += 1

        expected_vertices = {first, second, next_first, next_second}
        expected_edge_keys = {
            tuple(sorted((first.index, second.index))),
            tuple(sorted((first.index, next_first.index))),
            tuple(sorted((second.index, next_second.index))),
        }
        if normal_collar:
            expected_edge_keys.add(tuple(sorted((next_first.index, next_second.index))))
            expected_face_size = 4
        else:
            expected_face_size = 3
        actual_edge_keys = {
            tuple(sorted((face_edge.verts[0].index, face_edge.verts[1].index)))
            for face_edge in outside_face.edges
        }
        if (
            len(outside_face.verts) != expected_face_size
            or set(outside_face.verts) != expected_vertices
            or actual_edge_keys != expected_edge_keys
        ):
            expected_label = "quad" if normal_collar else "tip triangle"
            raise CenterlineError(
                f"The first collar needs one untwisted {expected_label} per cap boundary edge."
            )
        if leaving_edge_by_boundary[first] not in outside_face.edges or (
            leaving_edge_by_boundary[second] not in outside_face.edges
        ):
            raise CenterlineError("A first-collar face does not use its mapped side edges.")
        if normal_collar:
            outer_edge_keys.append(tuple(sorted((next_first.index, next_second.index))))

    if any(count != 1 for count in outside_face_use.values()):
        raise CenterlineError(
            "Each first-collar face must correspond to exactly one cap boundary edge."
        )

    if normal_collar:
        next_indices = tuple(sorted(vertex.index for vertex in next_vertices))
        outer_adjacency = _adjacency_from_edge_keys(next_indices, outer_edge_keys)
        try:
            outer_kind = _classify_slice(
                next_indices,
                outer_adjacency,
                label="The first collar outer edge",
            )
        except CenterlineError as exc:
            raise CenterlineError(
                "The first collar outer edges do not form one simple closed loop."
            ) from exc
        if outer_kind != "CLOSED":
            raise CenterlineError(
                "The first collar outer edges do not form one simple closed loop."
            )

    ignored_indices = tuple(sorted(vertex.index for vertex in interior_vertices))
    return boundary_indices, boundary_edge_keys, ignored_indices, "REGION_CAP"


def _capture_data(context):
    obj, bm = _edit_bmesh(context)
    selected_faces = tuple(face for face in bm.faces if face.select)
    if selected_faces:
        root_indices, edge_keys, ignored_indices, capture_mode = _capture_selected_face_boundary(
            bm,
            selected_faces,
        )
        return obj, bm, root_indices, edge_keys, "CLOSED", ignored_indices, capture_mode

    selected = {vertex.index for vertex in bm.verts if vertex.select}
    if not selected:
        raise CenterlineError(
            "Select one root point, one root edge row, or one root cap face, then capture."
        )

    edge_keys = _selected_edge_keys(bm, selected)
    adjacency = _adjacency_from_edge_keys(selected, edge_keys)
    kind = _classify_slice(selected, adjacency, label="The root selection")
    capture_mode = "POINT" if kind == "POINT" else "EDGES"
    return obj, bm, tuple(sorted(selected)), edge_keys, kind, (), capture_mode


def _validate_capture(context, settings, *, check_topology=True):
    obj, bm = _edit_bmesh(context)
    if settings.root_object is None:
        raise CenterlineError("Capture a root slice first.")
    if obj is not settings.root_object or obj.data is not settings.root_mesh:
        raise CenterlineError("Return to the captured hair object, or capture a new root.")
    if check_topology and _topology_signature(bm) != settings.topology_signature:
        raise TopologyChangedError("Hair topology changed after capture. Capture the root again.")

    root_indices = _indices_from_settings(settings)
    root_edge_keys = _root_edges_from_settings(settings)
    ignored_indices = _ignored_indices_from_settings(settings)
    if root_indices[-1] >= len(bm.verts) or (
        ignored_indices and ignored_indices[-1] >= len(bm.verts)
    ):
        raise TopologyChangedError("Hair topology changed after capture. Capture the root again.")
    root_set = set(root_indices)
    ignored_set = set(ignored_indices)
    if root_set & ignored_set:
        raise CenterlineError("The captured cap boundary overlaps its interior. Capture it again.")
    if any(first not in root_set or second not in root_set for first, second in root_edge_keys):
        raise CenterlineError("The captured root edges are invalid. Capture the root again.")
    adjacency = _adjacency_from_edge_keys(root_set, root_edge_keys)
    kind = _classify_slice(root_set, adjacency, label="The captured root")
    if kind != settings.root_kind:
        raise TopologyChangedError("The captured root topology changed. Capture it again.")
    return obj, bm, root_indices, root_edge_keys, ignored_indices


def _extract_layers(
    context,
    settings,
    *,
    check_topology=True,
    validated_capture=None,
):
    if validated_capture is None:
        validated_capture = _validate_capture(
            context,
            settings,
            check_topology=check_topology,
        )
    obj, bm, root_indices, root_edge_keys, ignored_indices = validated_capture
    ignored_set = set(ignored_indices)
    selected = {
        vertex.index
        for vertex in bm.verts
        if vertex.select and vertex.index not in ignored_set
    }
    root_set = set(root_indices)
    missing = root_set - selected
    if missing:
        raise CenterlineError("Keep the captured root selected while growing toward the tip.")
    if selected == root_set:
        raise CenterlineError("Only the root is selected. Grow the selection toward the tip.")

    selected_edge_keys = [
        edge_key
        for edge_key in _selected_edge_keys(bm, selected)
        if not (edge_key[0] in root_set and edge_key[1] in root_set)
    ]
    selected_edge_keys.extend(root_edge_keys)
    adjacency = _adjacency_from_edge_keys(selected, selected_edge_keys)
    distances = {index: 0 for index in root_set}
    queue = deque(root_indices)
    while queue:
        current = queue.popleft()
        next_distance = distances[current] + 1
        for neighbor in adjacency[current]:
            if neighbor not in distances:
                distances[neighbor] = next_distance
                queue.append(neighbor)
    unreachable = selected - distances.keys()
    if unreachable:
        raise CenterlineError(
            f"The selection contains {len(unreachable)} vertex/vertices disconnected from the root."
        )

    grouped = defaultdict(list)
    for index, distance in distances.items():
        grouped[distance].append(index)
    layers = [tuple(sorted(grouped[distance])) for distance in range(max(grouped) + 1)]
    if set(layers[0]) != root_set:
        raise CenterlineError("The captured root could not be reconstructed. Capture it again.")

    regular_kind = None
    for layer_index, layer in enumerate(layers):
        kind = _classify_slice(
            layer,
            adjacency,
            label=f"Layer {layer_index + 1}",
        )
        is_last = layer_index == len(layers) - 1
        if kind == "POINT":
            if layer_index != 0 and not is_last:
                raise CenterlineError(
                    f"Layer {layer_index + 1} is a point between regular cross-sections. "
                    "A point is supported only at the root or tip."
                )
        elif regular_kind is None:
            regular_kind = kind
        elif kind != regular_kind:
            raise CenterlineError(
                f"Layer {layer_index + 1} changes from {_root_label(regular_kind)} "
                f"to {_root_label(kind)}. Check the selection."
            )

        if layer_index == 0:
            continue
        previous = set(layers[layer_index - 1])
        current = set(layer)
        cross_edges = []
        for previous_index in previous:
            for current_index in adjacency[previous_index] & current:
                cross_edges.append((previous_index, current_index))

        previous_degree = defaultdict(int)
        current_degree = defaultdict(int)
        for previous_index, current_index in cross_edges:
            previous_degree[previous_index] += 1
            current_degree[current_index] += 1

        previous_is_point = len(previous) == 1
        current_is_point = len(current) == 1
        if previous_is_point:
            # A point root expands through one complete triangle fan into the
            # first regular open row or closed loop. Every vertex in that first
            # section must connect directly and only once to the root point.
            root_index = next(iter(previous))
            complete = (
                layer_index == 1
                and not current_is_point
                and len(cross_edges) == len(current)
                and previous_degree[root_index] == len(current)
                and all(current_degree[index] == 1 for index in current)
            )
        elif current_is_point:
            # A collapsed point tip is valid only when every vertex in the last
            # regular slice connects directly to that one final vertex.
            complete = (
                is_last
                and len(cross_edges) == len(previous)
                and all(previous_degree[index] == 1 for index in previous)
                and current_degree[next(iter(current))] == len(previous)
            )
        else:
            # The artist's source is a regular quad strip/tube. One-to-one
            # longitudinal edges make each graph-distance layer unambiguous;
            # many-to-many links would let BFS hide a branch or triangulated
            # shortcut inside an apparently valid row.
            complete = (
                len(previous) == len(current) == len(cross_edges)
                and all(previous_degree[index] == 1 for index in previous)
                and all(current_degree[index] == 1 for index in current)
            )
        if not complete:
            band_label = (
                "one complete point-root triangle band"
                if previous_is_point
                else "one regular quad band"
            )
            raise CenterlineError(
                f"Layers {layer_index} and {layer_index + 1} do not form {band_label}."
            )

    if regular_kind is None:
        raise CenterlineError("The selection needs at least one regular cross-section after the point root.")

    _validate_face_bands(bm, selected, layers, distances, adjacency)

    _validate_layer_coordinates(bm, layers)
    _validate_source_matrix(obj)
    centers = []
    for layer_index, layer in enumerate(layers):
        center = sum((bm.verts[index].co for index in layer), Vector((0.0, 0.0, 0.0))) / len(layer)
        if not _vector_is_finite(center):
            raise CenterlineError(
                f"Layer {layer_index + 1} has a non-finite center point."
            )
        if centers and (center - centers[-1]).length <= EPSILON:
            raise CenterlineError(
                f"Layers {layer_index} and {layer_index + 1} have the same center point."
            )
        centers.append(center.copy())
    return obj, bm, tuple(layers), tuple(centers)


def _regular_kind_from_layers(bm, layers):
    """Return the first non-point layer kind for a captured POINT root."""

    for layer_index, layer in enumerate(layers):
        if len(layer) == 1:
            continue
        edge_keys = _selected_edge_keys(bm, layer)
        adjacency = _adjacency_from_edge_keys(layer, edge_keys)
        kind = _classify_slice(
            layer,
            adjacency,
            label=f"Layer {layer_index + 1}",
        )
        if kind in {"OPEN", "CLOSED"}:
            return kind
    raise CenterlineError("A point root needs a following open row or closed loop.")


def _is_finite_number(value):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(float(value))
    except (OverflowError, TypeError, ValueError):
        return False


def _vector_is_finite(value):
    try:
        return len(value) == 3 and all(_is_finite_number(component) for component in value)
    except TypeError:
        return False


def _validate_layer_coordinates(bm, layers):
    for layer_index, layer in enumerate(layers):
        for vertex_index in layer:
            if not _vector_is_finite(bm.verts[vertex_index].co):
                raise CenterlineError(
                    f"Layer {layer_index + 1} vertex {vertex_index} has non-finite coordinates."
                )


def _validate_source_matrix(source_obj):
    for row in range(4):
        for column in range(4):
            if not _is_finite_number(source_obj.matrix_world[row][column]):
                raise CenterlineError(
                    "The source object transform has a non-finite value at "
                    f"row {row + 1}, column {column + 1}."
                )


def _unit_vector_or_none(value):
    value = Vector(value)
    if value.length <= EPSILON:
        return None
    return value.normalized()


def _project_to_normal_plane(value, normal):
    value = Vector(value)
    normal = Vector(normal)
    return _unit_vector_or_none(value - normal * value.dot(normal))


def _vector_json(value):
    return [float(value.x), float(value.y), float(value.z)] if value is not None else None


def _layer_diameter(bm, layer):
    """Return the exact, deterministic maximum vertex chord for one layer."""

    if len(layer) == 1:
        return 0.0, None, None

    best_distance_squared = -1.0
    best_pair = None
    best_vector = None
    ordered = tuple(sorted(layer))
    for position, first in enumerate(ordered[:-1]):
        for second in ordered[position + 1 :]:
            chord = bm.verts[second].co - bm.verts[first].co
            distance_squared = chord.length_squared
            # Iteration is lexicographic, so an exact tie deliberately keeps
            # the first pair and produces the same result on every build.
            if distance_squared > best_distance_squared:
                best_distance_squared = distance_squared
                best_pair = (first, second)
                best_vector = chord.copy()
    return best_distance_squared ** 0.5, best_pair, best_vector


def _layer_profile_span(bm, layer, tangent):
    """Return the maximum vertex chord after projection normal to the tangent."""

    if len(layer) == 1:
        return 0.0, None, None

    best_distance_squared = -1.0
    best_pair = None
    best_vector = None
    ordered = tuple(sorted(layer))
    for position, first in enumerate(ordered[:-1]):
        for second in ordered[position + 1 :]:
            chord = bm.verts[second].co - bm.verts[first].co
            projected = chord - tangent * chord.dot(tangent)
            distance_squared = projected.length_squared
            if distance_squared > best_distance_squared:
                best_distance_squared = distance_squared
                best_pair = (first, second)
                best_vector = projected.copy()
    return best_distance_squared ** 0.5, best_pair, best_vector


def _center_tangents(centers):
    if len(centers) < 2:
        raise CenterlineError("A center curve needs at least two points.")

    tangents = []
    final_index = len(centers) - 1
    for index, center in enumerate(centers):
        if index == 0:
            tangent = _unit_vector_or_none(centers[1] - center)
        elif index == final_index:
            tangent = _unit_vector_or_none(center - centers[index - 1])
        else:
            incoming = _unit_vector_or_none(center - centers[index - 1])
            outgoing = _unit_vector_or_none(centers[index + 1] - center)
            tangent = _unit_vector_or_none(incoming + outgoing)
            if tangent is None:
                # A perfect 180-degree reversal has no bisector. The outgoing
                # segment is deterministic and keeps the frame well defined.
                tangent = outgoing
        if tangent is None:
            raise CenterlineError(f"Center point {index + 1} has no usable tangent.")
        tangents.append(tangent)
    return tuple(tangents)


def _deterministic_perpendicular(tangent):
    basis = min(
        (Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0))),
        key=lambda axis: abs(axis.dot(tangent)),
    )
    result = _project_to_normal_plane(basis, tangent)
    if result is None:
        raise CenterlineError("Could not construct a stable orientation frame.")
    return result


def _transport_axis(axis, previous_tangent, tangent):
    try:
        transported = previous_tangent.rotation_difference(tangent) @ axis
    except ValueError:
        transported = axis
    transported = _project_to_normal_plane(transported, tangent)
    return transported if transported is not None else _deterministic_perpendicular(tangent)


def _track_layer_anchors(bm, layers, profile_span_pairs):
    neighbors = defaultdict(set)
    relevant = {index for layer in layers for index in layer}
    for vertex_index in relevant:
        for edge in bm.verts[vertex_index].link_edges:
            first = edge.verts[0].index
            second = edge.verts[1].index
            if first in relevant and second in relevant:
                neighbors[first].add(second)
                neighbors[second].add(first)

    anchors = []
    for layer_index, (layer, profile_span_pair) in enumerate(
        zip(layers, profile_span_pairs)
    ):
        if len(layer) == 1:
            anchors.append(None)
            continue
        if layer_index == 0 or anchors[-1] is None:
            anchors.append(profile_span_pair[0] if profile_span_pair else min(layer))
            continue

        candidates = sorted(neighbors[anchors[-1]] & set(layer))
        # Regular-band validation guarantees one longitudinal match. Keep a
        # deterministic fallback so metadata construction never invents a
        # random orientation if malformed data somehow reaches this helper.
        anchors.append(
            candidates[0]
            if len(candidates) == 1
            else (profile_span_pair[0] if profile_span_pair else min(layer))
        )
    return tuple(anchors)


def _layer_band_normals(bm, layers):
    """Area-weight adjacent selected-band normals into one local vector/layer."""

    layer_by_vertex = {
        vertex_index: layer_index
        for layer_index, layer in enumerate(layers)
        for vertex_index in layer
    }
    weighted_normals = [Vector((0.0, 0.0, 0.0)) for _layer in layers]
    total_areas = [0.0 for _layer in layers]
    face_counts = [0 for _layer in layers]

    candidate_faces = {
        face
        for vertex_index in layer_by_vertex
        for face in bm.verts[vertex_index].link_faces
    }
    for face in sorted(candidate_faces, key=lambda value: value.index):
        indices = tuple(vertex.index for vertex in face.verts)
        if any(index not in layer_by_vertex for index in indices):
            continue
        face_layers = {layer_by_vertex[index] for index in indices}
        if len(face_layers) != 2 or max(face_layers) - min(face_layers) != 1:
            # Same-layer cap faces do not describe profile roll.
            continue
        face.normal_update()
        area = face.calc_area()
        if area <= 0.0 or face.normal.length <= EPSILON:
            continue
        weighted = face.normal * area
        for layer_index in face_layers:
            weighted_normals[layer_index] += weighted
            total_areas[layer_index] += area
            face_counts[layer_index] += 1

    results = []
    for weighted, total_area, face_count in zip(weighted_normals, total_areas, face_counts):
        # A closed tube's radial side normals cancel. Relative cancellation is
        # intentional and signals that the tracked profile-span anchor must carry
        # roll instead of an unstable near-zero average.
        meaningful = total_area > 0.0 and weighted.length > total_area * 1.0e-6
        results.append(
            (
                weighted.normalized() if meaningful else None,
                face_count,
            )
        )
    return tuple(results)


def _build_cross_section_metadata(source_obj, bm, layers, centers, regular_kind):
    """Capture lossless sizing and a stable local frame without shaping the Curve."""

    _validate_source_matrix(source_obj)
    diameters = tuple(_layer_diameter(bm, layer) for layer in layers)
    widths = tuple(value[0] for value in diameters)
    diameter_pairs = tuple(value[1] for value in diameters)
    diameter_vectors = tuple(value[2] for value in diameters)
    tangents = _center_tangents(centers)
    profile_spans = tuple(
        _layer_profile_span(bm, layer, tangent)
        for layer, tangent in zip(layers, tangents)
    )
    profile_span_values = tuple(value[0] for value in profile_spans)
    profile_span_pairs = tuple(value[1] for value in profile_spans)
    profile_span_vectors = tuple(value[2] for value in profile_spans)
    anchors = _track_layer_anchors(bm, layers, profile_span_pairs)
    band_normals = _layer_band_normals(bm, layers)

    sections = []
    previous_axis = None
    previous_tangent = None
    for layer_index, layer in enumerate(layers):
        tangent = tangents[layer_index]
        diameter_pair = diameter_pairs[layer_index]
        diameter_vector = diameter_vectors[layer_index]
        profile_span_pair = profile_span_pairs[layer_index]
        profile_span_vector = profile_span_vectors[layer_index]
        anchor = anchors[layer_index]
        mesh_normal, band_face_count = band_normals[layer_index]
        mesh_roll_normal = (
            _project_to_normal_plane(mesh_normal, tangent)
            if mesh_normal is not None
            else None
        )

        if len(layer) == 1:
            if layer_index == 0:
                axis = _deterministic_perpendicular(tangent)
                axis_source = "DETERMINISTIC"
                orientation_source = "DETERMINISTIC_ROOT"
            elif previous_axis is None or previous_tangent is None:
                axis = _deterministic_perpendicular(tangent)
                axis_source = "DETERMINISTIC"
                orientation_source = "TRANSPORTED_TIP"
            else:
                axis = _transport_axis(previous_axis, previous_tangent, tangent)
                axis_source = "TRANSPORTED"
                orientation_source = "TRANSPORTED_TIP"
            frame_normal = _unit_vector_or_none(tangent.cross(axis))
            kind = "POINT"
        else:
            axis = _project_to_normal_plane(profile_span_vector, tangent)
            axis_source = "PROFILE_SPAN"

            anchor_axis = (
                _project_to_normal_plane(bm.verts[anchor].co - centers[layer_index], tangent)
                if anchor is not None
                else None
            )
            if axis is None:
                axis = anchor_axis
                axis_source = "ANCHOR"
            if axis is None:
                axis = _deterministic_perpendicular(tangent)
                axis_source = "DETERMINISTIC"

            # Give the otherwise unoriented profile span a stable sign, first from
            # its tracked mesh column and then from the transported prior frame.
            if anchor_axis is not None and axis.dot(anchor_axis) < 0.0:
                axis.negate()
            if previous_axis is not None and previous_tangent is not None:
                transported = _transport_axis(previous_axis, previous_tangent, tangent)
                if axis.dot(transported) < 0.0:
                    axis.negate()

            frame_normal = _unit_vector_or_none(tangent.cross(axis))
            if frame_normal is None:
                axis = _deterministic_perpendicular(tangent)
                frame_normal = _unit_vector_or_none(tangent.cross(axis))
                axis_source = "DETERMINISTIC"

            if mesh_roll_normal is not None:
                # Preserve the source face winding when it supplies a useful
                # roll direction. The raw area-weighted normal is stored too.
                if frame_normal.dot(mesh_roll_normal) < 0.0:
                    axis.negate()
                    frame_normal.negate()
                orientation_source = "MESH_NORMAL"
            else:
                orientation_source = "PROFILE_ANCHOR"
            kind = regular_kind

        sections.append(
            {
                "kind": kind,
                "max_width_local": float(widths[layer_index]),
                "diameter_pair": list(diameter_pair) if diameter_pair is not None else None,
                "diameter_vector_local": _vector_json(diameter_vector),
                "max_profile_span_local": float(profile_span_values[layer_index]),
                "profile_span_pair": (
                    list(profile_span_pair) if profile_span_pair is not None else None
                ),
                "profile_span_vector_local": _vector_json(profile_span_vector),
                "anchor_vertex": int(anchor) if anchor is not None else None,
                "tangent_local": _vector_json(tangent),
                "width_axis_local": _vector_json(axis),
                "normal_local": _vector_json(frame_normal),
                "mesh_normal_local": _vector_json(mesh_normal),
                "band_face_count": int(band_face_count),
                "width_axis_source": axis_source,
                "orientation_source": orientation_source,
            }
        )
        previous_axis = axis.copy()
        previous_tangent = tangent.copy()

    return {
        "version": METADATA_VERSION,
        "space": METADATA_SPACE,
        "point_count": len(centers),
        "matrix_world_at_build": [
            float(source_obj.matrix_world[row][column])
            for row in range(4)
            for column in range(4)
        ],
        "sections": sections,
    }


def _reject_json_constant(value):
    raise ValueError(f"Non-finite JSON constant: {value}")


def _metadata_pair_is_valid(value):
    return (
        isinstance(value, list)
        and len(value) == 2
        and all(isinstance(index, int) and not isinstance(index, bool) and index >= 0 for index in value)
        and value[0] != value[1]
    )


def _metadata_vector_is_valid(value, *, allow_none=False, require_nonzero=False):
    if value is None:
        return allow_none
    if not isinstance(value, list) or not _vector_is_finite(value):
        return False
    if require_nonzero and not any(abs(float(component)) > EPSILON for component in value):
        return False
    return True


def _metadata_section_is_valid(section, *, is_first, is_last):
    if not isinstance(section, dict):
        return False

    kind = section.get("kind")
    if kind not in {"OPEN", "CLOSED", "POINT"} or (
        kind == "POINT" and not (is_first or is_last)
    ):
        return False
    for key in ("max_width_local", "max_profile_span_local"):
        value = section.get(key)
        if not _is_finite_number(value) or float(value) < 0.0:
            return False

    is_point = kind == "POINT"
    diameter_pair = section.get("diameter_pair")
    profile_span_pair = section.get("profile_span_pair")
    if is_point:
        if any(float(section[key]) != 0.0 for key in ("max_width_local", "max_profile_span_local")):
            return False
        expected_orientation = "DETERMINISTIC_ROOT" if is_first else "TRANSPORTED_TIP"
        if section.get("orientation_source") != expected_orientation:
            return False
        if diameter_pair is not None or profile_span_pair is not None:
            return False
        if section.get("diameter_vector_local") is not None or (
            section.get("profile_span_vector_local") is not None
        ):
            return False
        if section.get("anchor_vertex") is not None:
            return False
    else:
        if not _metadata_pair_is_valid(diameter_pair) or not _metadata_pair_is_valid(
            profile_span_pair
        ):
            return False
        if not _metadata_vector_is_valid(section.get("diameter_vector_local")) or not (
            _metadata_vector_is_valid(section.get("profile_span_vector_local"))
        ):
            return False
        anchor = section.get("anchor_vertex")
        if not isinstance(anchor, int) or isinstance(anchor, bool) or anchor < 0:
            return False

    for key in ("tangent_local", "width_axis_local", "normal_local"):
        if not _metadata_vector_is_valid(
            section.get(key),
            require_nonzero=True,
        ):
            return False
    if not _metadata_vector_is_valid(
        section.get("mesh_normal_local"),
        allow_none=True,
        require_nonzero=True,
    ):
        return False

    face_count = section.get("band_face_count")
    if not isinstance(face_count, int) or isinstance(face_count, bool) or face_count < 0:
        return False
    if section.get("width_axis_source") not in {
        "PROFILE_SPAN",
        "ANCHOR",
        "DETERMINISTIC",
        "TRANSPORTED",
    }:
        return False
    if section.get("orientation_source") not in {
        "MESH_NORMAL",
        "PROFILE_ANCHOR",
        "DETERMINISTIC_ROOT",
        "TRANSPORTED_TIP",
    }:
        return False
    return True


def _curve_cross_section_metadata(curve_obj):
    if curve_obj is None or curve_obj.type != "CURVE":
        return None
    if curve_obj.get("character_designer_metadata_version") != METADATA_VERSION:
        return None
    try:
        metadata = json.loads(
            curve_obj.get("character_designer_cross_sections", ""),
            parse_constant=_reject_json_constant,
        )
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if (
        not isinstance(metadata, dict)
        or metadata.get("version") != METADATA_VERSION
        or metadata.get("space") != METADATA_SPACE
    ):
        return None

    sections = metadata.get("sections")
    point_count = metadata.get("point_count")
    if (
        not isinstance(sections, list)
        or not isinstance(point_count, int)
        or isinstance(point_count, bool)
        or point_count < 2
        or point_count != len(sections)
    ):
        return None
    matrix = metadata.get("matrix_world_at_build")
    if (
        not isinstance(matrix, list)
        or len(matrix) != 16
        or not all(_is_finite_number(value) for value in matrix)
    ):
        return None
    if any(
        not _metadata_section_is_valid(
            section,
            is_first=index == 0,
            is_last=index == point_count - 1,
        )
        for index, section in enumerate(sections)
    ):
        return None

    splines = curve_obj.data.splines
    if len(splines) != 1 or splines[0].type != "POLY" or len(splines[0].points) != point_count:
        return None
    return metadata


def _metadata_summary(metadata):
    sections = metadata.get("sections", ()) if metadata else ()
    # A point tip correctly stores zero span, but including that zero in the
    # visible range hides the useful size range of the actual cross-sections.
    # Keep the lossless zero in JSON and summarize only non-point layers.
    profile_spans = [
        section.get("max_profile_span_local")
        for section in sections
        if section.get("kind") != "POINT"
    ]
    profile_spans = [
        float(span) for span in profile_spans if isinstance(span, (int, float))
    ]
    if not profile_spans:
        return None

    mesh_count = sum(
        section.get("orientation_source") == "MESH_NORMAL"
        for section in sections
    )
    tip_count = sum(
        section.get("orientation_source") == "TRANSPORTED_TIP"
        for section in sections
    )
    fallback_count = len(sections) - mesh_count - tip_count
    return {
        "minimum_profile_span": min(profile_spans),
        "maximum_profile_span": max(profile_spans),
        "root_profile_span": float(sections[0]["max_profile_span_local"]),
        "tip_profile_span": float(sections[-1]["max_profile_span_local"]),
        "mesh_count": mesh_count,
        "tracked_count": fallback_count,
        "tip_count": tip_count,
    }


def _compact_number(value):
    return "0" if abs(value) <= EPSILON else f"{value:.5g}"


def _visible_collections(context):
    visible_collections = set()

    def visit(layer_collection, parent_visible=True):
        visible = (
            parent_visible
            and not layer_collection.exclude
            and not layer_collection.hide_viewport
            and not layer_collection.collection.hide_viewport
            and not layer_collection.collection.hide_select
        )
        if visible:
            visible_collections.add(layer_collection.collection)
        for child in layer_collection.children:
            visit(child, visible)

    visit(context.view_layer.layer_collection)
    return visible_collections


def _visible_source_collection(context, source_obj):
    visible_collections = _visible_collections(context)
    for collection in source_obj.users_collection:
        if collection in visible_collections:
            return collection
    return context.collection or context.scene.collection


def _output_is_selectable(context, output):
    if not (
        output is not None
        and output.name in bpy.data.objects
        and output.type == "CURVE"
        and context.view_layer.objects.get(output.name) is output
        and not output.hide_viewport
        and not output.hide_select
    ):
        return False
    visible_collections = _visible_collections(context)
    return any(collection in visible_collections for collection in output.users_collection)


def _rna_pointer(value):
    try:
        return int(value.as_pointer()) if value is not None else 0
    except (AttributeError, ReferenceError, RuntimeError):
        return 0


def _signature_float(value):
    try:
        return float(value).hex()
    except (OverflowError, TypeError, ValueError):
        return repr(value)


def _ordered_edit_topology_signature(bm):
    """Compatibility name for the full current Edit-BMesh topology digest."""

    return _topology_signature(bm)


def _preview_input_signature(context, settings, *, audit_topology=True):
    """Hash mutable inputs near the selection without walking the whole topology."""

    global _LIVE_PREVIEW_TOPOLOGY_SIGNATURE
    obj, bm = _edit_bmesh(context)
    root_object = settings.root_object
    root_mesh = settings.root_mesh
    digest = hashlib.sha256()
    header = (
        _rna_pointer(obj),
        _rna_pointer(obj.data),
        _rna_pointer(root_object),
        _rna_pointer(root_mesh),
        getattr(context, "mode", ""),
        getattr(obj, "mode", ""),
        settings.root_indices_json,
        settings.root_edges_json,
        settings.root_ignored_indices_json,
        settings.root_kind,
        settings.root_capture_mode,
        settings.topology_signature,
        _LIVE_PREVIEW_DEPSGRAPH_REVISION,
    )
    digest.update(repr(header).encode("utf-8", "backslashreplace"))
    if audit_topology or not _LIVE_PREVIEW_TOPOLOGY_SIGNATURE:
        _LIVE_PREVIEW_TOPOLOGY_SIGNATURE = _ordered_edit_topology_signature(bm)
    digest.update(_LIVE_PREVIEW_TOPOLOGY_SIGNATURE.encode("ascii"))

    for row in range(4):
        for column in range(4):
            digest.update(_signature_float(obj.matrix_world[row][column]).encode("ascii"))
            digest.update(b",")

    digest.update(f"v{len(bm.verts)}e{len(bm.edges)}f{len(bm.faces)}|".encode("ascii"))
    selected_vertices = tuple(vertex for vertex in bm.verts if vertex.select)
    incident_edges = {edge for vertex in selected_vertices for edge in vertex.link_edges}
    incident_faces = {face for vertex in selected_vertices for face in vertex.link_faces}

    for vertex in selected_vertices:
        digest.update(f"v{vertex.index}".encode("ascii"))
        for component in vertex.co:
            digest.update(b":")
            digest.update(_signature_float(component).encode("ascii"))
        digest.update(b";")

    for edge in sorted(incident_edges, key=lambda value: value.index):
        first, second = sorted((edge.verts[0].index, edge.verts[1].index))
        digest.update(f"e{edge.index}:{first}:{second}:{int(bool(edge.select))};".encode("ascii"))

    for face in sorted(incident_faces, key=lambda value: value.index):
        ordered_vertices = ",".join(str(vertex.index) for vertex in face.verts)
        digest.update(
            f"f{face.index}:{int(bool(face.select))}:{ordered_vertices};".encode("ascii")
        )
    return digest.hexdigest()


def _preview_fallback_signature(context, settings, message):
    root_object = getattr(settings, "root_object", None)
    root_mesh = getattr(settings, "root_mesh", None)
    active_object = getattr(context, "object", None)
    values = (
        "INVALID",
        _rna_pointer(root_object),
        _rna_pointer(root_mesh),
        _rna_pointer(active_object),
        getattr(context, "mode", ""),
        getattr(settings, "root_indices_json", ""),
        getattr(settings, "root_edges_json", ""),
        getattr(settings, "root_ignored_indices_json", ""),
        getattr(settings, "root_kind", ""),
        str(message),
    )
    return hashlib.sha256(repr(values).encode("utf-8", "backslashreplace")).hexdigest()


def _short_preview_message(error):
    message = " ".join(str(error).split()) or "Preview unavailable."
    return message if len(message) <= 112 else f"{message[:109]}..."


def _invalidate_live_preview_batches(*, clear_shader=False):
    global _LIVE_PREVIEW_SHADER
    global _LIVE_PREVIEW_LINE_BATCH, _LIVE_PREVIEW_POINT_BATCH
    global _LIVE_PREVIEW_BATCH_REVISION, _LIVE_PREVIEW_DRAW_FAILED
    global _LIVE_PREVIEW_DRAW_RETRY_AT

    _LIVE_PREVIEW_LINE_BATCH = None
    _LIVE_PREVIEW_POINT_BATCH = None
    _LIVE_PREVIEW_BATCH_REVISION = -1
    _LIVE_PREVIEW_DRAW_FAILED = False
    _LIVE_PREVIEW_DRAW_RETRY_AT = 0.0
    if clear_shader:
        _LIVE_PREVIEW_SHADER = None


def _clear_live_preview_cache():
    global _LIVE_PREVIEW_INPUT_SIGNATURE
    global _LIVE_PREVIEW_WORLD_POINTS, _LIVE_PREVIEW_LAYERS
    global _LIVE_PREVIEW_METADATA_JSON, _LIVE_PREVIEW_SOURCE_KEY
    global _LIVE_PREVIEW_TRACKED_SOURCE_KEY
    global _LIVE_PREVIEW_DEPSGRAPH_REVISION
    global _LIVE_PREVIEW_TOPOLOGY_SIGNATURE, _LIVE_PREVIEW_TOPOLOGY_DIRTY
    global _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT
    global _LIVE_PREVIEW_TOPOLOGY_VERIFIED

    _LIVE_PREVIEW_INPUT_SIGNATURE = None
    _LIVE_PREVIEW_WORLD_POINTS = ()
    _LIVE_PREVIEW_LAYERS = ()
    _LIVE_PREVIEW_METADATA_JSON = ""
    _LIVE_PREVIEW_SOURCE_KEY = None
    _LIVE_PREVIEW_TRACKED_SOURCE_KEY = None
    _LIVE_PREVIEW_DEPSGRAPH_REVISION = 0
    _LIVE_PREVIEW_TOPOLOGY_SIGNATURE = ""
    _LIVE_PREVIEW_TOPOLOGY_DIRTY = True
    _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT = 0.0
    _LIVE_PREVIEW_TOPOLOGY_VERIFIED = False
    _invalidate_live_preview_batches(clear_shader=True)


def _reset_preview_properties(settings):
    settings.preview_valid = False
    settings.preview_confirmable = False
    settings.preview_layer_count = 0
    settings.preview_message = ""
    settings.preview_action_error = ""
    settings.preview_root_span = 0.0
    settings.preview_max_span = 0.0
    settings.preview_tip_span = 0.0
    settings.preview_orientation_valid = False


def _publish_live_preview(
    settings,
    source_obj,
    layers,
    world_points,
    *,
    metadata=None,
    confirmable,
    message,
):
    global _LIVE_PREVIEW_WORLD_POINTS, _LIVE_PREVIEW_LAYERS
    global _LIVE_PREVIEW_METADATA_JSON, _LIVE_PREVIEW_SOURCE_KEY

    immutable_layers = tuple(tuple(int(index) for index in layer) for layer in layers)
    immutable_points = tuple(
        tuple(float(component) for component in point)
        for point in world_points
    )
    metadata_json = (
        json.dumps(metadata, sort_keys=True, separators=(",", ":"), allow_nan=False)
        if metadata is not None
        else ""
    )
    summary = _metadata_summary(metadata)

    _LIVE_PREVIEW_LAYERS = immutable_layers
    _LIVE_PREVIEW_WORLD_POINTS = immutable_points
    _LIVE_PREVIEW_METADATA_JSON = metadata_json
    _LIVE_PREVIEW_SOURCE_KEY = (
        _rna_pointer(source_obj),
        _rna_pointer(source_obj.data),
    )
    _invalidate_live_preview_batches()

    settings.preview_valid = True
    settings.preview_confirmable = bool(confirmable)
    settings.preview_layer_count = len(immutable_layers)
    settings.preview_message = message
    settings.preview_action_error = ""
    settings.preview_root_span = float(summary["root_profile_span"]) if summary else 0.0
    settings.preview_max_span = float(summary["maximum_profile_span"]) if summary else 0.0
    settings.preview_tip_span = float(summary["tip_profile_span"]) if summary else 0.0
    settings.preview_orientation_valid = metadata is not None
    settings.preview_revision += 1
    _tag_view3d_redraw()


def _publish_live_preview_invalid(settings, error):
    global _LIVE_PREVIEW_WORLD_POINTS, _LIVE_PREVIEW_LAYERS
    global _LIVE_PREVIEW_METADATA_JSON, _LIVE_PREVIEW_SOURCE_KEY
    global _LIVE_PREVIEW_TOPOLOGY_VERIFIED

    if isinstance(error, TopologyChangedError):
        _LIVE_PREVIEW_TOPOLOGY_VERIFIED = False

    _LIVE_PREVIEW_WORLD_POINTS = ()
    _LIVE_PREVIEW_LAYERS = ()
    _LIVE_PREVIEW_METADATA_JSON = ""
    _LIVE_PREVIEW_SOURCE_KEY = None
    _invalidate_live_preview_batches()
    _reset_preview_properties(settings)
    settings.preview_message = _short_preview_message(error)
    settings.preview_revision += 1
    _tag_view3d_redraw()


def _world_preview_points(source_obj, centers):
    points = []
    for point_index, center in enumerate(centers):
        world = source_obj.matrix_world @ Vector(center)
        if not _vector_is_finite(world):
            raise CenterlineError(
                f"Preview point {point_index + 1} has non-finite world coordinates."
            )
        points.append((float(world.x), float(world.y), float(world.z)))
    return tuple(points)


def _update_live_preview(context, force=False, *, _timer_driven=False):
    """Recompute and atomically publish live preview data when its input changes."""

    global _LIVE_PREVIEW_INPUT_SIGNATURE, _LIVE_PREVIEW_TOPOLOGY_DIRTY
    global _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT
    global _LIVE_PREVIEW_TOPOLOGY_VERIFIED

    settings = _settings(context)
    if settings is None or not settings.preview_active:
        return False

    try:
        audit_topology = bool(
            force
            or not _timer_driven
            or not _LIVE_PREVIEW_TOPOLOGY_SIGNATURE
            or (
                _LIVE_PREVIEW_TOPOLOGY_DIRTY
                and time.monotonic() >= _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT
            )
        )
        signature = _preview_input_signature(
            context,
            settings,
            audit_topology=audit_topology,
        )
        if audit_topology:
            _LIVE_PREVIEW_TOPOLOGY_DIRTY = False
            _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT = 0.0
            if _LIVE_PREVIEW_TOPOLOGY_SIGNATURE != settings.topology_signature:
                _LIVE_PREVIEW_TOPOLOGY_VERIFIED = False
                raise TopologyChangedError("Hair topology changed after capture. Capture the root again.")
            _LIVE_PREVIEW_TOPOLOGY_VERIFIED = True
        elif not _LIVE_PREVIEW_TOPOLOGY_VERIFIED:
            # A failed full audit is a latch: a cheap local pass must not make
            # an unchanged, globally-invalid mesh look valid again. Only a later
            # successful full audit (normally after Undo) may release it.
            return False
    except Exception as exc:
        signature = _preview_fallback_signature(context, settings, exc)
        if not force and signature == _LIVE_PREVIEW_INPUT_SIGNATURE:
            return False
        _LIVE_PREVIEW_INPUT_SIGNATURE = signature
        _publish_live_preview_invalid(settings, exc)
        return True

    if not force and signature == _LIVE_PREVIEW_INPUT_SIGNATURE:
        return False
    _LIVE_PREVIEW_INPUT_SIGNATURE = signature

    try:
        validated_capture = _validate_capture(
            context,
            settings,
            check_topology=False,
        )
        source_obj, bm, root_indices, _root_edges, ignored_indices = validated_capture
        ignored_set = set(ignored_indices)
        selected = {
            vertex.index
            for vertex in bm.verts
            if vertex.select and vertex.index not in ignored_set
        }
        root_set = set(root_indices)
        missing = root_set - selected
        if missing:
            raise CenterlineError("Keep the captured root selected while growing toward the tip.")

        if selected == root_set:
            root_layer = tuple(root_indices)
            _validate_layer_coordinates(bm, (root_layer,))
            _validate_source_matrix(source_obj)
            center = sum(
                (bm.verts[index].co for index in root_layer),
                Vector((0.0, 0.0, 0.0)),
            ) / len(root_layer)
            if not _vector_is_finite(center):
                raise CenterlineError("The captured root has a non-finite center point.")
            _publish_live_preview(
                settings,
                source_obj,
                (root_layer,),
                _world_preview_points(source_obj, (center,)),
                metadata=None,
                confirmable=False,
                message="Grow the selection to continue the centerline.",
            )
            return True

        source_obj, bm, layers, centers = _extract_layers(
            context,
            settings,
            check_topology=False,
            validated_capture=validated_capture,
        )
        regular_kind = (
            _regular_kind_from_layers(bm, layers)
            if settings.root_kind == "POINT"
            else settings.root_kind
        )
        metadata = _build_cross_section_metadata(
            source_obj,
            bm,
            layers,
            centers,
            regular_kind,
        )
        _publish_live_preview(
            settings,
            source_obj,
            layers,
            _world_preview_points(source_obj, centers),
            metadata=metadata,
            confirmable=len(layers) >= 2,
            message="Live preview ready.",
        )
    except Exception as exc:
        _publish_live_preview_invalid(settings, exc)
    return True


def _draw_live_preview():
    global _LIVE_PREVIEW_SHADER
    global _LIVE_PREVIEW_LINE_BATCH, _LIVE_PREVIEW_POINT_BATCH
    global _LIVE_PREVIEW_BATCH_REVISION, _LIVE_PREVIEW_DRAW_FAILED
    global _LIVE_PREVIEW_DRAW_RETRY_AT

    if bpy.app.background or not _LIVE_PREVIEW_WORLD_POINTS:
        return
    if _LIVE_PREVIEW_DRAW_FAILED:
        if time.monotonic() < _LIVE_PREVIEW_DRAW_RETRY_AT:
            return
        # A viewport/context transition can make one draw fail transiently.
        # Retry with fresh GPU resources instead of disabling Preview forever.
        _LIVE_PREVIEW_DRAW_FAILED = False
        _LIVE_PREVIEW_SHADER = None
        _LIVE_PREVIEW_LINE_BATCH = None
        _LIVE_PREVIEW_POINT_BATCH = None
        _LIVE_PREVIEW_BATCH_REVISION = -1
    try:
        context = bpy.context
        if context.area is None or context.area.type != "VIEW_3D":
            return
        settings = _settings(context)
        if settings is None or not settings.preview_active or not settings.preview_valid:
            return
        source_obj = settings.root_object
        if (
            source_obj is None
            or _LIVE_PREVIEW_SOURCE_KEY
            != (_rna_pointer(source_obj), _rna_pointer(source_obj.data))
            or context.scene.objects.get(source_obj.name) is not source_obj
            or context.view_layer.objects.get(source_obj.name) is not source_obj
            or not source_obj.visible_get(view_layer=context.view_layer)
        ):
            return

        import gpu
        from gpu_extras.batch import batch_for_shader

        if _LIVE_PREVIEW_SHADER is None:
            _LIVE_PREVIEW_SHADER = gpu.shader.from_builtin("UNIFORM_COLOR")
        if _LIVE_PREVIEW_BATCH_REVISION != settings.preview_revision:
            _LIVE_PREVIEW_POINT_BATCH = batch_for_shader(
                _LIVE_PREVIEW_SHADER,
                "POINTS",
                {"pos": _LIVE_PREVIEW_WORLD_POINTS},
            )
            _LIVE_PREVIEW_LINE_BATCH = (
                batch_for_shader(
                    _LIVE_PREVIEW_SHADER,
                    "LINE_STRIP",
                    {"pos": _LIVE_PREVIEW_WORLD_POINTS},
                )
                if len(_LIVE_PREVIEW_WORLD_POINTS) > 1
                else None
            )
            _LIVE_PREVIEW_BATCH_REVISION = settings.preview_revision

        previous_depth = gpu.state.depth_test_get()
        previous_depth_mask = gpu.state.depth_mask_get()
        previous_blend = gpu.state.blend_get()
        previous_line_width = gpu.state.line_width_get()
        try:
            gpu.state.depth_test_set("NONE")
            gpu.state.depth_mask_set(False)
            gpu.state.blend_set("ALPHA")
            gpu.state.line_width_set(3.0)
            gpu.state.point_size_set(7.0)
            _LIVE_PREVIEW_SHADER.bind()
            _LIVE_PREVIEW_SHADER.uniform_float("color", LIVE_PREVIEW_COLOR)
            if _LIVE_PREVIEW_LINE_BATCH is not None:
                _LIVE_PREVIEW_LINE_BATCH.draw(_LIVE_PREVIEW_SHADER)
            if _LIVE_PREVIEW_POINT_BATCH is not None:
                _LIVE_PREVIEW_POINT_BATCH.draw(_LIVE_PREVIEW_SHADER)
        finally:
            for restore, value in (
                (gpu.state.point_size_set, 1.0),
                (gpu.state.line_width_set, previous_line_width),
                (gpu.state.blend_set, previous_blend),
                (gpu.state.depth_mask_set, previous_depth_mask),
                (gpu.state.depth_test_set, previous_depth),
            ):
                try:
                    restore(value)
                except Exception:
                    pass
    except Exception:
        _LIVE_PREVIEW_DRAW_FAILED = True
        _LIVE_PREVIEW_DRAW_RETRY_AT = time.monotonic() + 1.0
        _LIVE_PREVIEW_LINE_BATCH = None
        _LIVE_PREVIEW_POINT_BATCH = None


def _remove_live_preview_draw_handler():
    global _LIVE_PREVIEW_DRAW_HANDLE

    handle = _LIVE_PREVIEW_DRAW_HANDLE
    _LIVE_PREVIEW_DRAW_HANDLE = None
    if handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
        except Exception:
            pass


def _live_preview_load_pre(_unused):
    # Do not mutate Blender's load_pre list while it is iterating callbacks;
    # removing this entry here can skip the next add-on's handler. Non-persistent
    # handlers are discarded by Blender as the new file loads.
    _stop_live_preview(
        settings=None,
        clear_capture=True,
        remove_load_handler=False,
    )


def _live_preview_depsgraph_update(_scene, depsgraph):
    """Mark non-selection scene/data edits for validation on the next tick."""

    global _LIVE_PREVIEW_DEPSGRAPH_REVISION, _LIVE_PREVIEW_TOPOLOGY_DIRTY
    global _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT
    if _LIVE_PREVIEW_TRACKED_SOURCE_KEY is None:
        return
    try:
        matched = False
        mesh_geometry_changed = False
        for update in depsgraph.updates:
            updated_id = getattr(update.id, "original", update.id)
            updated_pointer = _rna_pointer(updated_id)
            if updated_pointer not in _LIVE_PREVIEW_TRACKED_SOURCE_KEY:
                continue
            matched = True
            if (
                updated_pointer == _LIVE_PREVIEW_TRACKED_SOURCE_KEY[1]
                and getattr(update, "is_updated_geometry", False)
            ):
                mesh_geometry_changed = True
        if matched:
            _LIVE_PREVIEW_DEPSGRAPH_REVISION += 1
        if mesh_geometry_changed:
            # Blender reports both coordinate transforms and connectivity edits as
            # Mesh geometry updates. Keep the 0.1 s coordinate/selection preview
            # fast, then perform one full topology audit after interaction settles.
            _LIVE_PREVIEW_TOPOLOGY_DIRTY = True
            _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT = (
                time.monotonic() + LIVE_PREVIEW_TOPOLOGY_DEBOUNCE
            )
    except Exception:
        # If Blender invalidates an update wrapper during Undo/Redo, force one
        # conservative revalidation rather than risking a stale preview.
        _LIVE_PREVIEW_DEPSGRAPH_REVISION += 1
        _LIVE_PREVIEW_TOPOLOGY_DIRTY = True
        _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT = time.monotonic()


def _live_preview_history_post(_unused):
    """Force immediate revalidation after Undo/Redo, even if depsgraph coalesces updates."""

    global _LIVE_PREVIEW_DEPSGRAPH_REVISION, _LIVE_PREVIEW_TOPOLOGY_DIRTY
    global _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT
    settings = _settings(bpy.context)
    if (
        settings is None
        or not settings.preview_active
        or _LIVE_PREVIEW_TRACKED_SOURCE_KEY is None
    ):
        return
    _LIVE_PREVIEW_DEPSGRAPH_REVISION += 1
    _LIVE_PREVIEW_TOPOLOGY_DIRTY = True
    _LIVE_PREVIEW_TOPOLOGY_AUDIT_AT = time.monotonic()


def _ensure_live_preview_runtime():
    global _LIVE_PREVIEW_DRAW_HANDLE, _LIVE_PREVIEW_DRAW_FAILED
    global _LIVE_PREVIEW_TRACKED_SOURCE_KEY

    _LIVE_PREVIEW_DRAW_FAILED = False
    settings = _settings(bpy.context)
    if settings is not None and settings.root_object is not None and settings.root_mesh is not None:
        _LIVE_PREVIEW_TRACKED_SOURCE_KEY = (
            _rna_pointer(settings.root_object),
            _rna_pointer(settings.root_mesh),
        )
    if not bpy.app.timers.is_registered(_live_preview_tick):
        bpy.app.timers.register(
            _live_preview_tick,
            first_interval=LIVE_PREVIEW_INTERVAL,
            persistent=False,
        )
    if _LIVE_PREVIEW_DRAW_HANDLE is None:
        _LIVE_PREVIEW_DRAW_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
            _draw_live_preview,
            (),
            "WINDOW",
            "POST_VIEW",
        )
    if _live_preview_load_pre not in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.append(_live_preview_load_pre)
    if _live_preview_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_live_preview_depsgraph_update)
    for handlers in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _live_preview_history_post not in handlers:
            handlers.append(_live_preview_history_post)


def _live_preview_tick():
    settings = _settings(bpy.context)
    if settings is None or not settings.preview_active:
        _remove_live_preview_draw_handler()
        try:
            if _live_preview_load_pre in bpy.app.handlers.load_pre:
                bpy.app.handlers.load_pre.remove(_live_preview_load_pre)
        except Exception:
            pass
        try:
            if _live_preview_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
                bpy.app.handlers.depsgraph_update_post.remove(_live_preview_depsgraph_update)
        except Exception:
            pass
        for handlers in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
            try:
                if _live_preview_history_post in handlers:
                    handlers.remove(_live_preview_history_post)
            except Exception:
                pass
        _clear_live_preview_cache()
        return None
    try:
        _update_live_preview(bpy.context, force=False, _timer_driven=True)
    except Exception as exc:
        _publish_live_preview_invalid(settings, exc)
    if _LIVE_PREVIEW_DRAW_FAILED and time.monotonic() >= _LIVE_PREVIEW_DRAW_RETRY_AT:
        _tag_view3d_redraw()
    return LIVE_PREVIEW_INTERVAL if settings.preview_active else None


def _stop_live_preview(settings=None, clear_capture=True, remove_load_handler=True):
    if settings is None:
        settings = _settings(bpy.context)
    if settings is not None:
        try:
            settings.preview_active = False
        except (AttributeError, ReferenceError):
            settings = None

    try:
        if bpy.app.timers.is_registered(_live_preview_tick):
            bpy.app.timers.unregister(_live_preview_tick)
    except Exception:
        pass
    _remove_live_preview_draw_handler()
    if remove_load_handler:
        try:
            if _live_preview_load_pre in bpy.app.handlers.load_pre:
                bpy.app.handlers.load_pre.remove(_live_preview_load_pre)
        except Exception:
            pass
    try:
        if _live_preview_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(_live_preview_depsgraph_update)
    except Exception:
        pass
    for handlers in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        try:
            if _live_preview_history_post in handlers:
                handlers.remove(_live_preview_history_post)
        except Exception:
            pass
    _clear_live_preview_cache()

    if settings is not None:
        _reset_preview_properties(settings)
        if clear_capture:
            _clear_capture(settings)
    _tag_view3d_redraw()


def _create_centerline_object(context, source_obj, layers, centers, metadata=None):
    curve_data = None
    curve_obj = None
    try:
        curve_data = bpy.data.curves.new(f"{source_obj.name}_Centerline", type="CURVE")
        curve_data.dimensions = "3D"
        curve_data.resolution_u = 1
        curve_data.render_resolution_u = 1
        curve_data.bevel_depth = 0.0
        curve_data.extrude = 0.0
        curve_data.taper_object = None

        spline = curve_data.splines.new(type="POLY")
        spline.points.add(len(centers) - 1)
        for point, center in zip(spline.points, centers):
            point.co = (*center, 1.0)
        spline.use_cyclic_u = False

        curve_obj = bpy.data.objects.new(f"{source_obj.name}_Centerline", curve_data)
        _visible_source_collection(context, source_obj).objects.link(curve_obj)
        curve_obj.matrix_world = source_obj.matrix_world.copy()
        curve_obj.show_in_front = True
        curve_obj["character_designer_generator"] = GENERATOR_ID
        curve_obj["character_designer_source"] = source_obj.name
        curve_obj["character_designer_layer_vertices"] = json.dumps(layers, separators=(",", ":"))
        if metadata is not None:
            if metadata.get("point_count") != len(centers):
                raise ValueError("Cross-section metadata does not match the Curve point count.")
            curve_obj["character_designer_metadata_version"] = METADATA_VERSION
            curve_obj["character_designer_cross_sections"] = json.dumps(
                metadata,
                separators=(",", ":"),
                allow_nan=False,
            )
        return curve_obj
    except Exception:
        if curve_obj is not None and curve_obj.name in bpy.data.objects:
            bpy.data.objects.remove(curve_obj, do_unlink=True)
        if curve_data is not None and curve_data.name in bpy.data.curves:
            bpy.data.curves.remove(curve_data)
        raise


def _remove_created_curve(curve_obj):
    if curve_obj is None or curve_obj.name not in bpy.data.objects:
        return
    curve_data = curve_obj.data if curve_obj.type == "CURVE" else None
    bpy.data.objects.remove(curve_obj, do_unlink=True)
    if curve_data is not None and curve_data.users == 0:
        bpy.data.curves.remove(curve_data)


def _store_root_capture(
    settings,
    obj,
    bm,
    root_indices,
    root_edge_keys,
    kind,
    ignored_indices,
    capture_mode,
    *,
    clear_output,
):
    settings.root_object = obj
    settings.root_mesh = obj.data
    settings.root_indices_json = json.dumps(root_indices, separators=(",", ":"))
    settings.root_edges_json = json.dumps(root_edge_keys, separators=(",", ":"))
    settings.root_ignored_indices_json = json.dumps(
        ignored_indices,
        separators=(",", ":"),
    )
    settings.root_kind = kind
    settings.root_capture_mode = capture_mode
    settings.root_vertex_count = len(root_indices)
    settings.root_ignored_count = len(ignored_indices)
    settings.topology_signature = _topology_signature(bm)
    if clear_output:
        settings.output_object = None


def _capture_status_message(root_indices, ignored_indices, kind, capture_mode):
    if capture_mode in {"FAN_CAP", "TRI_CAP", "REGION_CAP"}:
        return (
            f"Captured cap boundary with {len(root_indices)} vertices; "
            f"ignored {len(ignored_indices)} interior "
            f"{'vertex' if len(ignored_indices) == 1 else 'vertices'}."
        )
    return f"Captured {_root_label(kind)} with {len(root_indices)} vertices."


class CHARACTERDESIGNER_OT_preview_selected_root(Operator):
    bl_idname = "character_designer.preview_selected_root"
    bl_label = "Preview Selected Root"
    bl_description = "Capture the selected root and preview its centerline as the selection changes"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.edit_object is not None and context.edit_object.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({"ERROR"}, "Character Designer is not registered correctly.")
            return {"CANCELLED"}

        _stop_live_preview(settings, clear_capture=True)
        try:
            (
                obj,
                bm,
                root_indices,
                root_edge_keys,
                kind,
                ignored_indices,
                capture_mode,
            ) = _capture_data(context)
            _store_root_capture(
                settings,
                obj,
                bm,
                root_indices,
                root_edge_keys,
                kind,
                ignored_indices,
                capture_mode,
                clear_output=False,
            )
            _reset_preview_properties(settings)
            settings.preview_active = True
            _ensure_live_preview_runtime()
            _update_live_preview(context, force=True)
        except CenterlineError as exc:
            _stop_live_preview(settings, clear_capture=True)
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            _stop_live_preview(settings, clear_capture=True)
            message = f"Live preview could not start: {_short_preview_message(exc)}"
            _set_status(settings, "ERROR", message)
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        message = _capture_status_message(root_indices, ignored_indices, kind, capture_mode)
        _set_status(settings, "SUCCESS", message)
        self.report({"INFO"}, message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_cancel_preview(Operator):
    bl_idname = "character_designer.cancel_preview"
    bl_label = "Cancel Preview"
    bl_description = "Stop the live preview without deleting any previously created curve"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        settings = _settings(context)
        _stop_live_preview(settings, clear_capture=True)
        if settings is not None:
            _set_status(settings, "INFO", "Live preview cancelled.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_capture_root(Operator):
    bl_idname = "character_designer.capture_root_slice"
    bl_label = "Capture Selected Root"
    bl_description = "Capture one selected edge row/loop or the boundary of a selected cap region"
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.edit_object is not None and context.edit_object.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({"ERROR"}, "Character Designer is not registered correctly.")
            return {"CANCELLED"}
        if settings.preview_active:
            _stop_live_preview(settings, clear_capture=True)
        try:
            (
                obj,
                bm,
                root_indices,
                root_edge_keys,
                kind,
                ignored_indices,
                capture_mode,
            ) = _capture_data(context)
            _store_root_capture(
                settings,
                obj,
                bm,
                root_indices,
                root_edge_keys,
                kind,
                ignored_indices,
                capture_mode,
                clear_output=True,
            )
            _set_status(
                settings,
                "SUCCESS",
                _capture_status_message(root_indices, ignored_indices, kind, capture_mode),
            )
        except CenterlineError as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, settings.last_message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_clear_root(Operator):
    bl_idname = "character_designer.clear_root_slice"
    bl_label = "Clear Captured Root"
    bl_description = "Forget the captured root slice"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        settings = _settings(context)
        if settings is not None:
            _stop_live_preview(settings, clear_capture=True)
            _set_status(settings, "INFO", "Root capture cleared.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_build_centerline(Operator):
    bl_idname = "character_designer.build_centerline"
    bl_label = "Build Center Curve"
    bl_description = "Create one exact Poly curve point at the arithmetic mean of every selected slice"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.edit_object is not None and context.edit_object.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({"ERROR"}, "Character Designer is not registered correctly.")
            return {"CANCELLED"}

        created = None
        try:
            source_obj, _bm, layers, centers = _extract_layers(context, settings)
            regular_kind = (
                _regular_kind_from_layers(_bm, layers)
                if settings.root_kind == "POINT"
                else settings.root_kind
            )
            metadata = _build_cross_section_metadata(
                source_obj,
                _bm,
                layers,
                centers,
                regular_kind,
            )
            created = _create_centerline_object(
                context,
                source_obj,
                layers,
                centers,
                metadata,
            )
            settings.output_object = created
            summary = _metadata_summary(metadata)
            _set_status(
                settings,
                "SUCCESS",
                (
                    f"Built {created.name}: {len(centers)} points; local profile span "
                    f"{_compact_number(summary['minimum_profile_span'])}-"
                    f"{_compact_number(summary['maximum_profile_span'])} BU."
                ),
            )
        except CenterlineError as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            _remove_created_curve(created)
            if settings.output_object is created:
                settings.output_object = None
            message = f"Center curve failed: {exc}"
            _set_status(settings, "ERROR", message)
            self.report({"ERROR"}, message)
            traceback.print_exc()
            return {"CANCELLED"}

        self.report({"INFO"}, settings.last_message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_confirm_centerline(Operator):
    bl_idname = "character_designer.confirm_centerline"
    bl_label = "Confirm Centerline"
    bl_description = "Revalidate the current mesh selection and create the exact center curve"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        return bool(
            settings is not None
            and settings.preview_active
            and settings.preview_confirmable
            and context.edit_object is settings.root_object
        )

    def execute(self, context):
        settings = _settings(context)
        if settings is None or not settings.preview_active:
            self.report({"ERROR"}, "Start a live preview first.")
            return {"CANCELLED"}
        if not settings.preview_confirmable:
            self.report({"ERROR"}, "Grow a valid selection before confirming the centerline.")
            return {"CANCELLED"}

        created = None
        try:
            source_obj, bm, layers, centers = _extract_layers(context, settings)
            regular_kind = (
                _regular_kind_from_layers(bm, layers)
                if settings.root_kind == "POINT"
                else settings.root_kind
            )
            metadata = _build_cross_section_metadata(
                source_obj,
                bm,
                layers,
                centers,
                regular_kind,
            )
            created = _create_centerline_object(
                context,
                source_obj,
                layers,
                centers,
                metadata,
            )
        except CenterlineError as exc:
            _publish_live_preview_invalid(settings, exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            _remove_created_curve(created)
            message = f"Could not create Curve: {_short_preview_message(exc)}"
            settings.preview_action_error = message
            _tag_view3d_redraw()
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        settings.output_object = created
        success_message = f"Created {created.name} · {len(centers)} points."
        _stop_live_preview(settings, clear_capture=True)
        _set_status(settings, "SUCCESS", success_message)
        self.report({"INFO"}, success_message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_select_output(Operator):
    bl_idname = "character_designer.select_output"
    bl_label = "Select Output"
    bl_description = "Leave mesh Edit Mode and select the last generated center curve"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        obj = getattr(settings, "output_object", None) if settings else None
        return _output_is_selectable(context, obj)

    def execute(self, context):
        settings = _settings(context)
        output = settings.output_object
        if not _output_is_selectable(context, output):
            self.report({"WARNING"}, "The output curve is not visible/selectable in this View Layer.")
            return {"CANCELLED"}
        output.hide_set(False)
        if not output.visible_get(view_layer=context.view_layer):
            self.report({"WARNING"}, "The output curve is hidden by its collection or View Layer.")
            return {"CANCELLED"}
        if context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.select_all(action="DESELECT")
        output.hide_set(False)
        output.select_set(True)
        context.view_layer.objects.active = output
        if not output.select_get(view_layer=context.view_layer):
            self.report({"ERROR"}, "Blender could not select the output curve.")
            return {"CANCELLED"}
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_refresh_addon(Operator):
    bl_idname = "character_designer.refresh_addon"
    bl_label = "Refresh Add-on"
    bl_description = "Validate and reload Character Designer after its Python files change"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, _context):
        return not ADDON_REFRESH_PENDING

    def execute(self, _context):
        global ADDON_REFRESH_PENDING, ADDON_REFRESH_LAST_ERROR, ADDON_REFRESH_LAST_STATE

        if not _source_changed():
            ADDON_REFRESH_LAST_STATE = False
            if not bpy.app.timers.is_registered(_source_watch_deferred):
                if not _register_source_watch():
                    self.report({"ERROR"}, ADDON_REFRESH_LAST_ERROR)
                    return {"CANCELLED"}
            ADDON_REFRESH_LAST_ERROR = ""
            _tag_view3d_redraw()
            self.report({"INFO"}, "Character Designer is already current.")
            return {"CANCELLED"}
        try:
            _validate_source_files()
        except Exception as exc:
            ADDON_REFRESH_LAST_ERROR = str(exc)
            self.report({"ERROR"}, f"Refresh blocked by a Python error: {exc}")
            return {"CANCELLED"}

        _stop_live_preview(settings=_settings(bpy.context), clear_capture=True)
        ADDON_REFRESH_PENDING = True
        ADDON_REFRESH_LAST_ERROR = ""
        try:
            if not bpy.app.timers.is_registered(_reload_addon_deferred):
                bpy.app.timers.register(_reload_addon_deferred, first_interval=0.1)
        except Exception as exc:
            ADDON_REFRESH_PENDING = False
            ADDON_REFRESH_LAST_ERROR = str(exc)
            self.report({"ERROR"}, f"Could not schedule refresh: {exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, "Refreshing Character Designer...")
        return {"FINISHED"}


def _draw_message(layout, level, message):
    if not message:
        return
    icon = {"ERROR": "ERROR", "SUCCESS": "CHECKMARK", "INFO": "INFO"}.get(level, "INFO")
    lines = textwrap.wrap(
        message,
        width=52,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [message]
    for index, line in enumerate(lines):
        row = layout.row()
        row.alert = level == "ERROR"
        if index == 0:
            row.label(text=line, icon=icon)
        else:
            row.label(text=line)


class CHARACTERDESIGNER_PT_main(Panel):
    bl_label = "Character Designer"
    bl_idname = "CHARACTERDESIGNER_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Character"

    def draw(self, context):
        layout = self.layout
        settings = _settings(context)
        if settings is None:
            layout.label(text="Add-on state unavailable", icon="ERROR")
            return

        layout.label(text="Hair Centerline", icon="CURVE_DATA")

        if settings.preview_active:
            if settings.preview_valid:
                layout.label(text="Live Preview", icon="HIDE_OFF")
                layout.label(
                    text=(
                        f"{settings.preview_layer_count} "
                        f"{'layer' if settings.preview_layer_count == 1 else 'layers'} "
                        f"→ {settings.preview_layer_count} "
                        f"{'point' if settings.preview_layer_count == 1 else 'points'}"
                    ),
                    icon="CURVE_PATH",
                )
                if settings.preview_confirmable:
                    layout.label(
                        text=(
                            f"Span: Start {_compact_number(settings.preview_root_span)} · "
                            f"Max {_compact_number(settings.preview_max_span)} · "
                            f"End {_compact_number(settings.preview_tip_span)} BU"
                        ),
                        icon="DRIVER_DISTANCE",
                    )
                    if settings.preview_orientation_valid:
                        layout.label(text="Orientation ✓", icon="CHECKMARK")
                    if settings.preview_action_error:
                        _draw_message(layout, "ERROR", settings.preview_action_error)
                else:
                    layout.label(text=settings.preview_message, icon="INFO")
            else:
                layout.label(text="Preview Invalid", icon="ERROR")
                _draw_message(
                    layout,
                    "ERROR",
                    settings.preview_message or "Preview unavailable.",
                )

            action_row = layout.row(align=True)
            confirm_row = action_row.row(align=True)
            confirm_row.enabled = bool(
                settings.preview_valid and settings.preview_confirmable
            )
            confirm_row.operator(
                "character_designer.confirm_centerline",
                text="Confirm Centerline",
                icon="CHECKMARK",
            )
            action_row.operator(
                "character_designer.cancel_preview",
                text="",
                icon="X",
            )
        else:
            can_preview = False
            idle_hint = ""
            if context.edit_object is None or context.edit_object.type != "MESH":
                idle_hint = "Enter Mesh Edit Mode to begin."
            else:
                try:
                    _obj, _bm = _edit_bmesh(context)
                    # Mesh.total_vert_sel is maintained by Blender and avoids an
                    # O(vertex-count) BMesh scan on every viewport redraw.
                    can_preview = _obj.data.total_vert_sel > 0
                    if not can_preview:
                        idle_hint = "Select a root point, row, loop, or cap."
                except CenterlineError:
                    idle_hint = "Enter Mesh Edit Mode to begin."

            preview_row = layout.row()
            preview_row.enabled = can_preview
            preview_row.operator(
                "character_designer.preview_selected_root",
                text="Preview Selected Root",
                icon="PLAY",
            )

            if idle_hint:
                layout.label(text=idle_hint, icon="INFO")

            output = settings.output_object
            if output is not None and output.name in bpy.data.objects:
                # The created object is already validated at build time; the
                # sidebar only needs a cheap count, not a full metadata parse.
                point_count = sum(
                    len(spline.points)
                    if spline.type == "POLY"
                    else len(spline.bezier_points)
                    for spline in output.data.splines
                )
                output_row = layout.row(align=True)
                output_row.label(text=f"Last Curve · {point_count} points", icon="CHECKMARK")
                output_row.operator(
                    "character_designer.select_output",
                    text="Select Curve",
                    icon="RESTRICT_SELECT_OFF",
                )

            if settings.last_level == "ERROR":
                _draw_message(layout, "ERROR", settings.last_message)

        if _refresh_ui_visible():
            layout.separator()
            refresh_row = layout.row(align=True)
            if ADDON_REFRESH_LAST_ERROR:
                refresh_row.alert = True
                refresh_row.label(text="Refresh failed", icon="ERROR")
                refresh_row.operator(
                    "character_designer.refresh_addon",
                    text="Retry",
                    icon="FILE_REFRESH",
                )
                _draw_message(layout, "ERROR", ADDON_REFRESH_LAST_ERROR)
            elif ADDON_REFRESH_PENDING:
                refresh_row.enabled = False
                refresh_row.label(text="Refreshing add-on...", icon="FILE_REFRESH")
            else:
                refresh_row.label(text="Source changed", icon="INFO")
                refresh_row.operator(
                    "character_designer.refresh_addon",
                    text="Refresh Add-on",
                    icon="FILE_REFRESH",
                )


CLASSES = (
    CharacterDesignerState,
    CHARACTERDESIGNER_OT_preview_selected_root,
    CHARACTERDESIGNER_OT_cancel_preview,
    CHARACTERDESIGNER_OT_capture_root,
    CHARACTERDESIGNER_OT_clear_root,
    CHARACTERDESIGNER_OT_build_centerline,
    CHARACTERDESIGNER_OT_confirm_centerline,
    CHARACTERDESIGNER_OT_select_output,
    CHARACTERDESIGNER_OT_refresh_addon,
    CHARACTERDESIGNER_PT_main,
)


def register():
    if hasattr(bpy.types.WindowManager, "character_designer"):
        _register_source_watch()
        return

    registered = []
    property_added = False
    try:
        for cls in CLASSES:
            bpy.utils.register_class(cls)
            registered.append(cls)
        bpy.types.WindowManager.character_designer = PointerProperty(
            type=CharacterDesignerState,
            options={"SKIP_SAVE"},
        )
        property_added = True
        _register_source_watch()
    except Exception:
        _stop_live_preview(settings=_settings(bpy.context), clear_capture=True)
        _unregister_source_watch()
        if property_added and hasattr(bpy.types.WindowManager, "character_designer"):
            del bpy.types.WindowManager.character_designer
        for cls in reversed(registered):
            try:
                bpy.utils.unregister_class(cls)
            except RuntimeError:
                pass
        raise


def unregister():
    _stop_live_preview(settings=_settings(bpy.context), clear_capture=True)
    _unregister_source_watch()
    if hasattr(bpy.types.WindowManager, "character_designer"):
        del bpy.types.WindowManager.character_designer
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
