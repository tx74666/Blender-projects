# Character Designer 0.6.0

Character Designer is Randy's personal Blender add-on. It stays separate from
RR Helper and focuses on character-modeling tools.

## Generic Reference View Sets

The **Reference Views** panel creates spatial image references for any subject:
a prop, vehicle, building, room, creature, or character. It does not assume a
human height or anatomy. Codex Console (or another tool) writes a set beneath
`//References/CDesigner/<set>/reference-views.json`; **Scan Standard Folder**
finds those manifests and **Create / Update Views** synchronizes the selected
set.

The version-1 contract is:

```json
{
  "schema": "blackunity.cdesigner.reference-view-set",
  "version": 1,
  "setId": "2ed7799e-5b80-41da-a8cf-502aa32d09db",
  "name": "Any Subject",
  "updatedAt": "2026-08-04T08:00:00Z",
  "units": "METERS",
  "placement": {
    "origin": [0.0, 0.0, 0.0],
    "displaySizeMeters": 2.0,
    "distanceMeters": 10.0,
    "opacity": 0.35,
    "showInFront": true
  },
  "views": {
    "front": {
      "file": "front.png",
      "enabled": true,
      "flipHorizontal": false,
      "flipVertical": false,
      "distanceMeters": null,
      "displaySizeMeters": null,
      "opacity": null
    }
  }
}
```

`null` per-view values inherit `placement`. Image paths use drive-free POSIX
relative syntax and are rejected for backslashes, `.`/`..` components, or any
real-path escape from the manifest folder. Unknown fields are ignored
for forward-compatible producers, while schema, version, UUID, units, numeric
ranges, booleans, and enabled image files are validated before the Scene is
changed. Meter values are divided by `Scene.unit_settings.scale_length` to get
Blender Units.

Project-local loaded Images are stored with Blender `//` paths so moving the
saved `.blend` together with its `References` directory keeps links portable;
images outside the `.blend` directory retain absolute paths.

An unused direction may be omitted or use `"file": null`. A null file is always
an unconfigured slot—even if an older producer accidentally leaves
`"enabled": true`—so a partial Front-only set remains usable. When a previously
created direction becomes empty or disabled, synchronization hides its managed
Empty but does not delete it; only **Clear Current Set** performs deletion.

Each Scene receives one tagged `C Designer References` collection. Every set
has a tagged root Empty and up to six tagged Image Empties. The image planes are
single-sided toward the subject so opposite views do not overlap; all remain
non-rendering. Synchronization leaves Edit Mode, the active object, and the
selection untouched. A failure rolls back new data and restores already managed
objects. **Clear Current Set** never claims same-named user data and retains a
managed object if another Scene or an unowned child depends on it.
Synchronization and visibility changes are refused before mutation when their
managed collection or objects are shared by multiple Scenes, preventing one
Scene's operation from silently changing another Scene.
Standard-folder discovery also refuses symlink, Junction, and other Windows
reparse-point directories, and rechecks every traversed directory and manifest
against the real `//References/CDesigner` boundary.

The WindowManager controls are intentionally session-only, but managed Scene
objects are persistent. On reopen, **Managed Scene Sets** reconstructs available
sets from exact current-version tags. A single set is adopted automatically;
multiple sets require an explicit UUID-backed dropdown choice before Show,
Hide, or Clear becomes available. This recovery does not require the original
manifest to still exist.

## Live Hair Centerline Preview

Character Designer turns the cross-sections of a hair mesh into an exact,
plain center curve.

1. Turn on **Live Preview**. It may be enabled before or after entering Mesh
   Edit Mode.
2. Select the complete connected part of the hair that should define the
   centerline. Every regular cross-section becomes one preview point and a
   collapsed endpoint vertex becomes one final point.
3. Grow, shrink, or replace the selection as needed; Preview follows it live.
4. Click **Confirm Centerline** to re-read the current selection and create the
   Curve. Turning Live Preview off simply clears the preview.

Leaving Edit Mode pauses Preview without turning the toggle off. Returning to
Edit Mode resumes it from the current selection. A single selected row, loop,
or point displays one preview point, while confirmation becomes available with
two or more validated cross-sections.

Open rows, closed profile loops, and a collapsed `POINT` tip are supported. The
selection parser is independent of Blender's vertex/edge/face selection mode.
For example, four selected triangular profile loops plus one pointed tip are
read as `3 → 3 → 3 → 3 → 1` and create five center points; selected side faces
are never mistaken for one large root cap.

Each valid topological layer contributes one preview point at the arithmetic
mean of that layer's current vertices. The points stay in source-object local
space and the source transform is copied to the confirmed Curve, preserving
the original placement and local precision.

The confirmed Curve remains deliberately plain. It has no bevel profile,
generated thickness, material, or automatic shaping; point Radius and Tilt
remain at Blender's defaults. Preview and confirmation do not modify the source
mesh or its selection.

## Source Metadata

The confirmed Curve keeps lossless, versioned source metadata for later profile
work. For every layer it records:

- the raw maximum vertex-to-vertex chord and the vertex pair that defines it;
- the maximum profile span used as the cross-section sizing reference;
- the local center, tangent, width axis, normal, and orientation source.

The metadata is stored in `SOURCE_OBJECT_LOCAL` space together with the source
matrix at confirmation time. It does not change the visible Curve. Later tools
can derive Radius, Tilt, or a profile without guessing or overwriting the raw
measurements.

The live panel keeps the working information in front: current layer-to-point
count, start/maximum/end profile span, pause state, and short errors.
Detailed per-layer measurements remain on the confirmed Curve.

## Refresh Add-on

Character Designer watches its installed Python files. **Refresh Add-on** is
hidden while the loaded code matches disk and appears only when the source has
changed, a refresh is running, or an error needs attention. Refresh validates
the Python files before reloading the add-on. It does not save or reload the
current `.blend`; session-only preview and output state is reset.
