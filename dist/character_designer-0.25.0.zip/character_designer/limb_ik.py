"""One-click, owner-scoped Arm/Leg IK controls for humanoid deform skeletons.

The module deliberately keeps analysis read-only (WindowManager state only) and
keeps generated controls inside the source Armature.  Constraint ownership is
recorded on PoseBones because Blender constraints do not support ID properties.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import textwrap
import uuid
from dataclasses import dataclass

import bpy
from bpy.props import EnumProperty, FloatProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Matrix, Vector

from .ui_constants import SIDEBAR_CATEGORY, UI_PAGE_RIG, active_ui_page


OWNER_KEY = "character_designer_owner"
OWNER_VALUE = "limb_ik"
VERSION_KEY = "character_designer_limb_ik_version"
RIG_ID_KEY = "character_designer_limb_ik_rig_id"
ROLE_KEY = "character_designer_limb_ik_role"
KIND_KEY = "character_designer_limb_ik_kind"
SIDE_KEY = "character_designer_limb_ik_side"
CHAIN_KEY = "character_designer_limb_ik_chain"
ARMATURE_ID_KEY = "character_designer_limb_ik_armature_id"
CONSTRAINT_REGISTRY_KEY = "character_designer_limb_ik_constraints"
RIG_VERSION = 1
CONTROL_COLLECTION_NAME = "Randy Controls"
WIDGET_COLLECTION_NAME = "Randy_Rig_Widgets"
POLE_STRAIGHT_RATIO = 0.02
EPSILON = 1.0e-8

SIDES = ("L", "R")
KINDS = ("ARM", "LEG")
ROLES = ("upper", "lower", "end")

LIMB_SPEC = {
    "ARM": {
        "upper": (("upperarm", 8), ("arm", 5)),
        "lower": (("forearm", 8), ("lowerarm", 8)),
        "end": (("hand", 8), ("wrist", 7)),
        "target": "CTRL_hand_IK.{side}",
        "pole": "CTRL_elbow_pole.{side}",
        "target_role": "HAND_IK",
    },
    "LEG": {
        "upper": (("thigh", 8), ("upperleg", 8)),
        "lower": (("shin", 8), ("calf", 8), ("lowerleg", 8)),
        "end": (("foot", 8), ("ankle", 7)),
        "target": "CTRL_foot_IK.{side}",
        "pole": "CTRL_knee_pole.{side}",
        "target_role": "FOOT_IK",
    },
}

_EXCLUDED_TOKENS = frozenset(
    {"mch", "org", "ctrl", "vis", "wgt", "ik", "fk", "twist", "helper", "corrective", "tweak"}
)


class LimbIKError(ValueError):
    """An actionable, fail-closed limb-rig problem."""


@dataclass(frozen=True)
class LimbChain:
    kind: str
    side: str
    upper: str
    lower: str
    end: str
    score: float = 0.0
    warning: str = ""

    @property
    def names(self):
        return (self.upper, self.lower, self.end)


@dataclass
class LimbPlan:
    chain: LimbChain
    rig_id: str
    target_name: str
    pole_name: str
    start: Vector
    joint: Vector
    end: Vector
    target_head: Vector
    target_tail: Vector
    target_z: Vector
    pole_head: Vector
    pole_tail: Vector
    pole_angle: float
    pole_warning: str
    desired_upper_matrix: Matrix
    desired_lower_matrix: Matrix
    desired_end_matrix: Matrix
    target_basis: Matrix
    pole_basis: Matrix


def _armature_poll(_self, obj):
    return obj is not None and obj.type == "ARMATURE"


def _settings(context):
    return getattr(getattr(context, "window_manager", None), "character_designer_limb_ik", None)


def _set_status(settings, level, message):
    if settings is not None:
        settings.last_level = level
        settings.last_message = message


def _field_name(kind, side, role):
    return f"{'left' if side == 'L' else 'right'}_{kind.lower()}_{role}"


def _canonical_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _armature_digest(armature):
    payload = []
    for bone in sorted(armature.data.bones, key=lambda item: item.name):
        if bone.get(OWNER_KEY) == OWNER_VALUE:
            continue
        payload.append(
            (
                bone.name,
                bone.parent.name if bone.parent else "",
                tuple(round(value, 7) for value in bone.head_local),
                tuple(round(value, 7) for value in bone.tail_local),
                tuple(round(float(value), 7) for row in bone.matrix_local for value in row),
                bool(bone.use_deform),
                bool(bone.use_connect),
            )
        )
    return hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def _side_from_name(name):
    match = re.search(r"(?:^|[._\-\s])(left|right|l|r)$", name, re.IGNORECASE)
    if match:
        return "L" if match.group(1).lower() in {"left", "l"} else "R"
    if re.match(r"^left(?=[A-Z_.\-\s]|$)", name, re.IGNORECASE):
        return "L"
    if re.match(r"^right(?=[A-Z_.\-\s]|$)", name, re.IGNORECASE):
        return "R"
    return ""


def _name_parts(name):
    expanded = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", name)
    tokens = tuple(token for token in re.split(r"[^a-z0-9]+", expanded.lower()) if token)
    base = "".join(token for token in tokens if token not in {"l", "r", "left", "right", "def"})
    return tokens, base


def _name_score(name, kind, role):
    tokens, base = _name_parts(name)
    if _EXCLUDED_TOKENS.intersection(tokens):
        return -1
    if any(marker in base for marker in ("twist", "helper", "corrective", "tweak")):
        return -1
    for keyword, score in LIMB_SPEC[kind][role]:
        if base == keyword:
            return score
        if base.startswith("def" + keyword) or base.endswith(keyword):
            return score - 1
    return -1


def _candidate_chains(armature, kind, side):
    candidates = []
    source_bones = [bone for bone in armature.data.bones if bone.get(OWNER_KEY) != OWNER_VALUE]
    center_x = sum(float(bone.head_local.x) for bone in source_bones) / max(1, len(source_bones))
    extent_x = max((abs(float(bone.head_local.x) - center_x) for bone in source_bones), default=1.0)
    for upper in armature.data.bones:
        upper_score = _name_score(upper.name, kind, "upper")
        if upper_score < 0 or upper.get(OWNER_KEY) == OWNER_VALUE or not upper.use_deform:
            continue
        for lower in upper.children:
            lower_score = _name_score(lower.name, kind, "lower")
            if lower_score < 0 or not lower.use_deform:
                continue
            for end in lower.children:
                end_score = _name_score(end.name, kind, "end")
                if end_score < 0 or not end.use_deform:
                    continue
                explicit = tuple(filter(None, (_side_from_name(b.name) for b in (upper, lower, end))))
                midpoint_x = sum(float(bone.head_local.x) for bone in (upper, lower, end)) / 3.0
                inferred_side = "L" if midpoint_x > center_x else "R"
                if explicit and any(item != side for item in explicit):
                    continue
                if not explicit and (abs(midpoint_x - center_x) < max(extent_x * 0.08, 1.0e-5) or inferred_side != side):
                    continue
                a = Vector(upper.head_local)
                b = Vector(lower.head_local)
                c = Vector(end.head_local)
                tolerance = max(upper.length, lower.length, end.length, 1.0) * 1.0e-4
                if (Vector(upper.tail_local) - b).length > tolerance or (Vector(lower.tail_local) - c).length > tolerance:
                    continue
                upper_len = (b - a).length
                lower_len = (c - b).length
                if min(upper_len, lower_len) <= EPSILON:
                    continue
                ratio = upper_len / lower_len
                if not 0.2 <= ratio <= 5.0:
                    continue
                delta = c - a
                geometry = 0.0
                if kind == "ARM" and math.hypot(delta.x, delta.y) >= abs(delta.z) * 0.45:
                    geometry += 1.0
                if kind == "LEG" and abs(delta.z) >= math.hypot(delta.x, delta.y) * 1.25:
                    geometry += 1.0
                if all(item == side for item in explicit) and len(explicit) == 3:
                    geometry += 1.0
                elif not explicit:
                    geometry += 0.25
                if end.length <= lower.length * 1.5:
                    geometry += 0.5
                candidates.append(
                    LimbChain(kind, side, upper.name, lower.name, end.name, upper_score + lower_score + end_score + geometry)
                )
    return sorted(candidates, key=lambda item: (-item.score, item.names))


def analyze_armature(armature):
    """Return a deterministic analysis without mutating the Armature datablock."""
    if armature is None or armature.type != "ARMATURE":
        raise LimbIKError("Make one Armature active before Analyze Rig.")
    scaffold_count = sum(bone.name.lower().startswith(("mch-", "org-", "ctrl-", "vis_")) for bone in armature.data.bones)
    if armature.get("rig_id") or armature.data.get("rig_id") or scaffold_count >= 12:
        raise LimbIKError("This looks like a generated control rig, not a clean humanoid Deform Skeleton; analyze the source/metarig instead.")
    results = {kind: {} for kind in KINDS}
    warnings = []
    for kind in KINDS:
        for side in SIDES:
            candidates = _candidate_chains(armature, kind, side)
            if not candidates:
                results[kind][side] = {"status": "MISSING", "warning": "No high-confidence direct chain was found."}
                warnings.append(f"{side} {kind.title()}: not identified")
                continue
            top = candidates[0]
            if top.score < 22.0:
                results[kind][side] = {"status": "LOW_CONFIDENCE", "warning": "Name, hierarchy, and position evidence did not reach the safe threshold."}
                warnings.append(f"{side} {kind.title()}: low confidence")
                continue
            if len(candidates) > 1 and top.score - candidates[1].score < 2.0:
                results[kind][side] = {"status": "AMBIGUOUS", "warning": "Two direct chains scored too closely; choose bones manually."}
                warnings.append(f"{side} {kind.title()}: ambiguous")
                continue
            upper = armature.data.bones[top.upper]
            lower = armature.data.bones[top.lower]
            start, joint, end = Vector(upper.head_local), Vector(lower.head_local), Vector(lower.tail_local)
            chain_axis = end - start
            projection = start + chain_axis * (joint - start).dot(chain_axis) / max(chain_axis.length_squared, EPSILON)
            straight_ratio = (joint - projection).length / max((joint - start).length + (end - joint).length, EPSILON)
            pole_warning = ""
            status = "READY"
            if straight_ratio < POLE_STRAIGHT_RATIO:
                status = "WARNING"
                pole_warning = f"Near-straight chain ({straight_ratio:.2%}); Build will use roll-aware -local Z and expose Flip Pole."
                warnings.append(f"{side} {kind.title()}: near-straight Pole fallback")
            results[kind][side] = {
                "status": status,
                "upper": top.upper,
                "lower": top.lower,
                "end": top.end,
                "score": top.score,
                "warning": pole_warning,
            }
    return {
        "version": RIG_VERSION,
        "armature": armature.name,
        "armature_data": armature.data.name,
        "digest": _armature_digest(armature),
        "limbs": results,
        "warnings": warnings,
    }


class CharacterDesignerLimbIKState(PropertyGroup):
    armature: PointerProperty(name="Armature", type=bpy.types.Object, poll=_armature_poll, options={"SKIP_SAVE"})
    analysis_json: StringProperty(default="", options={"HIDDEN", "SKIP_SAVE"})
    pole_distance_ratio: FloatProperty(name="Pole Distance", default=0.75, min=0.25, max=2.0, subtype="FACTOR", options={"SKIP_SAVE"})
    left_arm_upper: StringProperty(options={"SKIP_SAVE"})
    left_arm_lower: StringProperty(options={"SKIP_SAVE"})
    left_arm_end: StringProperty(options={"SKIP_SAVE"})
    right_arm_upper: StringProperty(options={"SKIP_SAVE"})
    right_arm_lower: StringProperty(options={"SKIP_SAVE"})
    right_arm_end: StringProperty(options={"SKIP_SAVE"})
    left_leg_upper: StringProperty(options={"SKIP_SAVE"})
    left_leg_lower: StringProperty(options={"SKIP_SAVE"})
    left_leg_end: StringProperty(options={"SKIP_SAVE"})
    right_leg_upper: StringProperty(options={"SKIP_SAVE"})
    right_leg_lower: StringProperty(options={"SKIP_SAVE"})
    right_leg_end: StringProperty(options={"SKIP_SAVE"})
    last_level: EnumProperty(items=(("NONE", "None", ""), ("INFO", "Info", ""), ("SUCCESS", "Success", ""), ("WARNING", "Warning", ""), ("ERROR", "Error", "")), default="NONE", options={"SKIP_SAVE"})
    last_message: StringProperty(default="", options={"SKIP_SAVE"})


class CHARACTERDESIGNER_OT_limb_ik_analyze(Operator):
    bl_idname = "character_designer.limb_ik_analyze"
    bl_label = "Analyze Rig"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == "ARMATURE" and context.mode in {"OBJECT", "POSE"}

    def execute(self, context):
        settings = _settings(context)
        try:
            armature = context.object
            payload = analyze_armature(armature)
            settings.armature = armature
            settings.analysis_json = _canonical_json(payload)
            for kind in KINDS:
                for side in SIDES:
                    result = payload["limbs"][kind][side]
                    for role in ROLES:
                        setattr(settings, _field_name(kind, side, role), result.get(role, ""))
            statuses = [payload["limbs"][kind][side]["status"] for kind in KINDS for side in SIDES]
            ready = sum(status in {"READY", "WARNING"} for status in statuses)
            incomplete = any(status not in {"READY", "WARNING"} for status in statuses)
            pole_warnings = any(status == "WARNING" for status in statuses)
            message = f"Analyze Rig found {ready}/4 high-confidence limbs."
            if incomplete:
                message += " Low-confidence sides were left blank."
            elif pole_warnings:
                message += " Near-straight Pole warnings are shown below."
            level = "WARNING" if incomplete or pole_warnings else "SUCCESS"
            _set_status(settings, level, message)
            self.report({"WARNING" if level == "WARNING" else "INFO"}, message)
            return {"FINISHED"}
        except (LimbIKError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
            _set_status(settings, "WARNING", str(exc))
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}


# Build/remove helpers and operators are intentionally below the analysis API so
# tests and future UI variants can use the detector independently.


def _require_active_armature(context, settings, *, analyzed=True):
    armature = context.object
    if armature is None or armature.type != "ARMATURE":
        raise LimbIKError("Make the intended Armature active first.")
    if settings is None:
        raise LimbIKError("Limb IK state is unavailable; reload Character Designer.")
    if analyzed and settings.armature is not armature:
        raise LimbIKError("The active Armature is not the analyzed Armature; run Analyze Rig again.")
    if armature.library is not None or armature.data.library is not None:
        raise LimbIKError("Linked Armatures are read-only; make a local copy before building Limb IK.")
    if armature.override_library is not None or armature.data.override_library is not None:
        raise LimbIKError("Library overrides are not modified by Limb IK; use a local Armature.")
    if armature.data.users != 1:
        raise LimbIKError("The active Armature Data is shared; make it single-user before building Limb IK.")
    memberships = [scene for scene in bpy.data.scenes if scene.objects.get(armature.name) is armature]
    if len(memberships) != 1 or memberships[0] is not context.scene:
        raise LimbIKError("The active Armature must belong only to the current Scene.")
    if context.view_layer.objects.get(armature.name) is not armature:
        raise LimbIKError("The active Armature is excluded from the current View Layer.")
    if abs(armature.matrix_world.to_3x3().determinant()) <= EPSILON:
        raise LimbIKError("The Armature transform is singular; apply a usable non-zero scale first.")
    if analyzed:
        try:
            payload = json.loads(settings.analysis_json)
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise LimbIKError("Analyze Rig data is missing or corrupt; run Analyze Rig again.") from exc
        if not isinstance(payload, dict) or payload.get("version") != RIG_VERSION:
            raise LimbIKError("Analyze Rig data is stale; run Analyze Rig again.")
        if payload.get("digest") != _armature_digest(armature):
            raise LimbIKError("Bone names, hierarchy, or rest pose changed; run Analyze Rig again.")
    return armature


def _chain_from_settings(settings, armature, kind, side):
    names = tuple(getattr(settings, _field_name(kind, side, role), "") for role in ROLES)
    if not any(names):
        return None
    if not all(names):
        raise LimbIKError(f"{side} {kind.title()} has an incomplete manual bone selection.")
    if len(set(names)) != 3:
        raise LimbIKError(f"{side} {kind.title()} must use three different bones.")
    bones = tuple(armature.data.bones.get(name) for name in names)
    if any(bone is None for bone in bones):
        raise LimbIKError(f"{side} {kind.title()} refers to a bone that no longer exists.")
    upper, lower, end = bones
    if lower.parent is None or lower.parent.name != upper.name or end.parent is None or end.parent.name != lower.name:
        raise LimbIKError(f"{side} {kind.title()} must be one direct upper → lower → end hierarchy.")
    if min((Vector(lower.head_local) - Vector(upper.head_local)).length, (Vector(end.head_local) - Vector(lower.head_local)).length) <= EPSILON:
        raise LimbIKError(f"{side} {kind.title()} contains a zero-length IK segment.")
    scale = max(upper.length, lower.length, end.length, 1.0)
    tolerance = max(scale * 1.0e-4, 1.0e-6)
    if (Vector(upper.tail_local) - Vector(lower.head_local)).length > tolerance or (Vector(lower.tail_local) - Vector(end.head_local)).length > tolerance:
        raise LimbIKError(f"{side} {kind.title()} joints are spatially disconnected.")
    if not all(bone.use_deform for bone in bones):
        raise LimbIKError(f"{side} {kind.title()} includes a non-Deform/scaffold bone.")
    if any(_EXCLUDED_TOKENS.intersection(_name_parts(bone.name)[0]) for bone in bones):
        raise LimbIKError(f"{side} {kind.title()} includes a helper, mechanism, or existing control bone.")
    explicit = tuple(filter(None, (_side_from_name(name) for name in names)))
    if explicit and any(value != side for value in explicit):
        raise LimbIKError(f"{side} {kind.title()} contains an explicit opposite-side bone name.")
    if any(bone.get(OWNER_KEY) == OWNER_VALUE for bone in bones):
        raise LimbIKError(f"{side} {kind.title()} cannot use generated control bones as deform inputs.")
    return LimbChain(kind, side, *names)


def _capture_context(context, armature):
    mode = context.mode
    if mode not in {"OBJECT", "POSE", "EDIT_ARMATURE"}:
        raise LimbIKError("Use Limb IK from Armature Object, Pose, or Edit Mode.")
    snapshot = {
        "mode": mode,
        "active": context.view_layer.objects.active,
        "selected": tuple(obj for obj in context.selected_objects),
        "bone_selection": {},
        "active_bone": "",
    }
    if mode == "EDIT_ARMATURE":
        snapshot["bone_selection"] = {
            bone.name: (bool(bone.select), bool(bone.select_head), bool(bone.select_tail))
            for bone in armature.data.edit_bones
        }
        active = armature.data.edit_bones.active
    else:
        snapshot["bone_selection"] = {bone.name: bool(bone.select) for bone in armature.pose.bones}
        active = armature.data.bones.active
    snapshot["active_bone"] = active.name if active else ""
    return snapshot


def _mode_set(context, armature, mode):
    active = context.view_layer.objects.active
    if context.mode != "OBJECT":
        if bpy.ops.object.mode_set(mode="OBJECT") != {"FINISHED"}:
            raise LimbIKError("Blender could not enter Object Mode for Limb IK.")
    for obj in context.view_layer.objects:
        obj.select_set(False)
    armature.select_set(True)
    context.view_layer.objects.active = armature
    if mode != "OBJECT" and bpy.ops.object.mode_set(mode=mode) != {"FINISHED"}:
        context.view_layer.objects.active = active
        raise LimbIKError(f"Blender could not enter {mode.title()} Mode for Limb IK.")


def _restore_context(context, armature, snapshot):
    if context.mode != "OBJECT" and bpy.ops.object.mode_set(mode="OBJECT") != {"FINISHED"}:
        raise LimbIKError("Blender could not restore Object Mode.")
    for obj in context.view_layer.objects:
        obj.select_set(False)
    selected = [obj for obj in snapshot["selected"] if bpy.data.objects.get(obj.name) is obj and context.view_layer.objects.get(obj.name) is obj]
    for obj in selected:
        obj.select_set(True)
    active = snapshot["active"]
    if active is not None and bpy.data.objects.get(active.name) is active and context.view_layer.objects.get(active.name) is active:
        context.view_layer.objects.active = active
    else:
        context.view_layer.objects.active = armature
        armature.select_set(True)
    original_mode = snapshot["mode"]
    if original_mode == "EDIT_ARMATURE":
        if context.view_layer.objects.active is not armature:
            raise LimbIKError("The original Edit Armature is no longer active.")
        if bpy.ops.object.mode_set(mode="EDIT") != {"FINISHED"}:
            raise LimbIKError("Blender could not restore Armature Edit Mode.")
        for bone in armature.data.edit_bones:
            values = snapshot["bone_selection"].get(bone.name, (False, False, False))
            bone.select, bone.select_head, bone.select_tail = values
        armature.data.edit_bones.active = armature.data.edit_bones.get(snapshot["active_bone"])
    elif original_mode == "POSE":
        if context.view_layer.objects.active is not armature:
            raise LimbIKError("The original Pose Armature is no longer active.")
        if bpy.ops.object.mode_set(mode="POSE") != {"FINISHED"}:
            raise LimbIKError("Blender could not restore Pose Mode.")
        for bone in armature.pose.bones:
            bone.select = snapshot["bone_selection"].get(bone.name, False)
        armature.data.bones.active = armature.data.bones.get(snapshot["active_bone"])
    elif original_mode == "OBJECT":
        for bone in armature.pose.bones:
            bone.select = snapshot["bone_selection"].get(bone.name, False)
        armature.data.bones.active = armature.data.bones.get(snapshot["active_bone"])


def _project_perpendicular(vector, axis):
    axis = Vector(axis)
    if axis.length <= EPSILON:
        return Vector()
    axis.normalize()
    return Vector(vector) - axis * Vector(vector).dot(axis)


def _signed_angle(reference, target, axis):
    reference = _project_perpendicular(reference, axis)
    target = _project_perpendicular(target, axis)
    if reference.length <= EPSILON or target.length <= EPSILON:
        raise LimbIKError("Pole Angle could not be derived from the source bone roll.")
    reference.normalize()
    target.normalize()
    axis = Vector(axis).normalized()
    return math.atan2(axis.dot(reference.cross(target)), max(-1.0, min(1.0, reference.dot(target))))


def _pole_solution(start, joint, end, upper_x, upper_z, lower_z, distance_ratio):
    chain_axis = Vector(end) - Vector(start)
    if chain_axis.length <= EPSILON:
        raise LimbIKError("The limb root and IK endpoint occupy the same position.")
    projection = Vector(start) + chain_axis * (Vector(joint) - Vector(start)).dot(chain_axis) / chain_axis.length_squared
    residual = Vector(joint) - projection
    total = (Vector(joint) - Vector(start)).length + (Vector(end) - Vector(joint)).length
    if total <= EPSILON:
        raise LimbIKError("The limb has no usable length.")
    ratio = residual.length / total
    warning = ""
    if ratio >= POLE_STRAIGHT_RATIO:
        direction = residual.normalized()
    else:
        # Near-straight limbs make the tiny residual noise-dominated.  Projected
        # negative local Z is roll-aware and gives X's arms +Y and legs -Y.
        coherent_z = _project_perpendicular(-(Vector(upper_z) + Vector(lower_z)), chain_axis)
        if coherent_z.length > 0.25:
            direction = coherent_z
        else:
            candidates = (_project_perpendicular(-Vector(upper_z), chain_axis), _project_perpendicular(-Vector(lower_z), chain_axis), _project_perpendicular(Vector(upper_x), chain_axis))
            direction = max(candidates, key=lambda value: value.length)
        if direction.length <= EPSILON:
            raise LimbIKError("The nearly straight limb has no reliable roll axis; adjust the bend or choose a Pole manually.")
        direction.normalize()
        warning = f"Near-straight chain ({ratio:.2%}); Pole uses projected -local Z. Flip Pole if the bend is reversed."
    pole_head = Vector(joint) + direction * total * float(distance_ratio)
    plane_normal = chain_axis.cross(pole_head - Vector(start))
    projected_pole_axis = plane_normal.cross(Vector(joint) - Vector(start))
    pole_angle = -_signed_angle(upper_x, projected_pole_axis, Vector(joint) - Vector(start))
    return pole_head, pole_angle, warning


def _build_plan(armature, chain, distance_ratio):
    upper = armature.pose.bones[chain.upper]
    lower = armature.pose.bones[chain.lower]
    end_bone = armature.pose.bones[chain.end]
    start = Vector(upper.head)
    joint = Vector(lower.head)
    end = Vector(lower.tail)
    pole_head, pole_angle, warning = _pole_solution(start, joint, end, upper.x_axis, upper.z_axis, lower.z_axis, distance_ratio)
    total = (joint - start).length + (end - joint).length
    size = max(total * 0.14, 1.0e-4)
    end_direction = Vector(end_bone.tail) - Vector(end_bone.head)
    if end_direction.length <= EPSILON:
        end_direction = end - joint
    end_direction.normalize()
    pole_tail_direction = _project_perpendicular(upper.z_axis, end - start)
    if pole_tail_direction.length <= EPSILON:
        pole_tail_direction = Vector((0.0, 0.0, 1.0))
    pole_tail_direction.normalize()
    return LimbPlan(
        chain=chain,
        rig_id=uuid.uuid4().hex,
        target_name=LIMB_SPEC[chain.kind]["target"].format(side=chain.side),
        pole_name=LIMB_SPEC[chain.kind]["pole"].format(side=chain.side),
        start=start,
        joint=joint,
        end=end,
        target_head=end.copy(),
        target_tail=end + end_direction * size,
        target_z=Vector(end_bone.matrix.to_3x3().col[2]),
        pole_head=pole_head,
        pole_tail=pole_head + pole_tail_direction * size * 0.65,
        pole_angle=pole_angle,
        pole_warning=warning,
        desired_upper_matrix=upper.matrix.copy(),
        desired_lower_matrix=lower.matrix.copy(),
        desired_end_matrix=end_bone.matrix.copy(),
        target_basis=Matrix.Identity(4),
        pole_basis=Matrix.Identity(4),
    )


def _constraint_registry(pose_bone, *, strict=False):
    raw = pose_bone.get(CONSTRAINT_REGISTRY_KEY, "")
    if not raw:
        return {}
    try:
        payload = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        if strict:
            raise LimbIKError(f"Limb IK registry on bone '{pose_bone.name}' is corrupt.") from exc
        return {}
    if not isinstance(payload, dict):
        if strict:
            raise LimbIKError(f"Limb IK registry on bone '{pose_bone.name}' is invalid.")
        return {}
    return payload


def _write_constraint_registry(pose_bone, registry):
    if registry:
        pose_bone[CONSTRAINT_REGISTRY_KEY] = _canonical_json(registry)
    elif CONSTRAINT_REGISTRY_KEY in pose_bone:
        del pose_bone[CONSTRAINT_REGISTRY_KEY]


def _constraint_name(rig_id, role):
    return f"CDLimbIK_{role}_{rig_id}"


def _tag(target, armature_id, *, role, rig_id="", kind="", side="", chain=()):
    target[OWNER_KEY] = OWNER_VALUE
    target[VERSION_KEY] = RIG_VERSION
    target[ARMATURE_ID_KEY] = armature_id
    target[ROLE_KEY] = role
    if rig_id:
        target[RIG_ID_KEY] = rig_id
    if kind:
        target[KIND_KEY] = kind
    if side:
        target[SIDE_KEY] = side
    if chain:
        target[CHAIN_KEY] = _canonical_json(list(chain))


def _owned(target, armature_id, *, role=None, rig_id=None):
    try:
        return (
            target.get(OWNER_KEY) == OWNER_VALUE
            and target.get(VERSION_KEY) == RIG_VERSION
            and target.get(ARMATURE_ID_KEY) == armature_id
            and (role is None or target.get(ROLE_KEY) == role)
            and (rig_id is None or target.get(RIG_ID_KEY) == rig_id)
        )
    except (AttributeError, ReferenceError):
        return False


def _widget_geometry(kind):
    if kind == "HAND":
        vertices = ((-0.75, 0, -0.55), (0.75, 0, -0.55), (0.9, 0, -0.35), (0.9, 0, 0.35), (0.75, 0, 0.55), (-0.75, 0, 0.55), (-0.9, 0, 0.35), (-0.9, 0, -0.35))
    elif kind == "FOOT":
        vertices = ((-0.65, -0.9, 0), (0.65, -0.9, 0), (0.82, 0.55, 0), (0.5, 1.0, 0), (-0.5, 1.0, 0), (-0.82, 0.55, 0))
    else:
        count = 12
        vertices = tuple((math.cos(index * math.tau / count), 0, math.sin(index * math.tau / count)) for index in range(count))
    edges = tuple((index, (index + 1) % len(vertices)) for index in range(len(vertices)))
    return vertices, edges


def _collection_scene_memberships(collection):
    return tuple(scene for scene in bpy.data.scenes if collection is scene.collection or collection in scene.collection.children_recursive)


def _ensure_widget_collection(context, armature_id, transaction):
    matches = [collection for collection in bpy.data.collections if _owned(collection, armature_id, role="WIDGET_COLLECTION")]
    if len(matches) > 1:
        raise LimbIKError("Multiple owned Randy Rig widget collections were found; repair them manually.")
    if matches:
        collection = matches[0]
        if _collection_scene_memberships(collection) != (context.scene,):
            raise LimbIKError("The owned widget collection is linked across Scenes.")
        return collection
    foreign = bpy.data.collections.get(WIDGET_COLLECTION_NAME)
    if foreign is not None:
        raise LimbIKError(f"Collection '{WIDGET_COLLECTION_NAME}' already exists but is not owned by Character Designer.")
    collection = bpy.data.collections.new(WIDGET_COLLECTION_NAME)
    context.scene.collection.children.link(collection)
    _tag(collection, armature_id, role="WIDGET_COLLECTION")
    collection.hide_render = True
    collection.hide_viewport = True
    transaction["collections"].append(collection)
    return collection


def _ensure_widget(context, armature_id, collection, kind, transaction):
    matches = [obj for obj in bpy.data.objects if _owned(obj, armature_id, role="WIDGET") and obj.get(KIND_KEY) == kind]
    if len(matches) > 1:
        raise LimbIKError(f"Multiple owned {kind.title()} widgets were found.")
    if matches:
        obj = matches[0]
        if obj.type != "MESH" or not _owned(obj.data, armature_id, role="WIDGET_DATA") or obj.data.get(KIND_KEY) != kind:
            raise LimbIKError(f"Owned {kind.title()} widget data is invalid.")
        if tuple(obj.users_collection) != (collection,):
            raise LimbIKError(f"Owned {kind.title()} widget is linked outside its exact collection.")
        return obj
    names = {"HAND": "WGT_Randy_HandIK", "FOOT": "WGT_Randy_FootIK", "POLE": "WGT_Randy_Pole"}
    name = names[kind]
    if bpy.data.objects.get(name) is not None or bpy.data.meshes.get(name) is not None:
        raise LimbIKError(f"Widget name '{name}' is already used by non-owned data.")
    mesh = bpy.data.meshes.new(name)
    vertices, edges = _widget_geometry(kind)
    mesh.from_pydata(vertices, edges, ())
    mesh.update()
    _tag(mesh, armature_id, role="WIDGET_DATA", kind=kind)
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    _tag(obj, armature_id, role="WIDGET", kind=kind)
    obj.hide_render = True
    obj.display_type = "WIRE"
    transaction["meshes"].append(mesh)
    transaction["objects"].append(obj)
    return obj


def _ensure_control_collection(armature, armature_id, transaction):
    matches = [collection for collection in armature.data.collections if _owned(collection, armature_id, role="CONTROL_COLLECTION")]
    if len(matches) > 1:
        raise LimbIKError("Multiple owned Randy Controls bone collections were found.")
    if matches:
        return matches[0]
    foreign = armature.data.collections.get(CONTROL_COLLECTION_NAME)
    if foreign is not None:
        raise LimbIKError(f"Bone Collection '{CONTROL_COLLECTION_NAME}' already exists but is not owned by Character Designer.")
    collection = armature.data.collections.new(CONTROL_COLLECTION_NAME)
    _tag(collection, armature_id, role="CONTROL_COLLECTION")
    transaction["bone_collections"].append(collection)
    return collection


def _owned_constraint_records(armature, *, strict=True):
    records = []
    pose = armature.pose
    if pose is None:
        return records
    for pose_bone in pose.bones:
        registry = _constraint_registry(pose_bone, strict=strict)
        for constraint_name, record in registry.items():
            if not isinstance(constraint_name, str) or not isinstance(record, dict):
                raise LimbIKError(f"Limb IK registry on bone '{pose_bone.name}' contains an invalid record.")
            rig_id = record.get("rig_id")
            role = record.get("role")
            if (
                record.get("owner") != OWNER_VALUE
                or record.get("version") != RIG_VERSION
                or not isinstance(rig_id, str)
                or not rig_id
                or role not in {"IK", "END_ROTATION"}
                or constraint_name != _constraint_name(rig_id, role)
            ):
                raise LimbIKError(f"Limb IK registry on bone '{pose_bone.name}' has an unknown ownership fingerprint.")
            matches = [constraint for constraint in pose_bone.constraints if constraint.name == constraint_name]
            if len(matches) != 1:
                raise LimbIKError(f"Owned constraint '{constraint_name}' is missing or duplicated.")
            constraint = matches[0]
            expected_type = "IK" if role == "IK" else "COPY_ROTATION"
            if constraint.type != expected_type:
                raise LimbIKError(f"Owned constraint '{constraint_name}' changed type.")
            records.append((pose_bone, constraint, record))
    return records


def _record_constraint(pose_bone, constraint, plan, armature_id, role):
    registry = _constraint_registry(pose_bone, strict=True)
    constraint.name = _constraint_name(plan.rig_id, role)
    if constraint.name in registry:
        raise LimbIKError(f"Constraint registry collision on '{pose_bone.name}'.")
    registry[constraint.name] = {
        "owner": OWNER_VALUE,
        "version": RIG_VERSION,
        "armature_id": armature_id,
        "rig_id": plan.rig_id,
        "role": role,
        "kind": plan.chain.kind,
        "side": plan.chain.side,
        "chain": list(plan.chain.names),
        "target": plan.target_name,
        "pole": plan.pole_name,
    }
    _write_constraint_registry(pose_bone, registry)


def _validate_inventory(armature):
    armature_id = armature.data.get(ARMATURE_ID_KEY, "")
    generated = [bone for bone in armature.data.bones if bone.get(OWNER_KEY) == OWNER_VALUE]
    records = _owned_constraint_records(armature, strict=True)
    if not armature_id:
        if generated or records:
            raise LimbIKError("Orphaned Limb IK ownership data was found on this Armature.")
        return {"armature_id": "", "rigs": {}, "records": [], "bones": []}
    if not isinstance(armature_id, str):
        raise LimbIKError("The Limb IK Armature ID is invalid.")
    rigs = {}
    by_rig = {}
    for pose_bone, constraint, record in records:
        if record.get("armature_id") != armature_id:
            raise LimbIKError("A Limb IK constraint belongs to a different Armature ID.")
        rig_id = record["rig_id"]
        by_rig.setdefault(rig_id, []).append((pose_bone, constraint, record))
    expected_bones = set()
    for rig_id, entries in by_rig.items():
        if len(entries) != 2 or {record["role"] for _pb, _con, record in entries} != {"IK", "END_ROTATION"}:
            raise LimbIKError(f"Limb IK rig '{rig_id}' is incomplete.")
        sample = entries[0][2]
        key = (sample.get("kind"), sample.get("side"))
        if key[0] not in KINDS or key[1] not in SIDES or key in rigs:
            raise LimbIKError("Duplicate or invalid Limb IK side ownership was found.")
        chain_value = sample.get("chain")
        target_name = sample.get("target")
        pole_name = sample.get("pole")
        if (
            not isinstance(chain_value, (list, tuple))
            or len(chain_value) != 3
            or any(not isinstance(name, str) or not name for name in chain_value)
            or len(set(chain_value)) != 3
            or any(armature.data.bones.get(name) is None for name in chain_value)
            or not isinstance(target_name, str)
            or not target_name
            or not isinstance(pole_name, str)
            or not pole_name
            or target_name == pole_name
        ):
            raise LimbIKError(f"Limb IK rig '{rig_id}' registry has an invalid source/control bone schema.")
        chain = tuple(chain_value)
        if any(
            record.get("chain") != list(chain)
            or record.get("target") != target_name
            or record.get("pole") != pole_name
            or record.get("kind") != sample.get("kind")
            or record.get("side") != sample.get("side")
            or record.get("armature_id") != armature_id
            for _pb, _con, record in entries
        ):
            raise LimbIKError(f"Limb IK rig '{rig_id}' has inconsistent registry records.")
        target = armature.data.bones.get(target_name)
        pole = armature.data.bones.get(pole_name)
        if not _owned(target, armature_id, role=LIMB_SPEC[key[0]]["target_role"], rig_id=rig_id) or not _owned(pole, armature_id, role="POLE", rig_id=rig_id):
            raise LimbIKError(f"Limb IK rig '{rig_id}' control bone ownership is invalid.")
        expected_bones.update((target.name, pole.name))
        ik_entry = next(entry for entry in entries if entry[2]["role"] == "IK")
        end_entry = next(entry for entry in entries if entry[2]["role"] == "END_ROTATION")
        lower_pb, ik, _record = ik_entry
        end_pb, copy_rotation, _record = end_entry
        if lower_pb.name != chain[1] or end_pb.name != chain[2]:
            raise LimbIKError(f"Limb IK rig '{rig_id}' constraints moved to other bones.")
        if ik.target is not armature or ik.subtarget != target.name or ik.pole_target is not armature or ik.pole_subtarget != pole.name or ik.chain_count != 2:
            raise LimbIKError(f"Limb IK rig '{rig_id}' IK settings were edited.")
        if copy_rotation.target is not armature or copy_rotation.subtarget != target.name:
            raise LimbIKError(f"Limb IK rig '{rig_id}' end rotation settings were edited.")
        rigs[key] = {"rig_id": rig_id, "entries": entries, "target": target, "pole": pole, "chain": chain}
    if {bone.name for bone in generated} != expected_bones:
        raise LimbIKError("Orphaned or duplicate generated Limb IK control bones were found.")
    return {"armature_id": armature_id, "rigs": rigs, "records": records, "bones": generated}


def _preflight_plans(context, armature, plans, inventory):
    existing_keys = set(inventory["rigs"])
    for plan in plans:
        key = (plan.chain.kind, plan.chain.side)
        if key in existing_keys:
            if tuple(inventory["rigs"][key]["chain"]) != plan.chain.names:
                raise LimbIKError(f"Existing {plan.chain.side} {plan.chain.kind.title()} rig targets a different source chain; use Remove Generated Rig first.")
            continue
        for name in (plan.target_name, plan.pole_name):
            if armature.data.bones.get(name) is not None:
                raise LimbIKError(f"Bone '{name}' already exists and is not this exact generated control.")
        lower = armature.pose.bones[plan.chain.lower]
        end = armature.pose.bones[plan.chain.end]
        if any(constraint.type == "IK" for constraint in lower.constraints):
            raise LimbIKError(f"Bone '{lower.name}' already has an IK constraint; Limb IK will not stack another one.")
        if any(constraint.type == "COPY_ROTATION" for constraint in end.constraints):
            raise LimbIKError(f"Bone '{end.name}' already has Copy Rotation; Limb IK will not stack another one.")
    if not inventory["armature_id"]:
        if armature.data.collections.get(CONTROL_COLLECTION_NAME) is not None:
            raise LimbIKError(f"Bone Collection '{CONTROL_COLLECTION_NAME}' is occupied by foreign data.")
        if bpy.data.collections.get(WIDGET_COLLECTION_NAME) is not None:
            raise LimbIKError(f"Collection '{WIDGET_COLLECTION_NAME}' is occupied by foreign data.")


def _new_transaction():
    return {
        "constraints": [],
        "registry_before": {},
        "bone_names": [],
        "objects": [],
        "meshes": [],
        "collections": [],
        "bone_collections": [],
        "new_armature_id": False,
    }


def _remember_registry(transaction, pose_bone):
    if pose_bone.name not in transaction["registry_before"]:
        transaction["registry_before"][pose_bone.name] = pose_bone.get(CONSTRAINT_REGISTRY_KEY, None)


def _rollback_build(context, armature, transaction):
    errors = []
    try:
        _mode_set(context, armature, "POSE")
        for pose_bone, constraint in reversed(transaction["constraints"]):
            try:
                # RNA wrapper identity is not stable across the Edit/Object/Pose
                # boundaries used while adding controls.  Resolve the exact
                # transaction-created UUID name again instead of comparing the
                # short-lived Python proxy with ``is``.
                live_owner = armature.pose.bones.get(pose_bone.name)
                live_constraint = live_owner.constraints.get(constraint.name) if live_owner is not None else None
                if live_constraint is not None:
                    live_owner.constraints.remove(live_constraint)
            except (ReferenceError, RuntimeError) as exc:
                errors.append(str(exc))
        for bone_name, raw in transaction["registry_before"].items():
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                continue
            try:
                if raw is None:
                    if CONSTRAINT_REGISTRY_KEY in pose_bone:
                        del pose_bone[CONSTRAINT_REGISTRY_KEY]
                else:
                    pose_bone[CONSTRAINT_REGISTRY_KEY] = raw
            except (ReferenceError, RuntimeError) as exc:
                errors.append(str(exc))
        _mode_set(context, armature, "OBJECT")
        armature.data.update_tag()
        armature.update_tag(refresh={"OBJECT"})
        context.view_layer.update()
        _mode_set(context, armature, "EDIT")
        for name in reversed(transaction["bone_names"]):
            bone = armature.data.edit_bones.get(name)
            if bone is not None:
                armature.data.edit_bones.remove(bone)
        _mode_set(context, armature, "OBJECT")
        armature.data.update_tag()
        armature.update_tag(refresh={"OBJECT"})
        context.view_layer.update()
    except (LimbIKError, ReferenceError, RuntimeError) as exc:
        errors.append(str(exc))
    for obj in reversed(transaction["objects"]):
        try:
            if bpy.data.objects.get(obj.name) is obj:
                bpy.data.objects.remove(obj, do_unlink=True)
        except (ReferenceError, RuntimeError) as exc:
            errors.append(str(exc))
    for mesh in reversed(transaction["meshes"]):
        try:
            if bpy.data.meshes.get(mesh.name) is mesh and not mesh.users:
                bpy.data.meshes.remove(mesh)
        except (ReferenceError, RuntimeError) as exc:
            errors.append(str(exc))
    for collection in reversed(transaction["collections"]):
        try:
            if bpy.data.collections.get(collection.name) is collection:
                bpy.data.collections.remove(collection)
        except (ReferenceError, RuntimeError) as exc:
            errors.append(str(exc))
    for collection in reversed(transaction["bone_collections"]):
        try:
            live = armature.data.collections.get(collection.name)
            if live is not None:
                armature.data.collections.remove(live)
        except (ReferenceError, RuntimeError) as exc:
            errors.append(str(exc))
    if transaction["new_armature_id"] and ARMATURE_ID_KEY in armature.data:
        try:
            del armature.data[ARMATURE_ID_KEY]
        except (ReferenceError, RuntimeError) as exc:
            errors.append(str(exc))
    return errors


def _create_control_bones(context, armature, armature_id, plans, transaction):
    # Blender's X-Mirror edit option also mirrors programmatic EditBone writes.
    # On an asymmetric/rest-rolled production skeleton, creating the R control
    # after L can silently overwrite L's roll.  This temporary option change is
    # local to the edit transaction and is restored on every exit path.
    mirror_x = bool(armature.data.use_mirror_x)
    try:
        armature.data.use_mirror_x = False
        _mode_set(context, armature, "EDIT")
        for plan in plans:
            target = armature.data.edit_bones.new(plan.target_name)
            if target.name != plan.target_name:
                raise LimbIKError(f"Blender renamed generated bone '{plan.target_name}'; build was rolled back.")
            transaction["bone_names"].append(target.name)
            target.head = plan.target_head
            target.tail = plan.target_tail
            target.parent = None
            target.use_connect = False
            target.use_deform = False
            target.align_roll(plan.target_z)

            pole = armature.data.edit_bones.new(plan.pole_name)
            if pole.name != plan.pole_name:
                raise LimbIKError(f"Blender renamed generated bone '{plan.pole_name}'; build was rolled back.")
            transaction["bone_names"].append(pole.name)
            pole.head = plan.pole_head
            pole.tail = plan.pole_tail
            pole.parent = None
            pole.use_connect = False
            pole.use_deform = False

        # Finish the topology edit before restoring the artist's symmetry flag;
        # restoring it while Edit Mode is live can itself mirror the last write.
        _mode_set(context, armature, "OBJECT")
    finally:
        armature.data.use_mirror_x = mirror_x

    # Commit the edited Armature topology through an evaluated Object-mode
    # boundary before PoseBone/constraint access.  Dense production rigs can
    # otherwise keep a stale depsgraph relation for the newly-created controls.
    armature.data.update_tag()
    armature.update_tag(refresh={"OBJECT"})
    context.view_layer.update()
    _mode_set(context, armature, "POSE")
    collection = _ensure_control_collection(armature, armature_id, transaction)
    for plan in plans:
        target = armature.data.bones[plan.target_name]
        pole = armature.data.bones[plan.pole_name]
        target.use_deform = False
        pole.use_deform = False
        _tag(target, armature_id, role=LIMB_SPEC[plan.chain.kind]["target_role"], rig_id=plan.rig_id, kind=plan.chain.kind, side=plan.chain.side, chain=plan.chain.names)
        _tag(pole, armature_id, role="POLE", rig_id=plan.rig_id, kind=plan.chain.kind, side=plan.chain.side, chain=plan.chain.names)
        collection.assign(target)
        collection.assign(pole)
    # BoneCollection assignment and Bone ID-property writes can invalidate the
    # production depsgraph a second time.  Rebuild it at an Object boundary so
    # IK relation creation sees BONE_DONE nodes for every new control.
    _mode_set(context, armature, "OBJECT")
    armature.data.update_tag()
    armature.update_tag(refresh={"OBJECT"})
    context.view_layer.update()
    context.evaluated_depsgraph_get().update()
    context.scene.frame_set(context.scene.frame_current)
    context.view_layer.update()
    _mode_set(context, armature, "POSE")
    context.view_layer.update()


def _create_constraint_shells(armature, plans, transaction):
    """Create exact constraint references before their future control bones.

    Blender's dense-rig depsgraph only creates same-Armature BONE_DONE nodes
    reliably when those references already exist as Edit Mode commits the new
    bones.  No evaluation is requested until `_create_control_bones` completes.
    """
    for plan in plans:
        lower = armature.pose.bones[plan.chain.lower]
        _remember_registry(transaction, lower)
        ik = lower.constraints.new(type="IK")
        ik.name = _constraint_name(plan.rig_id, "IK")
        ik.target = armature
        ik.subtarget = plan.target_name
        ik.pole_target = armature
        ik.pole_subtarget = plan.pole_name
        ik.chain_count = 2
        ik.pole_angle = plan.pole_angle
        if hasattr(ik, "use_tail"):
            ik.use_tail = True
        if hasattr(ik, "use_stretch"):
            ik.use_stretch = False
        transaction["constraints"].append((lower, ik))

def _create_constraints_and_shapes(context, armature, armature_id, plans, transaction):
    widget_collection = _ensure_widget_collection(context, armature_id, transaction)
    widgets = {"POLE": _ensure_widget(context, armature_id, widget_collection, "POLE", transaction)}
    if any(plan.chain.kind == "ARM" for plan in plans):
        widgets["ARM"] = _ensure_widget(context, armature_id, widget_collection, "HAND", transaction)
    if any(plan.chain.kind == "LEG" for plan in plans):
        widgets["LEG"] = _ensure_widget(context, armature_id, widget_collection, "FOOT", transaction)

    pending_records = []
    runtime_constraints = {}
    for plan in plans:
        armature.pose.bones[plan.target_name].matrix_basis = plan.target_basis
        armature.pose.bones[plan.pole_name].matrix_basis = plan.pole_basis
        lower = armature.pose.bones[plan.chain.lower]
        end = armature.pose.bones[plan.chain.end]
        ik_name = _constraint_name(plan.rig_id, "IK")
        ik = lower.constraints.get(ik_name)
        if ik is None or ik.type != "IK":
            raise LimbIKError(f"{plan.chain.side} {plan.chain.kind.title()} IK shell disappeared while creating controls.")
        _remember_registry(transaction, end)
        copy_rotation = end.constraints.new(type="COPY_ROTATION")
        copy_rotation.name = _constraint_name(plan.rig_id, "END_ROTATION")
        copy_rotation.target = armature
        copy_rotation.subtarget = plan.target_name
        copy_rotation.target_space = "WORLD"
        copy_rotation.owner_space = "WORLD"
        if hasattr(copy_rotation, "mix_mode"):
            copy_rotation.mix_mode = "REPLACE"
        transaction["constraints"].append((end, copy_rotation))
        runtime_constraints[plan.rig_id] = (ik, copy_rotation)

    # Configure every same-Armature relation first, then rebuild the relation
    # graph once.  Creating and evaluating one side at a time leaves later
    # controls without BONE_DONE nodes on dense production rigs.
    _mode_set(context, armature, "OBJECT")
    armature.data.update_tag()
    armature.update_tag(refresh={"OBJECT"})
    context.scene.update_tag()
    context.view_layer.update()
    context.evaluated_depsgraph_get().update()
    _mode_set(context, armature, "POSE")
    context.view_layer.update()

    for plan in plans:
        lower = armature.pose.bones[plan.chain.lower]
        end = armature.pose.bones[plan.chain.end]
        target = armature.pose.bones[plan.target_name]
        pole = armature.pose.bones[plan.pole_name]
        target.custom_shape = widgets[plan.chain.kind]
        pole.custom_shape = widgets["POLE"]
        if hasattr(target, "custom_shape_wire_width"):
            target.custom_shape_wire_width = 2.0
            pole.custom_shape_wire_width = 2.0

        ik, copy_rotation = runtime_constraints[plan.rig_id]
        ik_name = _constraint_name(plan.rig_id, "IK")
        for index, (owner, constraint) in enumerate(transaction["constraints"]):
            if constraint.name == ik_name:
                transaction["constraints"][index] = (lower, ik)
                break
        ik.pole_angle = _calibrate_pole_angle(context, armature, plan, ik)
        pending_records.append((lower, ik, plan, "IK"))

        copy_name = _constraint_name(plan.rig_id, "END_ROTATION")
        for index, (_owner, constraint) in enumerate(transaction["constraints"]):
            if constraint.name == copy_name:
                transaction["constraints"][index] = (end, copy_rotation)
                break
        context.view_layer.update()
        end_position_error = (Vector(end.head) - plan.desired_end_matrix.translation).length
        end_rotation_error = _rotation_error(end.matrix, plan.desired_end_matrix)
        if end_position_error > 2.0e-4 or end_rotation_error > 2.0e-3:
            raise LimbIKError(
                f"{plan.chain.side} {plan.chain.kind.title()} end controller could not preserve "
                f"the current Hand/Foot pose (position {end_position_error:.4g}, rotation {end_rotation_error:.4g})."
            )
        pending_records.append((end, copy_rotation, plan, "END_ROTATION"))

    # PoseBone ID-property writes rebuild relation components on dense rigs.
    # Defer every registry write until all solver work and no-pop validation is
    # complete, then cross an Object boundary once before final inventory.
    for pose_bone, constraint, plan, role in pending_records:
        _record_constraint(pose_bone, constraint, plan, armature_id, role)
    _mode_set(context, armature, "OBJECT")
    armature.data.update_tag()
    armature.update_tag(refresh={"OBJECT"})
    context.scene.update_tag()
    context.view_layer.update()
    context.evaluated_depsgraph_get().update()
    _mode_set(context, armature, "POSE")
    context.view_layer.update()


def _rotation_error(matrix, desired):
    return matrix.to_quaternion().rotation_difference(desired.to_quaternion()).angle


def _pole_pose_error(armature, plan):
    upper = armature.pose.bones[plan.chain.upper]
    lower = armature.pose.bones[plan.chain.lower]
    total = max((plan.joint - plan.start).length + (plan.end - plan.joint).length, EPSILON)
    position_error = (
        (Vector(upper.head) - plan.start).length
        + (Vector(upper.tail) - plan.joint).length
        + (Vector(lower.head) - plan.joint).length
        + (Vector(lower.tail) - plan.end).length
    ) / total
    rotation_error = _rotation_error(upper.matrix, plan.desired_upper_matrix) + _rotation_error(lower.matrix, plan.desired_lower_matrix)
    return position_error * 8.0 + rotation_error


def _calibrate_pole_angle(context, armature, plan, constraint):
    """Use Blender's own IK solver to make arbitrary source roll a no-pop build."""
    samples = 32
    step = math.tau / samples
    best_angle = float(plan.pole_angle)
    best_error = float("inf")
    for index in range(samples):
        angle = plan.pole_angle - math.pi + index * step
        constraint.pole_angle = angle
        context.view_layer.update()
        error = _pole_pose_error(armature, plan)
        if error < best_error:
            best_angle, best_error = angle, error
    left = best_angle - step
    right = best_angle + step
    golden = (math.sqrt(5.0) - 1.0) * 0.5
    x1 = right - golden * (right - left)
    x2 = left + golden * (right - left)

    def evaluate(angle):
        constraint.pole_angle = angle
        context.view_layer.update()
        return _pole_pose_error(armature, plan)

    f1, f2 = evaluate(x1), evaluate(x2)
    for _index in range(14):
        if f1 <= f2:
            right, x2, f2 = x2, x1, f1
            x1 = right - golden * (right - left)
            f1 = evaluate(x1)
        else:
            left, x1, f1 = x1, x2, f2
            x2 = left + golden * (right - left)
            f2 = evaluate(x2)
    if f1 <= f2:
        best_angle, best_error = x1, f1
    else:
        best_angle, best_error = x2, f2
    constraint.pole_angle = math.remainder(best_angle, math.tau)
    context.view_layer.update()
    final_error = _pole_pose_error(armature, plan)
    if not math.isfinite(final_error) or final_error > 2.0e-3:
        raise LimbIKError(
            f"{plan.chain.side} {plan.chain.kind.title()} Pole Angle could not preserve the current pose "
            f"(solver error {final_error:.4g}); adjust the source bend/roll before Build."
        )
    return constraint.pole_angle


def _build_plans(context, armature, plans):
    inventory = _validate_inventory(armature)
    _preflight_plans(context, armature, plans, inventory)
    missing = [plan for plan in plans if (plan.chain.kind, plan.chain.side) not in inventory["rigs"]]
    if not missing:
        raise LimbIKError("The requested Limb IK rig already exists; use Rebuild Rig to replace it.")
    transaction = _new_transaction()
    armature_id = inventory["armature_id"]
    try:
        if not armature_id:
            armature_id = uuid.uuid4().hex
            armature.data[ARMATURE_ID_KEY] = armature_id
            transaction["new_armature_id"] = True
        _create_constraint_shells(armature, missing, transaction)
        _create_control_bones(context, armature, armature_id, missing, transaction)
        _create_constraints_and_shapes(context, armature, armature_id, missing, transaction)
        verified = _validate_inventory(armature)
        for plan in missing:
            if (plan.chain.kind, plan.chain.side) not in verified["rigs"]:
                raise LimbIKError(f"Generated {plan.chain.side} {plan.chain.kind.title()} rig did not pass ownership verification.")
        return missing, transaction
    except (LimbIKError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
        rollback_errors = _rollback_build(context, armature, transaction)
        if rollback_errors:
            raise LimbIKError(f"{exc} Rollback also reported: {'; '.join(rollback_errors)}") from exc
        raise


def _plans_for_kind(context, armature, settings, kind):
    chains = []
    for side in SIDES:
        chain = _chain_from_settings(settings, armature, kind, side)
        if chain is not None:
            chains.append(chain)
    if not chains:
        raise LimbIKError(f"No complete high-confidence {kind.title()} chain is available; Analyze or choose bones manually.")
    _mode_set(context, armature, "POSE")
    return [_build_plan(armature, chain, settings.pole_distance_ratio) for chain in chains]


def _actions_for_id(id_block):
    animation = getattr(id_block, "animation_data", None)
    if animation is None:
        return ()
    actions = []
    if animation.action is not None:
        actions.append(animation.action)
    for track in animation.nla_tracks:
        for strip in track.strips:
            if strip.action is not None:
                actions.append(strip.action)
    return tuple(dict.fromkeys(actions))


def _fcurves_for_action(action):
    if hasattr(action, "fcurves"):
        return tuple(action.fcurves)
    # Blender 4.4+ layered Actions expose channelbags instead of action.fcurves.
    result = []
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            for channelbag in getattr(strip, "channelbags", ()):
                result.extend(channelbag.fcurves)
    return tuple(result)


def _path_mentions_bone(data_path, names):
    return any(f'pose.bones["{name.replace(chr(34), chr(92) + chr(34))}"]' in data_path for name in names)


def _rna_escape(name):
    return name.replace("\\", "\\\\").replace('"', '\\"')


def _owned_constraint_path(pose_bone_name, constraint_name):
    return f'pose.bones["{_rna_escape(pose_bone_name)}"].constraints["{_rna_escape(constraint_name)}"]'


def _constraint_references_controls(constraint, armature, names):
    if getattr(constraint, "target", None) is armature and getattr(constraint, "subtarget", "") in names:
        return True
    if getattr(constraint, "pole_target", None) is armature and getattr(constraint, "pole_subtarget", "") in names:
        return True
    for target in getattr(constraint, "targets", ()):
        if getattr(target, "target", None) is armature and getattr(target, "subtarget", "") in names:
            return True
    return False


def _foreign_dependency_problems(armature, inventory):
    names = {bone.name for bone in inventory["bones"]}
    if not names:
        return []
    owned_constraints = {(armature.as_pointer(), pose_bone.as_pointer(), constraint.as_pointer()) for pose_bone, constraint, _record in inventory["records"]}
    owned_constraint_paths = {
        _owned_constraint_path(pose_bone.name, constraint.name)
        for pose_bone, constraint, _record in inventory["records"]
    }
    problems = []
    for bone in armature.data.bones:
        if bone.name not in names and bone.parent is not None and bone.parent.name in names:
            problems.append(f"bone '{bone.name}' is parented to generated '{bone.parent.name}'")
    for rig_object in (obj for obj in bpy.data.objects if obj.type == "ARMATURE" and obj.pose is not None):
        for pose_bone in rig_object.pose.bones:
            for constraint in pose_bone.constraints:
                if (rig_object.as_pointer(), pose_bone.as_pointer(), constraint.as_pointer()) in owned_constraints:
                    continue
                references = _constraint_references_controls(constraint, armature, names)
                if references or (rig_object is armature and pose_bone.name in names):
                    problems.append(f"foreign constraint '{constraint.name}' on '{rig_object.name}:{pose_bone.name}' references/edits generated controls")
            if not (rig_object is armature and pose_bone.name in names) and pose_bone.custom_shape is not None and _owned(pose_bone.custom_shape, inventory["armature_id"], role="WIDGET"):
                problems.append(f"bone '{rig_object.name}:{pose_bone.name}' uses an owned widget as a foreign Custom Shape")
            if (
                rig_object is armature
                and pose_bone.custom_shape_transform is not None
                and pose_bone.custom_shape_transform.name in names
            ):
                problems.append(f"bone '{rig_object.name}:{pose_bone.name}' uses a generated control as Custom Shape Transform")
    for obj in bpy.data.objects:
        if obj is not armature and obj.parent is armature and obj.parent_type == "BONE" and obj.parent_bone in names:
            problems.append(f"Object '{obj.name}' is bone-parented to generated control '{obj.parent_bone}'")
        for constraint in obj.constraints:
            if _constraint_references_controls(constraint, armature, names):
                problems.append(f"foreign Object constraint '{constraint.name}' on '{obj.name}' references a generated control")
    for id_block in (armature, armature.data):
        for action in _actions_for_id(id_block):
            for fcurve in _fcurves_for_action(action):
                if _path_mentions_bone(fcurve.data_path, names):
                    problems.append(f"Action '{action.name}' animates a generated control")
                    break
                if any(fcurve.data_path.startswith(path) for path in owned_constraint_paths):
                    problems.append(f"Action '{action.name}' animates an owned Limb IK constraint")
                    break
        animation = getattr(id_block, "animation_data", None)
        for fcurve in getattr(animation, "drivers", ()) if animation else ():
            if _path_mentions_bone(fcurve.data_path, names):
                problems.append("a driver writes to a generated control")
            if any(fcurve.data_path.startswith(path) for path in owned_constraint_paths):
                problems.append("a driver writes to an owned Limb IK constraint")
            for variable in fcurve.driver.variables:
                for target in variable.targets:
                    target_path = getattr(target, "data_path", "")
                    if target.id is armature and (
                        getattr(target, "bone_target", "") in names
                        or _path_mentions_bone(target_path, names)
                        or any(target_path.startswith(path) for path in owned_constraint_paths)
                    ):
                        problems.append("a driver reads a generated control")
    for obj in bpy.data.objects:
        animation = obj.animation_data
        for fcurve in getattr(animation, "drivers", ()) if animation else ():
            for variable in fcurve.driver.variables:
                for target in variable.targets:
                    target_path = getattr(target, "data_path", "")
                    if target.id is armature and (
                        getattr(target, "bone_target", "") in names
                        or _path_mentions_bone(target_path, names)
                        or any(target_path.startswith(path) for path in owned_constraint_paths)
                    ):
                        problems.append(f"driver on '{obj.name}' reads a generated control")
    control_collection = next((collection for collection in armature.data.collections if _owned(collection, inventory["armature_id"], role="CONTROL_COLLECTION")), None)
    if control_collection is not None:
        foreign_members = [bone.name for bone in control_collection.bones if bone.name not in names]
        if foreign_members:
            problems.append(f"Randy Controls contains foreign bones: {', '.join(foreign_members[:3])}")
    return sorted(set(problems))


def _removal_resources(context, armature, inventory):
    """Validate every deletion target before the first destructive operation."""
    armature_id = inventory["armature_id"]
    control_collections = [collection for collection in armature.data.collections if _owned(collection, armature_id, role="CONTROL_COLLECTION")]
    if len(control_collections) != 1:
        raise LimbIKError("Owned Randy Controls bone collection is missing or duplicated.")
    expected_bones = {bone.name for bone in inventory["bones"]}
    if {bone.name for bone in control_collections[0].bones} != expected_bones:
        raise LimbIKError("Randy Controls contains missing or foreign bones.")

    widget_collections = [collection for collection in bpy.data.collections if _owned(collection, armature_id, role="WIDGET_COLLECTION")]
    if len(widget_collections) != 1:
        raise LimbIKError("Owned widget collection is missing or duplicated.")
    widget_collection = widget_collections[0]
    if _collection_scene_memberships(widget_collection) != (context.scene,):
        raise LimbIKError("Owned widget collection is linked outside the current Scene.")
    if tuple(widget_collection.children):
        raise LimbIKError("Owned widget collection contains foreign child collections.")
    widget_objects = [obj for obj in bpy.data.objects if _owned(obj, armature_id, role="WIDGET")]
    if set(widget_collection.objects) != set(widget_objects):
        raise LimbIKError("Owned widget collection contains missing or foreign objects.")
    expected_kinds = {"POLE"}
    if any(kind == "ARM" for kind, _side in inventory["rigs"]):
        expected_kinds.add("HAND")
    if any(kind == "LEG" for kind, _side in inventory["rigs"]):
        expected_kinds.add("FOOT")
    if {obj.get(KIND_KEY) for obj in widget_objects} != expected_kinds or len(widget_objects) != len(expected_kinds):
        raise LimbIKError("Owned widget object set does not match the generated Limb rigs.")
    widget_meshes = []
    for obj in widget_objects:
        if tuple(obj.users_collection) != (widget_collection,) or obj.type != "MESH":
            raise LimbIKError(f"Owned widget '{obj.name}' has foreign links or changed type.")
        mesh = obj.data
        if not _owned(mesh, armature_id, role="WIDGET_DATA") or mesh.get(KIND_KEY) != obj.get(KIND_KEY) or mesh.users != 1:
            raise LimbIKError(f"Owned widget data '{mesh.name}' has invalid ownership or foreign users.")
        widget_meshes.append(mesh)
    widget_by_kind = {obj.get(KIND_KEY): obj for obj in widget_objects}
    for (kind, _side), rig in inventory["rigs"].items():
        target_pose = armature.pose.bones[rig["target"].name]
        pole_pose = armature.pose.bones[rig["pole"].name]
        if target_pose.custom_shape is not widget_by_kind["HAND" if kind == "ARM" else "FOOT"] or pole_pose.custom_shape is not widget_by_kind["POLE"]:
            raise LimbIKError(f"Generated {kind.title()} Custom Shape assignment was edited.")
    return {
        "control_collection": control_collections[0],
        "widget_collection": widget_collection,
        "widget_objects": tuple(widget_objects),
        "widget_meshes": tuple(widget_meshes),
    }


def _snapshot_owned_rig(armature, inventory):
    plans = []
    control_pose = {}
    for (kind, side), rig in sorted(inventory["rigs"].items()):
        target = rig["target"]
        pole = rig["pole"]
        upper = armature.pose.bones[rig["chain"][0]]
        lower = armature.pose.bones[rig["chain"][1]]
        end_bone = armature.pose.bones[rig["chain"][2]]
        ik = next(constraint for _pose_bone, constraint, record in rig["entries"] if record["role"] == "IK")
        plans.append(
            LimbPlan(
                chain=LimbChain(kind, side, *rig["chain"]),
                rig_id=rig["rig_id"],
                target_name=target.name,
                pole_name=pole.name,
                start=Vector(upper.head),
                joint=Vector(lower.head),
                end=Vector(lower.tail),
                target_head=Vector(target.head_local),
                target_tail=Vector(target.tail_local),
                target_z=Vector(target.matrix_local.col[2][:3]),
                pole_head=Vector(pole.head_local),
                pole_tail=Vector(pole.tail_local),
                pole_angle=float(ik.pole_angle),
                pole_warning="",
                desired_upper_matrix=upper.matrix.copy(),
                desired_lower_matrix=lower.matrix.copy(),
                desired_end_matrix=end_bone.matrix.copy(),
                target_basis=armature.pose.bones[target.name].matrix_basis.copy(),
                pole_basis=armature.pose.bones[pole.name].matrix_basis.copy(),
            )
        )
        for name in (target.name, pole.name):
            pose_bone = armature.pose.bones[name]
            control_pose[name] = {
                "matrix_basis": pose_bone.matrix_basis.copy(),
                "rotation_mode": pose_bone.rotation_mode,
            }
    return {"armature_id": inventory["armature_id"], "plans": plans, "control_pose": control_pose}


def _purge_snapshot_owned(context, armature, snapshot):
    """Best-effort exact cleanup used only before transactional recovery."""
    rig_ids = {plan.rig_id for plan in snapshot["plans"]}
    constraint_names = {_constraint_name(rig_id, role) for rig_id in rig_ids for role in ("IK", "END_ROTATION")}
    _mode_set(context, armature, "POSE")
    for pose_bone in armature.pose.bones:
        registry = _constraint_registry(pose_bone, strict=False)
        for constraint in tuple(pose_bone.constraints):
            if constraint.name in constraint_names:
                name = constraint.name
                pose_bone.constraints.remove(constraint)
                registry.pop(name, None)
        _write_constraint_registry(pose_bone, registry)
    _mode_set(context, armature, "EDIT")
    for plan in snapshot["plans"]:
        for name in (plan.target_name, plan.pole_name):
            bone = armature.data.edit_bones.get(name)
            if bone is not None:
                armature.data.edit_bones.remove(bone)
    _mode_set(context, armature, "OBJECT")
    armature_id = snapshot["armature_id"]
    for obj in tuple(bpy.data.objects):
        if _owned(obj, armature_id, role="WIDGET"):
            bpy.data.objects.remove(obj, do_unlink=True)
    for mesh in tuple(bpy.data.meshes):
        if _owned(mesh, armature_id, role="WIDGET_DATA") and not mesh.users:
            bpy.data.meshes.remove(mesh)
    for collection in tuple(bpy.data.collections):
        if _owned(collection, armature_id, role="WIDGET_COLLECTION"):
            bpy.data.collections.remove(collection)
    for collection in tuple(armature.data.collections):
        if _owned(collection, armature_id, role="CONTROL_COLLECTION"):
            armature.data.collections.remove(collection)
    if ARMATURE_ID_KEY in armature.data:
        del armature.data[ARMATURE_ID_KEY]


def _restore_owned_snapshot(context, armature, snapshot):
    _purge_snapshot_owned(context, armature, snapshot)
    armature.data[ARMATURE_ID_KEY] = snapshot["armature_id"]
    transaction = None
    try:
        _mode_set(context, armature, "POSE")
        _built, transaction = _build_plans(context, armature, snapshot["plans"])
        for name, state in snapshot["control_pose"].items():
            pose_bone = armature.pose.bones[name]
            pose_bone.rotation_mode = state["rotation_mode"]
            pose_bone.matrix_basis = state["matrix_basis"]
        context.view_layer.update()
        _validate_inventory(armature)
        return transaction
    except Exception:
        if transaction is not None:
            _rollback_build(context, armature, transaction)
        if ARMATURE_ID_KEY in armature.data:
            del armature.data[ARMATURE_ID_KEY]
        raise


def _remove_owned(context, armature, *, refuse_dependencies=True):
    inventory = _validate_inventory(armature)
    if not inventory["rigs"]:
        raise LimbIKError("No exactly tagged Limb IK rig exists on the active Armature.")
    if refuse_dependencies:
        problems = _foreign_dependency_problems(armature, inventory)
        if problems:
            raise LimbIKError(f"Remove Generated Rig was refused: {problems[0]}.")
    resources = _removal_resources(context, armature, inventory)
    armature_id = inventory["armature_id"]
    removed_constraints = 0
    _mode_set(context, armature, "POSE")
    for pose_bone, constraint, _record in reversed(inventory["records"]):
        registry = _constraint_registry(pose_bone, strict=True)
        name = constraint.name
        pose_bone.constraints.remove(constraint)
        registry.pop(name, None)
        _write_constraint_registry(pose_bone, registry)
        removed_constraints += 1
    _mode_set(context, armature, "EDIT")
    removed_bones = 0
    for name in [bone.name for bone in inventory["bones"]]:
        edit_bone = armature.data.edit_bones.get(name)
        if edit_bone is not None:
            armature.data.edit_bones.remove(edit_bone)
            removed_bones += 1
    _mode_set(context, armature, "OBJECT")

    widget_objects = resources["widget_objects"]
    widget_meshes = resources["widget_meshes"]
    for obj in widget_objects:
        bpy.data.objects.remove(obj, do_unlink=True)
    for mesh in widget_meshes:
        if not mesh.users:
            bpy.data.meshes.remove(mesh)
    bpy.data.collections.remove(resources["widget_collection"])
    armature.data.collections.remove(resources["control_collection"])
    if ARMATURE_ID_KEY in armature.data:
        del armature.data[ARMATURE_ID_KEY]
    return {"constraints": removed_constraints, "bones": removed_bones, "widgets": len(widget_objects)}


def _execute_build(operator, context, kind):
    settings = _settings(context)
    armature = None
    snapshot = None
    transaction = None
    built = ()
    error = None
    try:
        armature = _require_active_armature(context, settings)
        snapshot = _capture_context(context, armature)
        plans = _plans_for_kind(context, armature, settings, kind)
        built, transaction = _build_plans(context, armature, plans)
    except (LimbIKError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
        error = exc
    if snapshot is not None and armature is not None:
        try:
            _restore_context(context, armature, snapshot)
        except (LimbIKError, ReferenceError, RuntimeError) as restore_exc:
            if transaction is not None:
                rollback_errors = _rollback_build(context, armature, transaction)
                try:
                    _restore_context(context, armature, snapshot)
                except (LimbIKError, ReferenceError, RuntimeError) as second_restore:
                    rollback_errors.append(str(second_restore))
                suffix = f" Rollback also reported: {'; '.join(rollback_errors)}" if rollback_errors else ""
                error = LimbIKError(f"Context restoration failed, so the generated rig was rolled back: {restore_exc}.{suffix}")
            elif error is None:
                error = LimbIKError(f"Limb IK context restoration failed: {restore_exc}")
    if error is not None:
        message = str(error)
        level = "ERROR" if "rollback" in message.lower() or "restoration" in message.lower() else "WARNING"
        _set_status(settings, level, message)
        operator.report({"ERROR" if level == "ERROR" else "WARNING"}, message)
        return {"CANCELLED"}
    warnings = [plan.pole_warning for plan in built if plan.pole_warning]
    message = f"Built {len(built)} {kind.title()} IK side{'s' if len(built) != 1 else ''}; targets, Poles, IK(2), and end rotation are ready."
    if warnings:
        message += " " + " ".join(warnings)
    _set_status(settings, "WARNING" if warnings else "SUCCESS", message)
    operator.report({"WARNING" if warnings else "INFO"}, message)
    return {"FINISHED"}


class CHARACTERDESIGNER_OT_limb_ik_build_arm(Operator):
    bl_idname = "character_designer.limb_ik_build_arm"
    bl_label = "Build Arm Rig"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        return context.object is not None and context.object.type == "ARMATURE" and settings is not None

    def execute(self, context):
        return _execute_build(self, context, "ARM")


class CHARACTERDESIGNER_OT_limb_ik_build_leg(Operator):
    bl_idname = "character_designer.limb_ik_build_leg"
    bl_label = "Build Leg Rig"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        return context.object is not None and context.object.type == "ARMATURE" and settings is not None

    def execute(self, context):
        return _execute_build(self, context, "LEG")


class CHARACTERDESIGNER_OT_limb_ik_remove(Operator):
    bl_idname = "character_designer.limb_ik_remove"
    bl_label = "Remove Generated Rig"
    bl_options = {"REGISTER", "UNDO"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        settings = _settings(context)
        armature = None
        context_snapshot = None
        rig_snapshot = None
        summary = None
        error = None
        removal_attempted = False
        try:
            armature = _require_active_armature(context, settings, analyzed=False)
            context_snapshot = _capture_context(context, armature)
            inventory = _validate_inventory(armature)
            _removal_resources(context, armature, inventory)
            problems = _foreign_dependency_problems(armature, inventory)
            if problems:
                raise LimbIKError(f"Remove Generated Rig was refused: {problems[0]}.")
            rig_snapshot = _snapshot_owned_rig(armature, inventory)
            removal_attempted = True
            summary = _remove_owned(context, armature, refuse_dependencies=False)
        except (LimbIKError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
            error = exc
            if removal_attempted and rig_snapshot is not None:
                try:
                    _restore_owned_snapshot(context, armature, rig_snapshot)
                except Exception as recovery_exc:
                    error = LimbIKError(f"{exc} Recovery also failed: {recovery_exc}")
        if context_snapshot is not None and armature is not None:
            try:
                _restore_context(context, armature, context_snapshot)
            except (LimbIKError, ReferenceError, RuntimeError) as restore_exc:
                if error is None and rig_snapshot is not None:
                    try:
                        _restore_owned_snapshot(context, armature, rig_snapshot)
                        _restore_context(context, armature, context_snapshot)
                        error = LimbIKError(f"Remove was rolled back because context restoration failed: {restore_exc}")
                    except Exception as recovery_exc:
                        error = LimbIKError(f"Context restoration failed after Remove, and rig recovery also failed: {recovery_exc}")
                elif error is None:
                    error = restore_exc
        if error is not None:
            message = str(error)
            level = "ERROR" if "Recovery also failed" in message or "recovery also failed" in message else "WARNING"
            _set_status(settings, level, message)
            self.report({"ERROR" if level == "ERROR" else "WARNING"}, message)
            return {"CANCELLED"}
        settings.analysis_json = ""
        message = f"Removed {summary['bones']} controls, {summary['constraints']} constraints, and {summary['widgets']} widgets. Analyze again before rebuilding."
        _set_status(settings, "SUCCESS", message)
        self.report({"INFO"}, message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_limb_ik_rebuild(Operator):
    bl_idname = "character_designer.limb_ik_rebuild"
    bl_label = "Rebuild Rig"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = _settings(context)
        armature = None
        context_snapshot = None
        rig_snapshot = None
        new_transaction = None
        rebuilt = ()
        error = None
        removal_attempted = False
        try:
            armature = _require_active_armature(context, settings)
            context_snapshot = _capture_context(context, armature)
            inventory = _validate_inventory(armature)
            kinds = sorted({kind for kind, _side in inventory["rigs"]})
            if not kinds:
                raise LimbIKError("No generated Limb IK rig exists to rebuild.")
            _removal_resources(context, armature, inventory)
            problems = _foreign_dependency_problems(armature, inventory)
            if problems:
                raise LimbIKError(f"Rebuild Rig was refused: {problems[0]}.")
            rig_snapshot = _snapshot_owned_rig(armature, inventory)
            plans = []
            for kind in kinds:
                plans.extend(_plans_for_kind(context, armature, settings, kind))
            removal_attempted = True
            _remove_owned(context, armature)
            _mode_set(context, armature, "POSE")
            rebuilt, new_transaction = _build_plans(context, armature, plans)
        except (LimbIKError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
            error = exc
            if new_transaction is not None:
                _rollback_build(context, armature, new_transaction)
                new_transaction = None
            if removal_attempted and rig_snapshot is not None:
                try:
                    _restore_owned_snapshot(context, armature, rig_snapshot)
                except Exception as recovery_exc:
                    error = LimbIKError(f"{exc} Old-rig recovery also failed: {recovery_exc}")
        if context_snapshot is not None and armature is not None:
            try:
                _restore_context(context, armature, context_snapshot)
            except (LimbIKError, ReferenceError, RuntimeError) as restore_exc:
                if error is None and rig_snapshot is not None:
                    try:
                        if new_transaction is not None:
                            _rollback_build(context, armature, new_transaction)
                            new_transaction = None
                        _restore_owned_snapshot(context, armature, rig_snapshot)
                        _restore_context(context, armature, context_snapshot)
                        error = LimbIKError(f"Rebuild was rolled back because context restoration failed: {restore_exc}")
                    except Exception as recovery_exc:
                        error = LimbIKError(f"Rebuild context restoration failed, and old-rig recovery also failed: {recovery_exc}")
                elif error is None:
                    error = restore_exc
        if error is not None:
            message = str(error)
            _set_status(settings, "ERROR", message)
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        message = f"Rebuilt {len(rebuilt)} Limb IK sides from the current analyzed chains."
        _set_status(settings, "SUCCESS", message)
        self.report({"INFO"}, message)
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_limb_ik_flip_pole(Operator):
    bl_idname = "character_designer.limb_ik_flip_pole"
    bl_label = "Flip Pole"
    bl_options = {"REGISTER", "UNDO"}

    kind: EnumProperty(items=(("ARM", "Arm", ""), ("LEG", "Leg", "")))
    side: EnumProperty(items=(("L", "Left", ""), ("R", "Right", "")))

    def execute(self, context):
        settings = _settings(context)
        try:
            armature = _require_active_armature(context, settings, analyzed=False)
            rig = _validate_inventory(armature)["rigs"].get((self.kind, self.side))
            if rig is None:
                raise LimbIKError(f"No generated {self.side} {self.kind.title()} rig exists.")
            ik = next(constraint for _pb, constraint, record in rig["entries"] if record["role"] == "IK")
            ik.pole_angle = math.remainder(ik.pole_angle + math.pi, math.tau)
            message = f"Flipped {self.side} {self.kind.title()} Pole solution by 180°."
            _set_status(settings, "SUCCESS", message)
            self.report({"INFO"}, message)
            return {"FINISHED"}
        except (LimbIKError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
            _set_status(settings, "WARNING", str(exc))
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}


def _draw_status(layout, settings):
    if not settings.last_message:
        return
    icon = {"SUCCESS": "CHECKMARK", "WARNING": "INFO", "ERROR": "ERROR"}.get(settings.last_level, "INFO")
    box = layout.box()
    for index, line in enumerate(textwrap.wrap(settings.last_message, width=48, break_long_words=False) or [settings.last_message]):
        row = box.row()
        row.alert = settings.last_level == "ERROR"
        row.label(text=line, icon=icon if index == 0 else "NONE")


def _draw_limb_side(layout, settings, armature, kind, side):
    label = f"{'LEFT' if side == 'L' else 'RIGHT'} {kind}"
    box = layout.box()
    box.label(text=label, icon="BONE_DATA")
    result = {}
    try:
        payload = json.loads(settings.analysis_json) if settings.analysis_json else {}
        result = payload.get("limbs", {}).get(kind, {}).get(side, {})
    except (TypeError, ValueError, json.JSONDecodeError):
        pass
    status = result.get("status", "NOT ANALYZED")
    box.label(text=status.replace("_", " ").title(), icon="CHECKMARK" if status == "READY" else "INFO")
    for role in ROLES:
        property_name = _field_name(kind, side, role)
        if armature is not None:
            box.prop_search(settings, property_name, armature.data, "bones", text=role.title())
        else:
            box.prop(settings, property_name, text=role.title())
    if result.get("warning"):
        for line in textwrap.wrap(result["warning"], width=42, break_long_words=False):
            box.label(text=line, icon="INFO")
    built = False
    if armature is not None and armature.type == "ARMATURE":
        armature_id = armature.data.get(ARMATURE_ID_KEY, "")
        target = armature.data.bones.get(LIMB_SPEC[kind]["target"].format(side=side))
        pole = armature.data.bones.get(LIMB_SPEC[kind]["pole"].format(side=side))
        built = bool(
            armature_id
            and target is not None
            and pole is not None
            and _owned(target, armature_id, role=LIMB_SPEC[kind]["target_role"])
            and _owned(pole, armature_id, role="POLE")
        )
    if status == "WARNING" and built:
        row = box.row(align=True)
        operator = row.operator("character_designer.limb_ik_flip_pole", text="Flip Pole", icon="ARROW_LEFTRIGHT")
        operator.kind = kind
        operator.side = side


class CHARACTERDESIGNER_PT_limb_ik(Panel):
    bl_label = "Limb IK"
    bl_idname = "CHARACTERDESIGNER_PT_limb_ik"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = SIDEBAR_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return active_ui_page(context) == UI_PAGE_RIG

    def draw(self, context):
        layout = self.layout
        settings = _settings(context)
        if settings is None:
            layout.label(text="Limb IK state is unavailable.", icon="ERROR")
            return
        layout.label(text="Randy Rig", icon="ARMATURE_DATA")
        layout.operator("character_designer.limb_ik_analyze", text="Analyze Rig", icon="VIEWZOOM")
        armature = settings.armature
        for kind in KINDS:
            for side in SIDES:
                _draw_limb_side(layout, settings, armature, kind, side)
            layout.operator(
                f"character_designer.limb_ik_build_{kind.lower()}",
                text=f"Build {kind.title()} Rig",
                icon="CON_KINEMATIC",
            )
        layout.prop(settings, "pole_distance_ratio")
        row = layout.row(align=True)
        row.operator("character_designer.limb_ik_rebuild", text="Rebuild Rig", icon="FILE_REFRESH")
        remove = row.row(align=True)
        remove.alert = True
        remove.operator("character_designer.limb_ik_remove", text="Remove Generated Rig", icon="TRASH")
        _draw_status(layout, settings)


LIMB_IK_CLASSES = (
    CharacterDesignerLimbIKState,
    CHARACTERDESIGNER_OT_limb_ik_analyze,
    CHARACTERDESIGNER_OT_limb_ik_build_arm,
    CHARACTERDESIGNER_OT_limb_ik_build_leg,
    CHARACTERDESIGNER_OT_limb_ik_remove,
    CHARACTERDESIGNER_OT_limb_ik_rebuild,
    CHARACTERDESIGNER_OT_limb_ik_flip_pole,
    CHARACTERDESIGNER_PT_limb_ik,
)


__all__ = (
    "CharacterDesignerLimbIKState",
    "LIMB_IK_CLASSES",
    "LimbIKError",
    "analyze_armature",
)
