SIDEBAR_CATEGORY = "Character Designer"
