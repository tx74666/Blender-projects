"""Transactional Spline IK rig setup for a selected Armature bone chain."""

import json
import textwrap
import uuid

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Matrix, Vector

from .ui_constants import SIDEBAR_CATEGORY


OWNER_KEY = "character_designer_owner"
OWNER_VALUE = "spline_ik_setup"
VERSION_KEY = "character_designer_spline_ik_version"
RIG_ID_KEY = "character_designer_spline_ik_rig_id"
ROLE_KEY = "character_designer_spline_ik_role"
CHAIN_KEY = "character_designer_spline_ik_chain"
ARMATURE_KEY = "character_designer_spline_ik_armature"
CONTROL_INDEX_KEY = "character_designer_spline_ik_control_index"
CONSTRAINT_REGISTRY_KEY = "character_designer_spline_ik_constraints"
HOOK_REGISTRY_KEY = "character_designer_spline_ik_hooks"
RIG_VERSION = 1
EPSILON = 1.0e-8


class SplineIKSetupError(ValueError):
    """An actionable rig-setup problem that can be shown to the artist."""


def _armature_poll(_self, obj):
    return obj is not None and obj.type == "ARMATURE"


def _settings(context):
    manager = getattr(context, "window_manager", None)
    return getattr(manager, "character_designer_spline_ik", None)


def _set_status(settings, level, message):
    if settings is None:
        return
    settings.last_level = level
    settings.last_message = message


def _canonical_chain_json(names):
    return json.dumps(list(names), ensure_ascii=False, separators=(",", ":"))


def _captured_names(settings):
    if settings is None or not settings.chain_names_json:
        return ()
    try:
        payload = json.loads(settings.chain_names_json)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise SplineIKSetupError("The captured bone chain is corrupt; capture it again.") from exc
    if (
        not isinstance(payload, list)
        or len(payload) < 2
        or any(not isinstance(name, str) or not name for name in payload)
        or len(set(payload)) != len(payload)
    ):
        raise SplineIKSetupError("The captured bone chain is invalid; capture it again.")
    return tuple(payload)


def _selected_chain(context):
    armature = context.object
    if armature is None or armature.type != "ARMATURE":
        raise SplineIKSetupError("Select one Armature and enter Pose or Armature Edit Mode.")

    if context.mode == "POSE":
        selected = tuple(context.selected_pose_bones or ())
        selected_names = {pose_bone.name for pose_bone in selected}
        bones = armature.data.bones
    elif context.mode == "EDIT_ARMATURE":
        selected = tuple(context.selected_editable_bones or ())
        selected_names = {edit_bone.name for edit_bone in selected if edit_bone.select}
        bones = armature.data.edit_bones
    else:
        raise SplineIKSetupError("Enter Pose or Armature Edit Mode and select one bone chain.")

    if len(selected_names) < 2:
        raise SplineIKSetupError("Select at least two parent-child bones.")

    selected_bones = {name: bones.get(name) for name in selected_names}
    if any(bone is None for bone in selected_bones.values()):
        raise SplineIKSetupError("The selected bones could not be resolved on the active Armature.")

    roots = [
        bone
        for bone in selected_bones.values()
        if bone.parent is None or bone.parent.name not in selected_names
    ]
    if len(roots) != 1:
        raise SplineIKSetupError("Select one continuous parent-child chain with a single root.")

    ordered = []
    current = roots[0]
    while current is not None:
        ordered.append(current.name)
        selected_children = [
            child for child in current.children if child.name in selected_names
        ]
        if len(selected_children) > 1:
            raise SplineIKSetupError("The selected chain branches; select only one path.")
        current = selected_children[0] if selected_children else None

    if len(ordered) != len(selected_names):
        raise SplineIKSetupError("The selected bones contain a gap or a disconnected branch.")
    return armature, tuple(ordered)


def _chain_bones(armature, names):
    if armature is None or armature.type != "ARMATURE":
        raise SplineIKSetupError("The captured Armature is no longer available.")
    bones = armature.data.edit_bones if armature.mode == "EDIT" else armature.data.bones
    resolved = []
    for name in names:
        bone = bones.get(name)
        if bone is None:
            raise SplineIKSetupError(f"Bone '{name}' no longer exists; capture the chain again.")
        resolved.append(bone)
    for parent, child in zip(resolved, resolved[1:]):
        if child.parent is None or child.parent.name != parent.name:
            raise SplineIKSetupError("The captured parent-child chain changed; capture it again.")
    return tuple(resolved)


def _chain_geometry(armature, names):
    bones = _chain_bones(armature, names)
    joints = [Vector(bones[0].head)]
    joints.extend(Vector(bone.tail) for bone in bones)
    total_bone_length = sum((Vector(bone.tail) - Vector(bone.head)).length for bone in bones)
    if total_bone_length <= EPSILON:
        raise SplineIKSetupError("The selected chain has no usable length.")
    if sum((right - left).length for left, right in zip(joints, joints[1:])) <= EPSILON:
        raise SplineIKSetupError("The selected chain joints collapse to one point.")
    return bones, tuple(joints), total_bone_length


def _sample_polyline(points, count):
    segments = []
    total = 0.0
    for left, right in zip(points, points[1:]):
        length = (right - left).length
        if length > EPSILON:
            segments.append((total, total + length, left, right))
            total += length
    if total <= EPSILON:
        raise SplineIKSetupError("The selected chain joints collapse to one point.")

    samples = []
    segment_index = 0
    for index in range(count):
        target = total * index / (count - 1)
        while segment_index < len(segments) - 1 and target > segments[segment_index][1]:
            segment_index += 1
        start_distance, end_distance, left, right = segments[segment_index]
        span = end_distance - start_distance
        factor = 0.0 if span <= EPSILON else (target - start_distance) / span
        samples.append(left.lerp(right, max(0.0, min(1.0, factor))))
    samples[0] = points[0].copy()
    samples[-1] = points[-1].copy()
    return tuple(samples)


def _point_tangent(points, index):
    if index == 0:
        tangent = points[1] - points[0]
    elif index == len(points) - 1:
        tangent = points[-1] - points[-2]
    else:
        tangent = points[index + 1] - points[index - 1]
    if tangent.length <= EPSILON:
        raise SplineIKSetupError("Two generated control points occupy the same position.")
    return tangent.normalized()


def _set_tags(target, rig_id, role, armature, chain_names, *, control_index=None):
    target[OWNER_KEY] = OWNER_VALUE
    target[VERSION_KEY] = RIG_VERSION
    target[RIG_ID_KEY] = rig_id
    target[ROLE_KEY] = role
    target[CHAIN_KEY] = _canonical_chain_json(chain_names)
    target[ARMATURE_KEY] = armature.name
    if control_index is not None:
        target[CONTROL_INDEX_KEY] = int(control_index)


def _tagged_chain(target):
    try:
        payload = json.loads(target.get(CHAIN_KEY, ""))
    except (AttributeError, ReferenceError, TypeError, ValueError, json.JSONDecodeError):
        return ()
    if not isinstance(payload, list) or any(not isinstance(name, str) for name in payload):
        return ()
    return tuple(payload)


def _is_owned(
    target,
    *,
    rig_id=None,
    role=None,
    armature=None,
    chain_names=None,
):
    try:
        if target.get(OWNER_KEY) != OWNER_VALUE or target.get(VERSION_KEY) != RIG_VERSION:
            return False
        if rig_id is not None and target.get(RIG_ID_KEY) != rig_id:
            return False
        if role is not None and target.get(ROLE_KEY) != role:
            return False
        if armature is not None and target.get(ARMATURE_KEY) != armature.name:
            return False
        if chain_names is not None and _tagged_chain(target) != tuple(chain_names):
            return False
    except (AttributeError, ReferenceError):
        return False
    return True


def _scene_memberships(obj):
    return tuple(
        scene
        for scene in bpy.data.scenes
        if scene.objects.get(obj.name) is obj
    )


def _collection_scene_memberships(collection):
    memberships = []
    for scene in bpy.data.scenes:
        if scene.collection is collection or collection in scene.collection.children_recursive:
            memberships.append(scene)
    return tuple(memberships)


def _require_current_scene(context, armature):
    if armature is None or armature.type != "ARMATURE":
        raise SplineIKSetupError("The captured Armature is no longer available.")
    memberships = _scene_memberships(armature)
    if len(memberships) != 1 or memberships[0] is not context.scene:
        raise SplineIKSetupError(
            "The captured Armature must belong only to the current Scene."
        )
    if context.view_layer.objects.get(armature.name) is not armature:
        raise SplineIKSetupError(
            "The captured Armature is excluded from the current View Layer."
        )


def _require_generated_object_scene(context, obj):
    memberships = _scene_memberships(obj)
    if len(memberships) != 1 or memberships[0] is not context.scene:
        raise SplineIKSetupError(
            f"Generated object '{obj.name}' does not belong only to the current Scene."
        )
    for collection in obj.users_collection:
        collection_scenes = _collection_scene_memberships(collection)
        if len(collection_scenes) != 1 or collection_scenes[0] is not context.scene:
            raise SplineIKSetupError(
                f"Generated object '{obj.name}' is linked through a cross-Scene collection."
            )


def _constraint_registry(pose_bone, *, strict=False):
    raw = pose_bone.get(CONSTRAINT_REGISTRY_KEY, "")
    if not raw:
        return {}
    try:
        payload = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        if strict:
            raise SplineIKSetupError(
                f"Spline IK ownership registry on bone '{pose_bone.name}' is corrupt."
            ) from exc
        return {}
    if not isinstance(payload, dict):
        if strict:
            raise SplineIKSetupError(
                f"Spline IK ownership registry on bone '{pose_bone.name}' is invalid."
            )
        return {}
    return payload


def _write_constraint_registry(pose_bone, registry):
    if registry:
        pose_bone[CONSTRAINT_REGISTRY_KEY] = json.dumps(
            registry,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    elif CONSTRAINT_REGISTRY_KEY in pose_bone:
        del pose_bone[CONSTRAINT_REGISTRY_KEY]


def _constraint_name(rig_id):
    return f"CDSplineIK_{rig_id}"


def _tag_constraint(pose_bone, constraint, rig_id, armature, chain_names):
    # Blender 5.2 Constraint RNA does not support ID properties. Keep the
    # versioned custom-property ownership record on its owning PoseBone, keyed
    # by an unguessable exact constraint name, and cross-check the tagged target.
    # Never reinterpret or overwrite malformed artist/project data. A corrupt
    # registry must be repaired explicitly before any new owned entry is made.
    registry = _constraint_registry(pose_bone, strict=True)
    constraint.name = _constraint_name(rig_id)
    registry[constraint.name] = {
        "owner": OWNER_VALUE,
        "version": RIG_VERSION,
        "rig_id": rig_id,
        "role": "SPLINE_IK_CONSTRAINT",
        "armature": armature.name,
        "chain": list(chain_names),
    }
    _write_constraint_registry(pose_bone, registry)


def _constraint_record(pose_bone, constraint, armature, chain_names=None):
    record = _constraint_registry(pose_bone).get(constraint.name)
    if not isinstance(record, dict):
        return None
    rig_id = record.get("rig_id")
    if (
        constraint.type != "SPLINE_IK"
        or not isinstance(rig_id, str)
        or not rig_id
        or constraint.name != _constraint_name(rig_id)
        or record.get("owner") != OWNER_VALUE
        or record.get("version") != RIG_VERSION
        or record.get("role") != "SPLINE_IK_CONSTRAINT"
        or record.get("armature") != armature.name
        or not isinstance(record.get("chain"), list)
        or any(not isinstance(name, str) for name in record.get("chain", ()))
        or (chain_names is not None and tuple(record.get("chain", ())) != tuple(chain_names))
    ):
        return None
    target = constraint.target
    if (
        target is None
        or target.type != "CURVE"
        or target.parent is not armature
        or not _is_owned(
            target,
            rig_id=rig_id,
            role="CURVE",
            armature=armature,
            chain_names=record["chain"],
        )
        or target.data is None
        or not _is_owned(
            target.data,
            rig_id=rig_id,
            role="CURVE_DATA",
            armature=armature,
            chain_names=record["chain"],
        )
    ):
        return None
    return record


def _remove_constraint(pose_bone, constraint):
    name = constraint.name
    registry = _constraint_registry(pose_bone, strict=True)
    pose_bone.constraints.remove(constraint)
    registry.pop(name, None)
    _write_constraint_registry(pose_bone, registry)


def _owned_constraints(armature, *, rig_id=None, chain_names=None):
    matches = []
    pose = getattr(armature, "pose", None)
    if pose is None:
        return matches
    for pose_bone in pose.bones:
        for constraint in pose_bone.constraints:
            record = _constraint_record(pose_bone, constraint, armature, chain_names)
            if record is None:
                continue
            if rig_id is not None and record.get("rig_id") != rig_id:
                continue
            if chain_names is not None and tuple(record.get("chain", ())) != tuple(chain_names):
                continue
            matches.append((pose_bone, constraint))
    return matches


def _resolved_rig_id(settings, armature, names):
    requested = settings.active_rig_id if settings is not None else ""
    if requested:
        matches = _owned_constraints(armature, rig_id=requested, chain_names=names)
        if len(matches) == 1:
            return requested
    matches = _owned_constraints(armature, chain_names=names)
    rig_ids = {
        _constraint_record(pose_bone, constraint, armature, names).get("rig_id", "")
        for pose_bone, constraint in matches
    }
    rig_ids.discard("")
    return next(iter(rig_ids)) if len(rig_ids) == 1 else ""


def _target_collection(context, armature):
    candidates = []
    for collection in armature.users_collection:
        memberships = _collection_scene_memberships(collection)
        if len(memberships) == 1 and memberships[0] is context.scene:
            candidates.append(collection)
    active = getattr(context, "collection", None)
    if active in candidates:
        return active
    if candidates:
        return sorted(candidates, key=lambda collection: collection.name)[0]
    raise SplineIKSetupError(
        "No Armature collection belongs exclusively to the current Scene."
    )


def _local_controller_matrix(position, tangent):
    try:
        rotation = tangent.to_track_quat("Y", "Z").to_matrix().to_4x4()
    except ValueError as exc:
        raise SplineIKSetupError("A controller orientation could not be derived.") from exc
    return Matrix.Translation(position) @ rotation


def _create_curve_and_controls(
    context,
    armature,
    chain_names,
    samples,
    control_size,
    rig_id,
    created_objects,
    created_curves,
):
    base_name = f"{armature.name}_SplineIK"
    collection = _target_collection(context, armature)

    curve_data = bpy.data.curves.new(f"{base_name}_Curve", type="CURVE")
    created_curves.append(curve_data)
    curve_data.dimensions = "3D"
    curve_data.resolution_u = 12
    curve_data.render_resolution_u = 12
    curve_data.twist_mode = "MINIMUM"
    _set_tags(curve_data, rig_id, "CURVE_DATA", armature, chain_names)

    spline = curve_data.splines.new(type="BEZIER")
    spline.bezier_points.add(len(samples) - 1)
    spline.resolution_u = 12
    for index, (point, position) in enumerate(zip(spline.bezier_points, samples)):
        tangent = _point_tangent(samples, index)
        left_span = (
            (samples[index] - samples[index - 1]).length
            if index > 0
            else (samples[1] - samples[0]).length
        )
        right_span = (
            (samples[index + 1] - samples[index]).length
            if index < len(samples) - 1
            else (samples[-1] - samples[-2]).length
        )
        point.co = position
        point.handle_left_type = "FREE"
        point.handle_right_type = "FREE"
        point.handle_left = position - tangent * (left_span / 3.0)
        point.handle_right = position + tangent * (right_span / 3.0)

    curve_obj = bpy.data.objects.new(f"{base_name}_Curve", curve_data)
    created_objects.append(curve_obj)
    collection.objects.link(curve_obj)
    curve_obj.parent = armature
    curve_obj.matrix_parent_inverse = Matrix.Identity(4)
    curve_obj.matrix_basis = Matrix.Identity(4)
    curve_obj.display_type = "WIRE"
    curve_obj.show_in_front = True
    _set_tags(curve_obj, rig_id, "CURVE", armature, chain_names)

    controls = []
    for index, position in enumerate(samples):
        tangent = _point_tangent(samples, index)
        control = bpy.data.objects.new(f"{base_name}_CTRL_{index + 1:02d}", None)
        created_objects.append(control)
        collection.objects.link(control)
        control.parent = armature
        control.matrix_parent_inverse = Matrix.Identity(4)
        control.matrix_basis = _local_controller_matrix(position, tangent)
        control.empty_display_type = "CUBE" if index in {0, len(samples) - 1} else "SPHERE"
        control.empty_display_size = control_size
        control.display_type = "WIRE"
        control.show_in_front = True
        _set_tags(
            control,
            rig_id,
            "CONTROL",
            armature,
            chain_names,
            control_index=index,
        )
        controls.append(control)

    context.view_layer.update()
    for index, control in enumerate(controls):
        hook = curve_obj.modifiers.new(
            f"CDSplineIK_Hook_{rig_id}_{index + 1:02d}",
            type="HOOK",
        )
        hook.object = control
        hook.falloff_type = "NONE"
        hook.strength = 1.0
        if not hasattr(hook, "vertex_indices_set"):
            raise SplineIKSetupError("This Blender build cannot bind Curve Hook indices.")
        hook.vertex_indices_set((index * 3, index * 3 + 1, index * 3 + 2))
        try:
            hook.matrix_inverse = control.matrix_world.inverted() @ curve_obj.matrix_world
        except ValueError as exc:
            raise SplineIKSetupError(
                "The Armature transform is singular; remove zero object scale before building."
            ) from exc
    # Modifiers, like Constraints, do not support ID custom properties in
    # Blender 5.2. Their exact names and targets are therefore registered on
    # their already UUID-tagged owning Curve object.
    curve_obj[HOOK_REGISTRY_KEY] = json.dumps(
        [
            {
                "name": modifier.name,
                "owner": OWNER_VALUE,
                "version": RIG_VERSION,
                "rig_id": rig_id,
                "role": "HOOK",
                "control_index": index,
                "target": controls[index].name,
            }
            for index, modifier in enumerate(curve_obj.modifiers)
        ],
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )

    return curve_obj, tuple(controls)


def _configure_constraint(constraint, curve_obj, chain_count):
    constraint.target = curve_obj
    constraint.chain_count = chain_count
    # NONE explicitly prevents the Spline IK constraint from introducing any
    # additional Y-axis scaling into the already-authored bone transforms.
    constraint.y_scale_mode = "NONE"
    constraint.xz_scale_mode = "NONE"
    constraint.use_curve_radius = False
    constraint.use_even_divisions = False
    constraint.use_chain_offset = False
    constraint.mute = False
    constraint.influence = 1.0


_SPLINE_IK_SNAPSHOT_PROPERTIES = (
    "owner_space",
    "target_space",
    "space_object",
    "space_subtarget",
    "mute",
    "show_expanded",
    "active",
    "influence",
    "target",
    "chain_count",
    "use_chain_offset",
    "use_even_divisions",
    "use_curve_radius",
    "xz_scale_mode",
    "y_scale_mode",
    "use_original_scale",
    "bulge",
    "use_bulge_min",
    "use_bulge_max",
    "bulge_min",
    "bulge_max",
    "bulge_smooth",
)


def _snapshot_foreign_constraint(pose_bone, constraint):
    values = {}
    for name in _SPLINE_IK_SNAPSHOT_PROPERTIES:
        if not hasattr(constraint, name):
            continue
        value = getattr(constraint, name)
        # Blender ID values such as ``target`` also expose ``copy()``, but
        # calling it creates a real duplicate Object/Data user.  Snapshots must
        # retain those exact external references; only value types (Matrix,
        # Vector, etc.) are copied defensively.
        values[name] = (
            value
            if isinstance(value, bpy.types.ID)
            else value.copy() if hasattr(value, "copy") else value
        )
    return {
        "pose_bone": pose_bone,
        "constraint": constraint,
        "index": tuple(pose_bone.constraints).index(constraint),
        "name": constraint.name,
        "values": values,
        "registry_raw": pose_bone.get(CONSTRAINT_REGISTRY_KEY, ""),
    }


def _restore_foreign_constraint(snapshot):
    pose_bone = snapshot["pose_bone"]
    constraint = pose_bone.constraints.new(type="SPLINE_IK")
    constraint.name = snapshot["name"]
    for name, value in snapshot["values"].items():
        try:
            setattr(constraint, name, value)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    registry_raw = snapshot["registry_raw"]
    if registry_raw:
        pose_bone[CONSTRAINT_REGISTRY_KEY] = registry_raw
    elif CONSTRAINT_REGISTRY_KEY in pose_bone:
        del pose_bone[CONSTRAINT_REGISTRY_KEY]
    constraints = pose_bone.constraints
    current_index = tuple(constraints).index(constraint)
    if current_index != snapshot["index"]:
        constraints.move(current_index, snapshot["index"])
    return constraint


def _clear_owner_tags(target):
    for key in (
        OWNER_KEY,
        VERSION_KEY,
        RIG_ID_KEY,
        ROLE_KEY,
        CHAIN_KEY,
        ARMATURE_KEY,
        CONTROL_INDEX_KEY,
    ):
        if key in target:
            del target[key]


def _delete_generated_constraint(pose_bone, constraint):
    """Fault-injection seam for the owned-constraint removal stage."""

    _remove_constraint(pose_bone, constraint)


def _delete_generated_object(obj):
    """Fault-injection seam for one exact generated Object deletion."""

    bpy.data.objects.remove(obj, do_unlink=True)


def _delete_generated_curve(curve_data):
    """Fault-injection seam for the exact generated Curve Data deletion."""

    bpy.data.curves.remove(curve_data)


def _discard_removal_backup(backup):
    for item in reversed(backup.get("objects", ())):
        obj = item["backup"]
        try:
            if bpy.data.objects.get(obj.name) is obj:
                bpy.data.objects.remove(obj, do_unlink=True)
        except (ReferenceError, RuntimeError):
            pass
    curve_data = backup.get("curve_data_backup")
    try:
        if (
            curve_data is not None
            and bpy.data.curves.get(curve_data.name) is curve_data
            and not curve_data.users
        ):
            bpy.data.curves.remove(curve_data)
    except (ReferenceError, RuntimeError):
        pass


def _copy_generated_curve_object(obj, curve_data_backup):
    """Clone the generated Curve Object without ever referencing its live data.

    ``Object.copy()`` is unsafe for this transaction in Blender 5.2: copying a
    Curve Object and then changing ``data`` can leave an untracked Object ID
    holding the original Curve Data as an extra user.  Construct the backup
    directly on the already-copied datablock and reproduce the small, fully
    owned generated-object contract explicitly.
    """

    clone = bpy.data.objects.new(f"{obj.name}_RemovalBackup", curve_data_backup)
    try:
        clone.parent = obj.parent
        clone.parent_type = obj.parent_type
        clone.parent_bone = obj.parent_bone
        clone.matrix_parent_inverse = obj.matrix_parent_inverse.copy()
        clone.matrix_basis = obj.matrix_basis.copy()
        clone.rotation_mode = obj.rotation_mode
        clone.display_type = obj.display_type
        clone.show_in_front = obj.show_in_front
        clone.show_name = obj.show_name
        clone.show_axis = obj.show_axis
        clone.show_wire = obj.show_wire
        clone.show_all_edges = obj.show_all_edges
        clone.hide_select = obj.hide_select
        clone.color = tuple(obj.color)
        for key in obj.keys():
            clone[key] = obj[key]
        for source in obj.modifiers:
            if source.type != "HOOK":
                raise SplineIKSetupError(
                    "The generated Curve has an unexpected modifier during backup."
                )
            modifier = clone.modifiers.new(source.name, type="HOOK")
            modifier.object = source.object
            modifier.vertex_group = source.vertex_group
            modifier.strength = source.strength
            modifier.falloff_type = source.falloff_type
            modifier.falloff_radius = source.falloff_radius
            modifier.use_falloff_uniform = source.use_falloff_uniform
            modifier.matrix_inverse = source.matrix_inverse.copy()
            modifier.show_viewport = source.show_viewport
            modifier.show_render = source.show_render
            modifier.show_in_editmode = source.show_in_editmode
            modifier.show_on_cage = source.show_on_cage
            modifier.show_expanded = source.show_expanded
            modifier.vertex_indices_set(tuple(source.vertex_indices))
        return clone
    except Exception:
        if bpy.data.objects.get(clone.name) is clone:
            bpy.data.objects.remove(clone, do_unlink=True)
        raise


def _snapshot_removal_inventory(inventory, armature, chain_names, rig_id):
    backup = {"objects": (), "curve_data_backup": None}
    object_items = []
    try:
        curve_data_backup = inventory["curve_data"].copy()
        _clear_owner_tags(curve_data_backup)
        backup["curve_data_backup"] = curve_data_backup
        for obj in inventory["objects"]:
            if obj is inventory["curve_object"]:
                obj_backup = _copy_generated_curve_object(obj, curve_data_backup)
            else:
                obj_backup = obj.copy()
            _clear_owner_tags(obj_backup)
            object_items.append(
                {
                    "original": obj,
                    "backup": obj_backup,
                    "name": obj.name,
                    "collections": tuple(obj.users_collection),
                    "role": obj.get(ROLE_KEY),
                    "control_index": obj.get(CONTROL_INDEX_KEY),
                    "hide_viewport": bool(obj.hide_viewport),
                    "hide_render": bool(obj.hide_render),
                    "hide_get": bool(obj.hide_get()),
                    "selected": bool(obj.select_get()),
                }
            )
        backup.update(
            {
                "objects": tuple(object_items),
                "curve_data_name": inventory["curve_data"].name,
                "constraint": _snapshot_foreign_constraint(
                    inventory["constraint_owner"],
                    inventory["constraint"],
                ),
                "armature": armature,
                "chain_names": tuple(chain_names),
                "rig_id": rig_id,
            }
        )
        return backup
    except Exception:
        _discard_removal_backup(backup)
        raise


def _restore_removal_backup(context, backup):
    armature = backup["armature"]
    chain_names = backup["chain_names"]
    rig_id = backup["rig_id"]
    owner = backup["constraint"]["pose_bone"]
    surviving_constraint = owner.constraints.get(backup["constraint"]["name"])
    if surviving_constraint is not None:
        _remove_constraint(owner, surviving_constraint)

    # Clear any exact surviving originals before re-linking the complete copy.
    for item in reversed(backup["objects"]):
        original = item["original"]
        try:
            if bpy.data.objects.get(item["name"]) is original:
                bpy.data.objects.remove(original, do_unlink=True)
        except ReferenceError:
            pass
    original_curve_data = bpy.data.curves.get(backup["curve_data_name"])
    curve_data_backup = backup["curve_data_backup"]
    if original_curve_data is not None and original_curve_data is not curve_data_backup:
        if original_curve_data.users:
            raise SplineIKSetupError(
                "Removal recovery found the original Curve Data still in unexpected use."
            )
        bpy.data.curves.remove(original_curve_data)

    restored = {}
    for item in backup["objects"]:
        obj = item["backup"]
        obj.name = item["name"]
        for collection in item["collections"]:
            collection.objects.link(obj)
        _set_tags(
            obj,
            rig_id,
            item["role"],
            armature,
            chain_names,
            control_index=(
                item["control_index"] if item["role"] == "CONTROL" else None
            ),
        )
        obj.hide_viewport = item["hide_viewport"]
        obj.hide_render = item["hide_render"]
        try:
            obj.hide_set(item["hide_get"])
        except RuntimeError:
            pass
        restored[item["role"], item["control_index"]] = obj

    curve_obj = restored["CURVE", None]
    curve_data_backup.name = backup["curve_data_name"]
    _set_tags(curve_data_backup, rig_id, "CURVE_DATA", armature, chain_names)
    controls = {
        index: obj
        for (role, index), obj in restored.items()
        if role == "CONTROL"
    }
    for index, modifier in enumerate(curve_obj.modifiers):
        modifier.object = controls[index]
    context.view_layer.update()
    for item in backup["objects"]:
        obj = item["backup"]
        try:
            obj.select_set(item["selected"])
        except RuntimeError:
            pass

    backup["constraint"]["values"]["target"] = curve_obj
    _restore_foreign_constraint(backup["constraint"])
    inventory = _rig_inventory(context, armature, chain_names, rig_id)
    backup["objects"] = ()
    backup["curve_data_backup"] = None
    return inventory


def _hook_registry(curve_obj):
    raw = curve_obj.get(HOOK_REGISTRY_KEY, "")
    try:
        payload = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise SplineIKSetupError("The generated Hook registry is corrupt.") from exc
    if not isinstance(payload, list):
        raise SplineIKSetupError("The generated Hook registry is invalid.")
    return payload


def _rig_inventory(context, armature, chain_names, rig_id):
    _require_current_scene(context, armature)
    constraints = _owned_constraints(
        armature,
        rig_id=rig_id,
        chain_names=chain_names,
    )
    if len(constraints) != 1:
        raise SplineIKSetupError(
            "The generated setup must have exactly one owned Spline IK constraint."
        )
    tip_pose_bone, constraint = constraints[0]
    if tip_pose_bone.name != chain_names[-1]:
        raise SplineIKSetupError("The owned Spline IK is no longer on the captured tip bone.")

    curve_candidates = [
        obj
        for obj in bpy.data.objects
        if _is_owned(
            obj,
            rig_id=rig_id,
            role="CURVE",
            armature=armature,
            chain_names=chain_names,
        )
    ]
    if len(curve_candidates) != 1 or constraint.target is not curve_candidates[0]:
        raise SplineIKSetupError(
            "The generated setup has an ambiguous, duplicated, or mismatched Curve."
        )
    curve_obj = curve_candidates[0]
    _require_generated_object_scene(context, curve_obj)
    if curve_obj.type != "CURVE" or curve_obj.parent is not armature:
        raise SplineIKSetupError("The generated Curve parent or type no longer matches.")
    curve_data = curve_obj.data
    if (
        curve_data is None
        or curve_data.users != 1
        or not _is_owned(
            curve_data,
            rig_id=rig_id,
            role="CURVE_DATA",
            armature=armature,
            chain_names=chain_names,
        )
    ):
        raise SplineIKSetupError(
            "The generated Curve Data is missing, shared, copied, or mismatched."
        )

    controls = [
        obj
        for obj in bpy.data.objects
        if _is_owned(
            obj,
            rig_id=rig_id,
            role="CONTROL",
            armature=armature,
            chain_names=chain_names,
        )
    ]
    registry = _hook_registry(curve_obj)
    if len(registry) < 3 or len(controls) != len(registry):
        raise SplineIKSetupError("The generated control or Hook count no longer matches.")
    controls_by_index = {}
    for control in controls:
        _require_generated_object_scene(context, control)
        if control.type != "EMPTY" or control.parent is not armature:
            raise SplineIKSetupError(
                f"Generated control '{control.name}' has a mismatched type or parent."
            )
        index = control.get(CONTROL_INDEX_KEY)
        if not isinstance(index, int) or isinstance(index, bool) or index in controls_by_index:
            raise SplineIKSetupError("Generated control indices are missing or duplicated.")
        controls_by_index[index] = control
    expected_indices = set(range(len(registry)))
    if set(controls_by_index) != expected_indices:
        raise SplineIKSetupError("Generated control indices are not contiguous.")

    modifier_names = [modifier.name for modifier in curve_obj.modifiers]
    registry_names = []
    for index, record in enumerate(registry):
        if not isinstance(record, dict):
            raise SplineIKSetupError("The Hook registry contains an invalid entry.")
        expected_name = f"CDSplineIK_Hook_{rig_id}_{index + 1:02d}"
        control = controls_by_index[index]
        if (
            record.get("name") != expected_name
            or record.get("owner") != OWNER_VALUE
            or record.get("version") != RIG_VERSION
            or record.get("rig_id") != rig_id
            or record.get("role") != "HOOK"
            or record.get("control_index") != index
            or record.get("target") != control.name
        ):
            raise SplineIKSetupError("The Hook registry no longer matches the generated setup.")
        modifier = curve_obj.modifiers.get(expected_name)
        if (
            modifier is None
            or modifier.type != "HOOK"
            or modifier.object is not control
            or tuple(modifier.vertex_indices) != (index * 3, index * 3 + 1, index * 3 + 2)
        ):
            raise SplineIKSetupError(
                f"Generated Hook '{expected_name}' no longer matches its registered control."
            )
        registry_names.append(expected_name)
    if modifier_names != registry_names:
        raise SplineIKSetupError(
            "The generated Curve has unregistered, duplicated, or reordered modifiers."
        )

    all_tagged_objects = [
        obj
        for obj in bpy.data.objects
        if obj.get(RIG_ID_KEY) == rig_id and obj.get(OWNER_KEY) == OWNER_VALUE
    ]
    expected_objects = {curve_obj, *controls_by_index.values()}
    if set(all_tagged_objects) != expected_objects:
        raise SplineIKSetupError(
            "Duplicate or foreign copied objects share this generated rig identifier."
        )
    all_tagged_curves = [
        data
        for data in bpy.data.curves
        if data.get(RIG_ID_KEY) == rig_id and data.get(OWNER_KEY) == OWNER_VALUE
    ]
    if all_tagged_curves != [curve_data]:
        raise SplineIKSetupError(
            "Duplicate or foreign Curve Data shares this generated rig identifier."
        )
    return {
        "constraint_owner": tip_pose_bone,
        "constraint": constraint,
        "curve_object": curve_obj,
        "curve_data": curve_data,
        "controls": tuple(controls_by_index[index] for index in range(len(registry))),
        "objects": (curve_obj, *(controls_by_index[index] for index in range(len(registry)))),
    }


def _remove_inventory(context, armature, chain_names, rig_id, inventory):
    # The complete inventory has already passed all ambiguity and sharing
    # checks. Delete exact resolved pointers only; never rescan by tag to delete.
    backup = _snapshot_removal_inventory(inventory, armature, chain_names, rig_id)
    object_count = len(inventory["objects"])
    try:
        _delete_generated_constraint(
            inventory["constraint_owner"],
            inventory["constraint"],
        )
        for obj in reversed(inventory["objects"]):
            if bpy.data.objects.get(obj.name) is not obj:
                raise SplineIKSetupError(
                    f"Generated object '{obj.name}' disappeared during removal."
                )
            _delete_generated_object(obj)
        curve_data = inventory["curve_data"]
        if bpy.data.curves.get(curve_data.name) is not curve_data or curve_data.users:
            raise SplineIKSetupError("Generated Curve Data could not be removed safely.")
        _delete_generated_curve(curve_data)
        if _owned_constraints(armature, rig_id=rig_id, chain_names=chain_names):
            raise SplineIKSetupError("The owned Spline IK constraint survived removal.")
        if any(
            obj.get(RIG_ID_KEY) == rig_id and obj.get(OWNER_KEY) == OWNER_VALUE
            for obj in bpy.data.objects
        ):
            raise SplineIKSetupError("Generated objects survived removal.")
    except Exception as exc:
        try:
            _restore_removal_backup(context, backup)
        except Exception as restore_exc:
            raise SplineIKSetupError(
                f"Generated setup removal failed: {exc}. Recovery also failed: {restore_exc}"
            ) from restore_exc
        raise SplineIKSetupError(
            f"Generated setup removal failed and was restored unchanged: {exc}"
        ) from exc
    _discard_removal_backup(backup)
    return {"constraints": 1, "objects": object_count, "curves": 1}


def _remove_rig(context, armature, chain_names, rig_id):
    inventory = _rig_inventory(context, armature, chain_names, rig_id)
    return _remove_inventory(context, armature, chain_names, rig_id, inventory)


def _rollback(created_constraints, created_objects, created_curves):
    for pose_bone, constraint in reversed(created_constraints):
        try:
            _remove_constraint(pose_bone, constraint)
        except (ReferenceError, RuntimeError):
            pass
    for obj in reversed(created_objects):
        try:
            if bpy.data.objects.get(obj.name) is obj:
                bpy.data.objects.remove(obj, do_unlink=True)
        except (ReferenceError, RuntimeError):
            pass
    for curve in reversed(created_curves):
        try:
            if bpy.data.curves.get(curve.name) is curve and not curve.users:
                bpy.data.curves.remove(curve)
        except (ReferenceError, RuntimeError):
            pass


def _snapshot_edit_bone_state(armature):
    active = armature.data.edit_bones.active
    return {
        "bones": {
            bone.name: (
                bool(bone.select),
                bool(bone.select_head),
                bool(bone.select_tail),
            )
            for bone in armature.data.edit_bones
        },
        "active": active.name if active is not None else "",
    }


def _restore_edit_bone_state(context, armature, snapshot):
    context.view_layer.objects.active = armature
    armature.select_set(True)
    result = bpy.ops.object.mode_set(mode="EDIT")
    if result != {"FINISHED"} or context.mode != "EDIT_ARMATURE" or context.object is not armature:
        raise SplineIKSetupError("Blender could not restore the captured Armature Edit Mode.")
    edit_bones = armature.data.edit_bones
    if set(snapshot["bones"]) != {bone.name for bone in edit_bones}:
        raise SplineIKSetupError("The Armature bones changed while restoring Edit Mode.")
    for bone in edit_bones:
        select, select_head, select_tail = snapshot["bones"][bone.name]
        bone.select = select
        bone.select_head = select_head
        bone.select_tail = select_tail
    active_name = snapshot["active"]
    if active_name:
        active = edit_bones.get(active_name)
        if active is None:
            raise SplineIKSetupError("The active Edit Bone disappeared while restoring context.")
        edit_bones.active = active
    restored = _snapshot_edit_bone_state(armature)
    if restored != snapshot:
        raise SplineIKSetupError("Blender did not restore the Edit Bone selection exactly.")


def _current_rig(context, settings):
    armature = settings.armature if settings is not None else None
    names = _captured_names(settings)
    if armature is None or not names:
        raise SplineIKSetupError("Capture a bone chain first.")
    _require_current_scene(context, armature)
    _chain_bones(armature, names)
    rig_id = _resolved_rig_id(settings, armature, names)
    if not rig_id:
        raise SplineIKSetupError("No generated Spline IK setup matches the captured chain.")
    inventory = _rig_inventory(context, armature, names, rig_id)
    return armature, names, rig_id, inventory


class CharacterDesignerSplineIKState(PropertyGroup):
    armature: PointerProperty(
        name="Armature",
        type=bpy.types.Object,
        poll=_armature_poll,
        options={"SKIP_SAVE"},
    )
    point_count: IntProperty(
        name="Curve Points",
        description="Number of Bezier points and Hook controls sampled along the chain",
        default=5,
        min=3,
        max=12,
        options={"SKIP_SAVE"},
    )
    control_size_ratio: FloatProperty(
        name="Control Size Ratio",
        description="Wire control size relative to the selected chain's local total length",
        default=0.06,
        min=0.005,
        max=0.5,
        precision=3,
        options={"SKIP_SAVE"},
    )
    replace_existing: BoolProperty(
        name="Replace Existing Spline IK",
        description="Replace one unambiguous non-Character-Designer Spline IK on the tip bone",
        default=False,
        options={"SKIP_SAVE"},
    )
    chain_names_json: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    chain_count: IntProperty(default=0, min=0, options={"HIDDEN", "SKIP_SAVE"})
    active_rig_id: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    last_level: StringProperty(default="NONE", options={"HIDDEN", "SKIP_SAVE"})
    last_message: StringProperty(options={"HIDDEN", "SKIP_SAVE"})


class CHARACTERDESIGNER_OT_spline_ik_capture_chain(Operator):
    bl_idname = "character_designer.spline_ik_capture_chain"
    bl_label = "Capture Bone Chain"
    bl_description = "Capture one strictly continuous selected parent-child bone chain"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return (
            context.object is not None
            and context.object.type == "ARMATURE"
            and context.mode in {"POSE", "EDIT_ARMATURE"}
        )

    def execute(self, context):
        settings = _settings(context)
        try:
            if settings is None:
                raise SplineIKSetupError("Spline IK state is unavailable.")
            armature, names = _selected_chain(context)
            _chain_geometry(armature, names)
            settings.armature = armature
            settings.chain_names_json = _canonical_chain_json(names)
            settings.chain_count = len(names)
            settings.active_rig_id = _resolved_rig_id(settings, armature, names)
            message = f"Captured {len(names)} bones: {names[0]} -> {names[-1]}."
            _set_status(settings, "SUCCESS", message)
            self.report({"INFO"}, message)
            return {"FINISHED"}
        except (SplineIKSetupError, ReferenceError, RuntimeError) as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class CHARACTERDESIGNER_OT_spline_ik_build(Operator):
    bl_idname = "character_designer.spline_ik_build"
    bl_label = "Build Spline IK Setup"
    bl_description = "Build a non-stretching Spline IK Curve and wire Hook controls"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        return bool(settings and settings.armature and settings.chain_names_json)

    def execute(self, context):
        settings = _settings(context)
        created_constraints = []
        created_objects = []
        created_curves = []
        armature = None
        restore_edit_mode = context.mode == "EDIT_ARMATURE"
        switched_captured_armature_to_pose = False
        edit_state_snapshot = None
        result = None
        deferred_error = None
        foreign_snapshot = None
        foreign_removed = False
        try:
            if settings is None:
                raise SplineIKSetupError("Spline IK state is unavailable.")
            armature = settings.armature
            names = _captured_names(settings)
            if (
                context.object is not armature
                or context.view_layer.objects.active is not armature
                or context.mode not in {"POSE", "EDIT_ARMATURE"}
            ):
                raise SplineIKSetupError(
                    "Make the captured Armature active in Pose or Armature Edit Mode before building."
                )
            _require_current_scene(context, armature)
            _bones, joints, total_bone_length = _chain_geometry(armature, names)
            try:
                armature.matrix_world.inverted()
            except ValueError as exc:
                raise SplineIKSetupError(
                    "The Armature has a singular object transform; remove zero scale before building."
                ) from exc

            # Pose constraints cannot be created reliably while the Armature's
            # edit-bone table is live. Switch only for the transaction and
            # restore the artist's Edit Mode state in the finally block.
            if restore_edit_mode:
                edit_state_snapshot = _snapshot_edit_bone_state(armature)
                result = bpy.ops.object.mode_set(mode="POSE")
                if result != {"FINISHED"}:
                    raise SplineIKSetupError("Blender could not enter Pose Mode to build Spline IK.")
                switched_captured_armature_to_pose = True

            tip_pose_bone = armature.pose.bones.get(names[-1]) if armature.pose else None
            if tip_pose_bone is None:
                raise SplineIKSetupError("The captured tip Pose Bone is unavailable.")
            # This PoseBone is the only ID owner we may write below. Validate
            # its raw registry before creating any object or constraint so a
            # malformed value is neither overwritten nor left with residue.
            _constraint_registry(tip_pose_bone, strict=True)

            same_rig_matches = _owned_constraints(armature, chain_names=names)
            same_rig_ids = {
                _constraint_record(pose_bone, constraint, armature, names).get("rig_id", "")
                for pose_bone, constraint in same_rig_matches
            }
            same_rig_ids.discard("")
            if len(same_rig_ids) > 1:
                raise SplineIKSetupError(
                    "Multiple generated setups match this chain; remove them before rebuilding."
                )
            old_rig_id = next(iter(same_rig_ids)) if same_rig_ids else ""
            if old_rig_id:
                _rig_inventory(context, armature, names, old_rig_id)
                raise SplineIKSetupError(
                    "A generated setup already exists for this chain. "
                    "Use Remove Generated before building a replacement."
                )

            spline_constraints = [
                constraint
                for constraint in tip_pose_bone.constraints
                if constraint.type == "SPLINE_IK"
            ]
            foreign_constraints = [
                constraint
                for constraint in spline_constraints
                if _constraint_record(tip_pose_bone, constraint, armature) is None
            ]
            for foreign_constraint in foreign_constraints:
                target = foreign_constraint.target
                if target is not None and target.get(OWNER_KEY) == OWNER_VALUE:
                    raise SplineIKSetupError(
                        "A Spline IK targets Character Designer data but has an invalid "
                        "ownership registry; repair or remove it manually."
                    )
            owned_other = []
            for constraint in spline_constraints:
                record = _constraint_record(tip_pose_bone, constraint, armature)
                if record is not None and record.get("rig_id", "") != old_rig_id:
                    owned_other.append(constraint)
            if owned_other:
                raise SplineIKSetupError(
                    "The tip bone has another generated setup; remove it before building this chain."
                )
            if foreign_constraints and not settings.replace_existing:
                raise SplineIKSetupError(
                    "The tip bone already has a non-Character-Designer Spline IK. "
                    "Enable Replace Existing to replace one unambiguous constraint."
                )
            if len(foreign_constraints) > 1:
                raise SplineIKSetupError(
                    "The tip bone has multiple non-Character-Designer Spline IK constraints; "
                    "remove all but the intended one manually."
                )
            if foreign_constraints:
                foreign_snapshot = _snapshot_foreign_constraint(
                    tip_pose_bone,
                    foreign_constraints[0],
                )

            samples = _sample_polyline(joints, settings.point_count)
            control_size = total_bone_length * settings.control_size_ratio
            if control_size <= EPSILON:
                raise SplineIKSetupError("Control Size Ratio produces a zero-sized control.")

            new_rig_id = uuid.uuid4().hex
            curve_obj, controls = _create_curve_and_controls(
                context,
                armature,
                names,
                samples,
                control_size,
                new_rig_id,
                created_objects,
                created_curves,
            )
            constraint = tip_pose_bone.constraints.new(type="SPLINE_IK")
            created_constraints.append((tip_pose_bone, constraint))
            _configure_constraint(constraint, curve_obj, len(names))
            _tag_constraint(
                tip_pose_bone,
                constraint,
                new_rig_id,
                armature,
                names,
            )
            # Validate the complete newly-created ownership graph before any
            # irreversible replacement commit.
            _rig_inventory(context, armature, names, new_rig_id)

            # Commit only after the complete replacement exists. Removing a
            # foreign constraint never removes or edits its target Curve.
            if foreign_constraints:
                tip_pose_bone.constraints.remove(foreign_constraints[0])
                foreign_removed = True

            settings.active_rig_id = new_rig_id
            settings.chain_count = len(names)
            message = (
                f"Built {len(names)}-bone Spline IK with {len(controls)} Hook controls "
                "and no Y-axis stretch."
            )
            _set_status(settings, "SUCCESS", message)
            self.report({"INFO"}, message)
            result = {"FINISHED"}
        except (SplineIKSetupError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
            _rollback(created_constraints, created_objects, created_curves)
            if foreign_removed and foreign_snapshot is not None:
                try:
                    _restore_foreign_constraint(foreign_snapshot)
                except (ReferenceError, RuntimeError, TypeError, ValueError) as restore_exc:
                    exc = SplineIKSetupError(
                        f"{exc} The replaced artist constraint could not be restored: {restore_exc}"
                    )
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            result = {"CANCELLED"}
        finally:
            if (
                restore_edit_mode
                and switched_captured_armature_to_pose
                and armature is not None
                and bpy.data.objects.get(armature.name) is armature
                and armature.mode != "EDIT"
            ):
                try:
                    _restore_edit_bone_state(context, armature, edit_state_snapshot)
                except (SplineIKSetupError, ReferenceError, RuntimeError) as restore_exc:
                    deferred_error = restore_exc
        if deferred_error is not None:
            message = f"Build result was cancelled because Edit Mode restoration failed: {deferred_error}"
            _set_status(settings, "ERROR", message)
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        return result or {"CANCELLED"}


class CHARACTERDESIGNER_OT_spline_ik_select_controls(Operator):
    bl_idname = "character_designer.spline_ik_select_controls"
    bl_label = "Select Controls"
    bl_description = "Select this captured chain's generated Hook control Empties"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        return bool(settings and settings.armature and settings.chain_names_json)

    def execute(self, context):
        settings = _settings(context)
        try:
            _armature, _names, _rig_id, inventory = _current_rig(context, settings)
            controls = inventory["controls"]
            if context.mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            for obj in context.view_layer.objects:
                obj.select_set(False)
            selected = []
            for control in controls:
                if context.view_layer.objects.get(control.name) is not control:
                    continue
                try:
                    control.hide_set(False)
                    control.select_set(True)
                except RuntimeError:
                    continue
                if control.select_get(view_layer=context.view_layer):
                    selected.append(control)
            if not selected:
                raise SplineIKSetupError(
                    "The controls are hidden or excluded from the current View Layer."
                )
            context.view_layer.objects.active = selected[0]
            message = f"Selected {len(selected)} Spline IK controls."
            _set_status(settings, "SUCCESS", message)
            return {"FINISHED"}
        except (SplineIKSetupError, ReferenceError, RuntimeError) as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class CHARACTERDESIGNER_OT_spline_ik_remove_generated(Operator):
    bl_idname = "character_designer.spline_ik_remove_generated"
    bl_label = "Remove Generated"
    bl_description = "Remove only the exactly tagged generated setup for this captured chain"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = _settings(context)
        return bool(settings and settings.armature and settings.chain_names_json)

    def invoke(self, context, _event):
        return context.window_manager.invoke_confirm(self, _event)

    def execute(self, context):
        settings = _settings(context)
        try:
            armature, names, rig_id, inventory = _current_rig(context, settings)
            summary = _remove_inventory(
                context,
                armature,
                names,
                rig_id,
                inventory,
            )
            if not any(summary.values()):
                raise SplineIKSetupError("No exactly tagged generated setup was removed.")
            settings.active_rig_id = ""
            message = (
                f"Removed {summary['objects']} generated objects and "
                f"{summary['constraints']} generated constraint."
            )
            _set_status(settings, "SUCCESS", message)
            self.report({"INFO"}, message)
            return {"FINISHED"}
        except (SplineIKSetupError, ReferenceError, RuntimeError) as exc:
            _set_status(settings, "ERROR", str(exc))
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


def _draw_status(layout, settings):
    if not settings.last_message:
        return
    icon = {
        "ERROR": "ERROR",
        "SUCCESS": "CHECKMARK",
        "INFO": "INFO",
    }.get(settings.last_level, "INFO")
    lines = textwrap.wrap(
        settings.last_message,
        width=48,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [settings.last_message]
    for index, line in enumerate(lines):
        row = layout.row()
        row.alert = settings.last_level == "ERROR"
        row.label(text=line, icon=icon if index == 0 else "NONE")


class CHARACTERDESIGNER_PT_spline_ik_setup(Panel):
    bl_label = "Spline IK Setup"
    bl_idname = "CHARACTERDESIGNER_PT_spline_ik_setup"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = SIDEBAR_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        settings = _settings(context)
        if settings is None:
            layout.label(text="Spline IK state is unavailable.", icon="ERROR")
            return

        layout.prop(settings, "armature")
        layout.operator(
            "character_designer.spline_ik_capture_chain",
            text="Capture Selected Chain",
            icon="BONE_DATA",
        )
        try:
            names = _captured_names(settings)
        except SplineIKSetupError:
            names = ()
        if names:
            layout.label(
                text=f"{len(names)} bones: {names[0]} -> {names[-1]}",
                icon="CONSTRAINT_BONE",
            )

        layout.prop(settings, "point_count")
        layout.prop(settings, "control_size_ratio")
        layout.prop(settings, "replace_existing")

        build_row = layout.row()
        build_row.enabled = bool(settings.armature and names)
        build_row.operator(
            "character_designer.spline_ik_build",
            text="Build Spline IK Setup",
            icon="CON_SPLINEIK",
        )

        has_valid_rig = False
        if settings.armature and names:
            try:
                rig_id = _resolved_rig_id(settings, settings.armature, names)
                if rig_id:
                    _rig_inventory(context, settings.armature, names, rig_id)
                    has_valid_rig = True
            except (SplineIKSetupError, ReferenceError, RuntimeError):
                has_valid_rig = False
        if has_valid_rig:
            action_row = layout.row(align=True)
            action_row.operator(
                "character_designer.spline_ik_select_controls",
                text="Select Controls",
                icon="EMPTY_AXIS",
            )
            remove_row = action_row.row(align=True)
            remove_row.alert = True
            remove_row.operator(
                "character_designer.spline_ik_remove_generated",
                text="Remove Generated",
                icon="TRASH",
            )

        _draw_status(layout, settings)


SPLINE_IK_SETUP_CLASSES = (
    CharacterDesignerSplineIKState,
    CHARACTERDESIGNER_OT_spline_ik_capture_chain,
    CHARACTERDESIGNER_OT_spline_ik_build,
    CHARACTERDESIGNER_OT_spline_ik_select_controls,
    CHARACTERDESIGNER_OT_spline_ik_remove_generated,
    CHARACTERDESIGNER_PT_spline_ik_setup,
)


__all__ = (
    "CharacterDesignerSplineIKState",
    "SPLINE_IK_SETUP_CLASSES",
)
